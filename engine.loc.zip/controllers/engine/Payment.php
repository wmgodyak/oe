<?php
/**
 * OYiEngine 7
 * @author Volodymyr Hodiak mailto:support@otakoi.com
 * @copyright Copyright (c) 2015 Otakoyi.com
 * Date: 25.12.15 : 17:46
 */

namespace controllers\engine;

use controllers\Engine;
use helpers\bootstrap\Button;
use helpers\bootstrap\Icon;
use helpers\bootstrap\Link;
use helpers\FormValidation;
use models\engine\DeliveryPayment;

defined("CPATH") or die();

/**
 * Class Payment
 * @name Оплата
 * @icon fa-credit-card
 * @author Volodymyr Hodiak
 * @version 1.0.0
 * @rang 300
 * @package controllers\engine
 */
class Payment extends Engine
{
    private $payment;

    public function __construct()
    {
        parent::__construct();
        $this->payment = new \models\engine\Payment();
    }

    public function index()
    {
        $this->appendToPanel
        (
            (string)Button::create($this->t('common.button_create'), ['class' => 'btn-md b-payment-create'])
        );
        $t = new DataTables();

        $t  -> setId('payment')
            -> ajaxConfig('payment/items')
//            -> setConfig('order', array(0, 'desc'))
            -> th($this->t('common.id'), '', 'width: 20px')
            -> th($this->t('payment.name'))
            -> th($this->t('common.tbl_func'), '', 'width: 180px')
        ;

        $this->output($t->render());
    }

    public function items()
    {
        $t = new DataTables();
        $t  -> table('payment d')
            -> join("payment_info i on i.payment_id=d.id and i.languages_id={$this->languages_id}")
            -> get('d.id,i.name,d.published')

            -> execute();

        $res = array();
        foreach ($t->getResults(false) as $i=>$row) {
            $res[$i][] = $row['id'];
            $res[$i][] = $row['name'];
            $res[$i][] =
                (string)(
                $row['published'] ?
                    Button::create
                    (
                        Icon::create(Icon::TYPE_PUBLISHED),
                        [
                            'class' => 'btn-primary b-payment-hide',
                            'title' => $this->t('common.title_pub'),
                            'data-id' => $row['id']
                        ]
                    )
                    :
                    Button::create
                    (
                        Icon::create(Icon::TYPE_HIDDEN),
                        [
                            'class' => 'btn-primary b-payment-pub',
                            'title' => $this->t('common.title_hide'),
                            'data-id' => $row['id']
                        ]
                    )
                ).
                (string)Button::create
                (
                    Icon::create(Icon::TYPE_EDIT),
                    ['class' => 'b-payment-edit', 'data-id' => $row['id'], 'title' => $this->t('common.title_edit')]
                ) .
                (string)Button::create
                (
                    Icon::create(Icon::TYPE_DELETE),
                    ['class' => 'b-payment-delete', 'data-id' => $row['id'], 'title' => $this->t('common.title_delete')]
                )
            ;
        }

        return $t->renderJSON($res, $t->getTotal());
   }

    public function create()
    {
        $this->template->assign('action', 'create');
        $this->template->assign('delivery', DeliveryPayment::getDelivery());
        $this->response->body($this->template->fetch('payment/edit'))->asHtml();
    }
    public function edit($id)
    {
        $this->template->assign('data', $this->payment->getData($id));
        $this->template->assign('delivery', DeliveryPayment::getDelivery());
        $this->template->assign('selected', DeliveryPayment::getSelectedDelivery($id));
        $this->template->assign('action', 'edit');
        $this->response->body($this->template->fetch('payment/edit'))->asHtml();
    }

    public function process($id= null)
    {
        if(! $this->request->isPost()) die;

        $payment_info = $this->request->post('info');
        $s=0; $i=[];

        foreach ($payment_info as $languages_id=> $item) {
            if(empty($item['name'])){
                $i[] = ["info[$languages_id][name]" => $this->t('payment.empty_name')];
            }
        }



        if(empty($i)){
            switch($this->request->post('action')){
                case 'create':
                    $s = $this->payment->create();
                    break;
                case 'edit':
                    if( $id > 0 ){
                        $s = $this->payment->update($id);
                    }
                    break;
            }
            if(! $s){
                echo $this->payment->getDBErrorMessage();
            }

        }

        $this->response->body(['s'=>$s, 'i' => $i])->asJSON();
    }

    public function delete($id)
    {
        return $this->payment->delete($id);
    }

    public function pub($id)
    {
        return $this->payment->pub($id);
    }

    public function hide($id)
    {
        return $this->payment->hide($id);
    }

}