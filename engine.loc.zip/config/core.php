<?php
/**
 * OYiEngine 7
 * @author Volodymyr Hodiak mailto:support@otakoi.com
 * @copyright Copyright (c) 2015 Otakoyi.com
 * Date: 18.12.15 : 11:54
 */

    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    return array(
        'debug' => true,
        'lang'  => 'uk',
        'user'  => 'wg'
    );