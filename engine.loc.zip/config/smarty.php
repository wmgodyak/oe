<?php
/**
 * OYiEngine 7
 * @author Volodymyr Hodiak mailto:support@otakoi.com
 * @copyright Copyright (c) 2015 Otakoyi.com
 * Date: 18.12.15 : 11:57
 */

return array(
    'compile_check'  => true,
    'caching'        => false,
    'cache_lifetime' => 0,
    'debugging'      => false,
    'html_minify'    => false
);