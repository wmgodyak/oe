
engine.payment = {
    init: function()
    {
        $(document).on('click', '.b-payment-create', function(){
            engine.payment.create();
        });
        $(document).on('click', '.b-payment-edit', function(){
            engine.payment.edit($(this).data('id'));
        });
        $(document).on('click', '.b-payment-delete', function(){
            engine.payment.delete($(this).data('id'));
        });
        $(document).on('click', '.b-payment-pub', function(){
            engine.payment.pub($(this).data('id'));
        });
        $(document).on('click', '.b-payment-hide', function(){
            engine.payment.hide($(this).data('id'));
        });
    },
    create: function()
    {
        engine.request.get('./payment/create', function(d)
        {
            var bi = t.common.button_save;
            var buttons = {};
            buttons[bi] =  function(){
                $('#form').submit();
            };
            var dialog = engine.dialog({
                content: d,
                title: t.payment.create_title,
                autoOpen: true,
                width: 600,
                modal: true,
                buttons: buttons
            });

            $('#data_code').mask('aaa');
            $('#data_payment').select2();
            engine.validateAjaxForm('#form', function(d){
                if(d.s){
                    engine.refreshDataTable('payment');
                    dialog.dialog('close');
                    dialog.dialog('destroy').remove()
                }
            });
        });
    },
    edit: function(id)
    {
        engine.request.post({
            url: './payment/edit/' + id,
            data: {id: id},
            success: function(d)
            {
                var bi = t.common.button_save;
                var buttons = {};
                buttons[bi] =  function(){
                    $('#form').submit();
                };
                var dialog = engine.dialog({
                    content: d,
                    title: t.payment.edit_title,
                    autoOpen: true,
                    width: 600,
                    modal: true,
                    buttons: buttons
                });

                $('#data_code').mask('aaa');
                $('#data_delivery').select2();

                engine.validateAjaxForm('#form', function(d){
                    if(d.s){
                        engine.refreshDataTable('payment');
                        dialog.dialog('close');
                        dialog.dialog('destroy').remove()
                    }
                });
            }
        })
    },
    delete: function(id)
    {
        engine.confirm
        (
            t.payment.delete_question,
            function()
            {
                engine.request.get('./payment/delete/' + id, function(d){
                    if(d > 0){
                        engine.refreshDataTable('payment');
                    }
                });
                $(this).dialog('close').dialog('destroy').remove();
            }
        );
    },
    pub: function(id)
    {
        engine.request.get('./payment/pub/' + id, function(d){
            if(d > 0){
                engine.refreshDataTable('payment');
            }
        });
    },
    hide: function(id)
    {
        engine.request.get('./payment/hide/' + id, function(d){
            if(d > 0){
                engine.refreshDataTable('payment');
            }
        });
    }
};

$(document).ready(function(){
   engine.payment.init();
});