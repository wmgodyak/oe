<?php

namespace system\components\blank\controllers;

use system\Engine;

defined("CPATH") or die();

class Blank extends Engine
{
    public function index()
    {
        // TODO: Implement index() method.
    }
    public function create()
    {
        // TODO: Implement create() method.
    }
    public function edit($id)
    {
        // TODO: Implement edit() method.
    }
    public function delete($id)
    {
        // TODO: Implement delete() method.
    }
    public function process($id)
    {
        // TODO: Implement process() method.
    }
}