<?php
/**
 * Created by PhpStorm.
 * User: wg
 * Date: 18.06.16
 * Time: 1:26
 */

namespace system\components\admins\models;

use system\models\UsersGroup;

class AdminsGroup extends UsersGroup
{

}