<?php
/**
 * Created by PhpStorm.
 * User: wg
 * Date: 12.06.16
 * Time: 0:34
 */

namespace system\models;

if ( !defined("CPATH") ) die();

class Blank extends Model
{

}