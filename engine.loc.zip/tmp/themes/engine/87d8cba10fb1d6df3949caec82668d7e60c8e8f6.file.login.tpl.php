<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-12-24 10:33:45
         compiled from "/var/www/engine.loc/themes/engine/views/admin/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:81463024567badca38c925-05430800%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '87d8cba10fb1d6df3949caec82668d7e60c8e8f6' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/admin/login.tpl',
      1 => 1450946024,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '81463024567badca38c925-05430800',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_567badca408853_67033721',
  'variables' => 
  array (
    'langs' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_567badca408853_67033721')) {function content_567badca408853_67033721($_smarty_tpl) {?><pre><?php echo print_r($_smarty_tpl->tpl_vars['langs']->value);?>
</pre><?php }} ?>
