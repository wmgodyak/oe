<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-17 14:24:32
         compiled from "/var/www/engine.loc/themes/engine/views/settings/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:151467736156ea62e571d1c1-37171608%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b5aac9df4aef07e2d833e2cf589f0f8e14242247' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/settings/index.tpl',
      1 => 1458217470,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '151467736156ea62e571d1c1-37171608',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56ea62e572b6c8_92597850',
  'variables' => 
  array (
    'items' => 0,
    'com_url' => 0,
    'group' => 0,
    'item_name' => 0,
    't' => 0,
    'item' => 0,
    'a' => 0,
    'title' => 0,
    'desc' => 0,
    'sys_info' => 0,
    'name' => 0,
    'v' => 0,
    'dir_perm' => 0,
    'k' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56ea62e572b6c8_92597850')) {function content_56ea62e572b6c8_92597850($_smarty_tpl) {?><form id="form" action="settings/process" method="post"  class="form-horizontal row">
    <div><br></div>
    <div class="col-md-8 col-md-offset-2">
        <div id="tabs_settings">
            <ul>
                <?php  $_smarty_tpl->tpl_vars['a'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['a']->_loop = false;
 $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['a']->key => $_smarty_tpl->tpl_vars['a']->value) {
$_smarty_tpl->tpl_vars['a']->_loop = true;
 $_smarty_tpl->tpl_vars['group']->value = $_smarty_tpl->tpl_vars['a']->key;
?>
                    <?php $_smarty_tpl->tpl_vars["item_name"] = new Smarty_variable("tab_".((string)$_smarty_tpl->tpl_vars['group']->value), null, 0);?>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['com_url']->value;?>
#<?php echo $_smarty_tpl->tpl_vars['group']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['t']->value['settings'][$_smarty_tpl->tpl_vars['item_name']->value];?>
</a></li>
                <?php } ?>
            </ul>
            <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
 $_smarty_tpl->tpl_vars['group']->value = $_smarty_tpl->tpl_vars['item']->key;
?>
                <div id="<?php echo $_smarty_tpl->tpl_vars['group']->value;?>
">
                    <?php  $_smarty_tpl->tpl_vars['a'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['a']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['a']->key => $_smarty_tpl->tpl_vars['a']->value) {
$_smarty_tpl->tpl_vars['a']->_loop = true;
?>
                        <?php $_smarty_tpl->tpl_vars["title"] = new Smarty_variable("title_".((string)$_smarty_tpl->tpl_vars['a']->value['name']), null, 0);?>
                        <?php $_smarty_tpl->tpl_vars["desc"] = new Smarty_variable("desc_".((string)$_smarty_tpl->tpl_vars['a']->value['name']), null, 0);?>
                        <div class="form-group">
                            <label for="settings_<?php echo $_smarty_tpl->tpl_vars['a']->value['name'];?>
" class="col-md-3 control-label required"><?php echo $_smarty_tpl->tpl_vars['t']->value['settings'][$_smarty_tpl->tpl_vars['title']->value];?>
</label>
                            <div class="col-md-9">
                                <?php if ($_smarty_tpl->tpl_vars['a']->value['type']=='text') {?>
                                    <input type="text" class="form-control" name="settings[<?php echo $_smarty_tpl->tpl_vars['a']->value['name'];?>
]" id="settings_<?php echo $_smarty_tpl->tpl_vars['a']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['a']->value['value'];?>
" <?php if ($_smarty_tpl->tpl_vars['a']->value['required']) {?>required<?php }?>>
                                <?php } elseif ($_smarty_tpl->tpl_vars['a']->value['type']=='textarea') {?>
                                    <textarea class="form-control" name="settings[<?php echo $_smarty_tpl->tpl_vars['a']->value['name'];?>
]" id="settings_<?php echo $_smarty_tpl->tpl_vars['a']->value['name'];?>
" <?php if ($_smarty_tpl->tpl_vars['a']->value['required']) {?>required<?php }?>><?php echo $_smarty_tpl->tpl_vars['a']->value['value'];?>
</textarea>
                                <?php }?>
                                <p class="help-block"><?php echo $_smarty_tpl->tpl_vars['t']->value['settings'][$_smarty_tpl->tpl_vars['desc']->value];?>
</p>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
        <div class="clearfix"></div>
    </div>

    <div class="col-md-8 col-md-offset-2">
        <div class="alert">
            <h3><?php echo $_smarty_tpl->tpl_vars['t']->value['settings']['sys_info'];?>
</h3>
            <ul>
                <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['sys_info']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value) {
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                    <?php $_smarty_tpl->tpl_vars["name"] = new Smarty_variable("sys_info_".((string)$_smarty_tpl->tpl_vars['k']->value), null, 0);?>
                    <li><?php echo $_smarty_tpl->tpl_vars['t']->value['settings'][$_smarty_tpl->tpl_vars['name']->value];?>
: <?php echo $_smarty_tpl->tpl_vars['v']->value;?>
</li>
                <?php } ?>
            </ul>

            <h3><?php echo $_smarty_tpl->tpl_vars['t']->value['settings']['dir_perm'];?>
</h3>
            <ul>
                <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['dir_perm']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value) {
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                    <li><?php echo $_smarty_tpl->tpl_vars['k']->value;?>
: <?php if ($_smarty_tpl->tpl_vars['v']->value==1) {
echo $_smarty_tpl->tpl_vars['t']->value['settings']['dir_perm_yes'];
} else {
echo $_smarty_tpl->tpl_vars['t']->value['settings']['dir_perm_no'];
}?></li>
                <?php } ?>
            </ul>
        </div>
    </div>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
</form><?php }} ?>
