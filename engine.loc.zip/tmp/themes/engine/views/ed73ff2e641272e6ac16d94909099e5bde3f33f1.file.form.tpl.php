<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 16:14:21
         compiled from "/var/www/engine.loc/themes/engine/views/guides/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9374101875773c68b74a4e9-02621226%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ed73ff2e641272e6ac16d94909099e5bde3f33f1' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/guides/form.tpl',
      1 => 1467206060,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9374101875773c68b74a4e9-02621226',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5773c68b76f7e9_09044619',
  'variables' => 
  array (
    'content' => 0,
    'token' => 0,
    'admin' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5773c68b76f7e9_09044619')) {function content_5773c68b76f7e9_09044619($_smarty_tpl) {?><form action="guides/process/<?php if (isset($_smarty_tpl->tpl_vars['content']->value['id'])) {
echo $_smarty_tpl->tpl_vars['content']->value['id'];
}?>" method="post" id="guidesForm" class="form-horizontal">

    <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/meta.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="content[status]" value="published">
    <input type="hidden" name="content[owner_id]" value="<?php echo $_smarty_tpl->tpl_vars['admin']->value['id'];?>
">
    <input type="hidden" name="content[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['parent_id'];?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
</form><?php }} ?>
