<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-16 11:21:29
         compiled from "/var/www/engine.loc/themes/engine/views/seo/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:931184655762618941d061-64281195%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6a14b3be9b5421e9a9766db2a4eb87aca090c64d' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/seo/index.tpl',
      1 => 1466020694,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '931184655762618941d061-64281195',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'types' => 0,
    'com_url' => 0,
    'type' => 0,
    'languages' => 0,
    'lang' => 0,
    'data' => 0,
    't' => 0,
    'sys_info' => 0,
    'name' => 0,
    'v' => 0,
    'dir_perm' => 0,
    'k' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_576261895be266_94938098',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_576261895be266_94938098')) {function content_576261895be266_94938098($_smarty_tpl) {?><form id="form" action="seo/process" method="post"  class="form-horizontal row">
    <div><br></div>
    <div class="col-md-8 col-md-offset-2">
        <div id="tabs_seo">
            <ul>
                <?php  $_smarty_tpl->tpl_vars['type'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['type']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['types']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['type']->key => $_smarty_tpl->tpl_vars['type']->value) {
$_smarty_tpl->tpl_vars['type']->_loop = true;
?>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['com_url']->value;?>
#<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
"><?php echo $_smarty_tpl->tpl_vars['type']->value['name'];?>
</a></li>
                <?php } ?>
            </ul>
            <?php  $_smarty_tpl->tpl_vars['type'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['type']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['types']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['type']->key => $_smarty_tpl->tpl_vars['type']->value) {
$_smarty_tpl->tpl_vars['type']->_loop = true;
?>
                <div id="<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
">
                    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
                        <div class="form-group">
                            <label for="seo_<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_title" class="col-md-3 control-label required">Title (<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
)</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="seo[<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
][<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][title]" id="seo_<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
_title" value="<?php echo $_smarty_tpl->tpl_vars['data']->value[$_smarty_tpl->tpl_vars['type']->value['type']][$_smarty_tpl->tpl_vars['lang']->value['id']]['title'];?>
" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="seo_<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_keywords" class="col-md-3 control-label required">Keywords (<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
)</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="seo[<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
][<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][keywords]" id="seo_<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
_keywords" value="<?php echo $_smarty_tpl->tpl_vars['data']->value[$_smarty_tpl->tpl_vars['type']->value['type']][$_smarty_tpl->tpl_vars['lang']->value['id']]['keywords'];?>
"  required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="seo_<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_description" class="col-md-3 control-label required">Description (<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
)</label>
                            <div class="col-md-9">
                                <textarea class="form-control" name="seo[<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
][<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][description]" id="seo_<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
_description" required><?php echo $_smarty_tpl->tpl_vars['data']->value[$_smarty_tpl->tpl_vars['type']->value['type']][$_smarty_tpl->tpl_vars['lang']->value['id']]['description'];?>
</textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="seo_<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_h1" class="col-md-3 control-label required">Heading (<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
)</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="seo[<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
][<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][h1]" id="seo_<?php echo $_smarty_tpl->tpl_vars['type']->value['type'];?>
_h1" value="<?php echo $_smarty_tpl->tpl_vars['data']->value[$_smarty_tpl->tpl_vars['type']->value['type']][$_smarty_tpl->tpl_vars['lang']->value['id']]['h1'];?>
"  required>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
        
            <p>&nbsp;</p>
            <div class="alert alert-info alert-dismissible se-content" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <p style="text-align: center">Ви можете використовувати наступні блоки</p>
                <p>
                    <b>{title}</b> - заголовок сторінки,<br>
                    <b>{keywords}</b> - ключові слова сторінки,<br>
                    <b>{h1}</b> - заголовок першого рвіня сторінки,<br>
                    <b>{description}</b> - опис сторінки,<br>
                    <b>{company_name}</b> - Назва компанії,<br>
                    <b>{company_phone}</b> - телефон,<br>
                    <b>{category}</b> - категорія,<br>
                    <b>{delimiter}</b> - розділювач, напр "/"
                </p>
            </div>
        
    </div>

    <div class="col-md-8 col-md-offset-2">
        <div class="alert">
            <h3><?php echo $_smarty_tpl->tpl_vars['t']->value['seo']['sys_info'];?>
</h3>
            <ul>
                <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['sys_info']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value) {
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                    <?php $_smarty_tpl->tpl_vars["name"] = new Smarty_variable("sys_info_".((string)$_smarty_tpl->tpl_vars['k']->value), null, 0);?>
                    <li><?php echo $_smarty_tpl->tpl_vars['t']->value['seo'][$_smarty_tpl->tpl_vars['name']->value];?>
: <?php echo $_smarty_tpl->tpl_vars['v']->value;?>
</li>
                <?php } ?>
            </ul>

            <h3><?php echo $_smarty_tpl->tpl_vars['t']->value['seo']['dir_perm'];?>
</h3>
            <ul>
                <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['dir_perm']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value) {
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                    <li><?php echo $_smarty_tpl->tpl_vars['k']->value;?>
: <?php if ($_smarty_tpl->tpl_vars['v']->value==1) {
echo $_smarty_tpl->tpl_vars['t']->value['seo']['dir_perm_yes'];
} else {
echo $_smarty_tpl->tpl_vars['t']->value['seo']['dir_perm_no'];
}?></li>
                <?php } ?>
            </ul>
        </div>
    </div>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
</form><?php }} ?>
