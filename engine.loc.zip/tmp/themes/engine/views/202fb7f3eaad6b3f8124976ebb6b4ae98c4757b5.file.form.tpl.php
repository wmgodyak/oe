<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-23 14:59:20
         compiled from "/var/www/engine.loc/themes/engine/views/features/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:204391798556e6d35c45d583-56817434%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '202fb7f3eaad6b3f8124976ebb6b4ae98c4757b5' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/features/form.tpl',
      1 => 1458318072,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '204391798556e6d35c45d583-56817434',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56e6d35c560a83_96806375',
  'variables' => 
  array (
    'data' => 0,
    'plugins' => 0,
    't' => 0,
    'languages' => 0,
    'lang' => 0,
    'item' => 0,
    'item_name' => 0,
    'i' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e6d35c560a83_96806375')) {function content_56e6d35c560a83_96806375($_smarty_tpl) {?><form action="features/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal" >
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['top'])) {?>
        <div class="row">
            <div class="col-md-12">
                <?php echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['top']);?>

            </div>
        </div>
    <?php }?>
    <div class="row">
        <div class="col-md-8">
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['legend_main'];?>
</legend>
                <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
                    <div class="form-group">
                        <label for="name_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
)</label>
                        <div class="col-sm-9">
                            <input name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['name'];?>
">
                        </div>
                    </div>
                <?php } ?>
                <div class="form-group">
                    <label for="data_code" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['code'];?>
</label>
                    <div class="col-sm-9">
                        <input name="data[code]" id="data_code"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['code'];?>
">
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_type" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['type'];?>
</label>
                    <div class="col-md-9">
                        <select name="data[type]" id="data_type" class="form-control">
                            <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['data']->value['types']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['item']->key;
?>
                                <?php $_smarty_tpl->tpl_vars["item_name"] = new Smarty_variable("type_".((string)$_smarty_tpl->tpl_vars['item']->value), null, 0);?>
                                <option <?php if ($_smarty_tpl->tpl_vars['data']->value['type']==$_smarty_tpl->tpl_vars['item']->value) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['t']->value['features'][$_smarty_tpl->tpl_vars['item_name']->value];?>
</option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['main'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['main']);
}?>
            </fieldset>
        </div>
        <div class="col-md-4">
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['params'];?>
</legend>
                <div class="form-group">
                    <label for="data_status" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['status'];?>
</label>
                    <div class="col-md-9">
                        <select name="data[status]" id="data_status" class="form-control">
                            <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['data']->value['statuses']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['item']->key;
?>
                                <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>
                                <option <?php if ($_smarty_tpl->tpl_vars['data']->value['status']==$_smarty_tpl->tpl_vars['item']->value) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value;?>
</option>
                                <?php }?>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                        <div class="checkbox">
                            <label>
                                <input type="hidden" name="data[required]" value="0">
                                <input <?php if ($_smarty_tpl->tpl_vars['data']->value['required']==1) {?>checked<?php }?> type="checkbox" name="data[required]" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['required'];?>

                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group fg-show-filter" style="display: none">
                    <div class="col-md-9 col-md-offset-3">
                        <div class="checkbox">
                            <label>
                                <input type="hidden" name="data[on_filter]" value="0">
                                <input <?php if ($_smarty_tpl->tpl_vars['data']->value['on_filter']==1) {?>checked<?php }?> type="checkbox" name="data[on_filter]" id="data_on_filter" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['on_filter'];?>

                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group fg-multiple" style="display: none">
                    <div class="col-md-9 col-md-offset-3">
                        <div class="checkbox">
                            <label>
                                <input type="hidden" name="data[multiple]" value="0">
                                <input <?php if ($_smarty_tpl->tpl_vars['data']->value['multiple']==1) {?>checked<?php }?> type="checkbox" name="data[multiple]" id="data_multiple" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['multiple'];?>

                            </label>
                        </div>
                    </div>
                </div>

                <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['params'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['params']);
}?>
            </fieldset>

            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['show_on'];?>
 <a href="javascript:;" data-id="<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" class="b-features-select-ct"><i class="fa fa-list"></i></a></legend>
                <div id="content_types"></div>
            </fieldset>
        </div>
    </div>
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['bottom'])) {?>
        <div class="row">
            <div class="col-md-12">
                <?php echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['bottom']);?>

            </div>
        </div>
    <?php }?>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="data[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['parent_id'];?>
">
</form>
<?php echo '<script'; ?>
>var selected_content = <?php echo json_encode($_smarty_tpl->tpl_vars['data']->value['selected_content']);?>
<?php echo '</script'; ?>
>


    <?php echo '<script'; ?>
 type="text/template" id="ctList" >
        <table class="table table-bordered">
            <tr>
                <th>Тип</th>
                <th>Підтип</th>
                <th>Сторінка</th>
                <th>Видалити</th>
            </tr>
            <?php echo '<%'; ?>
 for(var i=0;i < items.length; i++) { <?php echo '%>'; ?>

            <tr id="f-sc-<?php echo '<%'; ?>
- items[i].id <?php echo '%>'; ?>
">
                <td><?php echo '<%'; ?>
- items[i].type <?php echo '%>'; ?>
</td>
                <td><?php echo '<%'; ?>
- items[i].subtype <?php echo '%>'; ?>
</td>
                <td><?php echo '<%'; ?>
- items[i].content <?php echo '%>'; ?>
</td>
                <td><a class="b-features-delete-ct" data-id="<?php echo '<%'; ?>
- items[i].id <?php echo '%>'; ?>
" title="Видалити" href="javascript:;"><i class="fa fa-remove"></i></a></td>
            </tr>
            <?php echo '<%'; ?>
 } <?php echo '%>'; ?>

        </table>
    <?php echo '</script'; ?>
>
<?php }} ?>
