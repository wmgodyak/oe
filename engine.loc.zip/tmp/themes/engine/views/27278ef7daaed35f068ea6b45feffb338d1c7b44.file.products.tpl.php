<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-04-01 09:40:22
         compiled from "/var/www/engine.loc/themes/engine/views/content/products.tpl" */ ?>
<?php /*%%SmartyHeaderCode:117192282956fe17d61d6699-48161586%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '27278ef7daaed35f068ea6b45feffb338d1c7b44' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/products.tpl',
      1 => 1458288060,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '117192282956fe17d61d6699-48161586',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'form_action' => 0,
    'form_success' => 0,
    'plugins' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fe17d62956a3_86630867',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fe17d62956a3_86630867')) {function content_56fe17d62956a3_86630867($_smarty_tpl) {?><form action="<?php echo $_smarty_tpl->tpl_vars['form_action']->value;?>
" method="post" id="form" class="form-horizontal" <?php if ($_smarty_tpl->tpl_vars['form_success']->value) {?>data-success = '<?php echo $_smarty_tpl->tpl_vars['form_success']->value;?>
'<?php }?>>
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['top'])) {?>
        <div class="row">
            <div class="col-md-12">
                <?php echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['top']);?>

            </div>
        </div>
    <?php }?>
    <div class="row">
        <div class="col-md-8">
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_main'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_main']);
}?>
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/meta.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_meta'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_meta']);
}?>
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/content.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_content'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_content']);
}?>
        </div>
        <div class="col-md-4">
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/params.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_params'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_params']);
}?>
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/features.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_features'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_features']);
}?>
        </div>
    </div>
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['bottom'])) {?>
        <div class="row">
            <div class="col-md-12">
                <?php echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['bottom']);?>

            </div>
        </div>
    <?php }?>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
</form><?php }} ?>
