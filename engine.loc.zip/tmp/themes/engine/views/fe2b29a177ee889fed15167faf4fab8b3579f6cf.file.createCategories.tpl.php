<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-18 09:28:44
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/content/posts/createCategories.tpl" */ ?>
<?php /*%%SmartyHeaderCode:129556519456eba70be45439-26902896%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fe2b29a177ee889fed15167faf4fab8b3579f6cf' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/content/posts/createCategories.tpl',
      1 => 1458286077,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '129556519456eba70be45439-26902896',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56eba70be45fc3_29050391',
  'variables' => 
  array (
    'content' => 0,
    'token' => 0,
    'admin' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56eba70be45fc3_29050391')) {function content_56eba70be45fc3_29050391($_smarty_tpl) {?><form action="./plugins/postsCategories/process/<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
" method="post" id="postCategoriesForm" class="form-horizontal">

    <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/meta.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="content[status]" value="published">
    <input type="hidden" name="content[owner_id]" value="<?php echo $_smarty_tpl->tpl_vars['admin']->value['id'];?>
">
    <input type="hidden" name="content[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['parent_id'];?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">

</form><?php }} ?>
