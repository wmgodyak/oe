<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-27 09:55:22
         compiled from "/var/www/engine.loc/themes/engine/views/blog/categories/tree.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13069626355770cddae05c00-50248643%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce9d94119551dc6bba9326b51784477605552865' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/blog/categories/tree.tpl',
      1 => 1467010151,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13069626355770cddae05c00-50248643',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    't' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5770cddae17154_08851489',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5770cddae17154_08851489')) {function content_5770cddae17154_08851489($_smarty_tpl) {?><div class="title">
    <i class="fa fa-pencil-square"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['blogCategories']['tree_title'];?>
</span>
    <button class="btn btn-link b-blog-categories-create" ><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</button>
</div>
<div class="pages-tree" id="blogCategories"></div><?php }} ?>
