<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-16 20:51:51
         compiled from "/var/www/engine.loc/themes/engine/views/content/images/sizes/edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11114971855762e6457c3382-86900545%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd8b9cda94f67712d1825b139ce39807f5a9a9e8d' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/images/sizes/edit.tpl',
      1 => 1466099508,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11114971855762e6457c3382-86900545',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5762e6458388e7_99426712',
  'variables' => 
  array (
    'data' => 0,
    't' => 0,
    'action' => 0,
    'types' => 0,
    'item' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5762e6458388e7_99426712')) {function content_5762e6458388e7_99426712($_smarty_tpl) {?><form action="./contentImagesSizes/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal">
    <div class="form-group">
        <label for="data_size" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImagesSizes']['size'];?>
</label>
        <div class="col-sm-9">
            <input <?php if ($_smarty_tpl->tpl_vars['action']->value=='edit') {?>readonly<?php }?> name="data[size]" id="data_size"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['size'])) {
echo $_smarty_tpl->tpl_vars['data']->value['size'];
}?>" required>
        </div>
    </div>
    <div class="form-group">
        <label for="data_width" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImagesSizes']['width'];?>
</label>
        <div class="col-sm-9">
            <input name="data[width]" id="data_width"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['width'])) {
echo $_smarty_tpl->tpl_vars['data']->value['width'];
}?>" required onchange="this.value = parseInt(this.value); if (this.value == 'NaN') this.value=0">
        </div>
    </div>
    <div class="form-group">
        <label for="data_height" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImagesSizes']['height'];?>
</label>
        <div class="col-sm-9">
            <input name="data[height]" id="data_height"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['height'])) {
echo $_smarty_tpl->tpl_vars['data']->value['height'];
}?>" required onchange="this.value = parseInt(this.value); if (this.value == 'NaN') this.value=0">
        </div>
    </div>
    <div class="form-group">
        <label for="types" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImagesSizes']['types'];?>
</label>
        <div class="col-sm-9">
            <select name="types[]" multiple id="content_types"  class="form-control" required>
                <?php  $_smarty_tpl->tpl_vars['t'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['t']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['types']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['t']->key => $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->_loop = true;
?>
                    <option  <?php if (in_array($_smarty_tpl->tpl_vars['t']->value['id'],$_smarty_tpl->tpl_vars['data']->value['types'])) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['t']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
</option>
                    <?php if ($_smarty_tpl->tpl_vars['t']->value['isfolder']) {?>
                        <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['t']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                            <option <?php if (in_array($_smarty_tpl->tpl_vars['item']->value['id'],$_smarty_tpl->tpl_vars['data']->value['types'])) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['t']->value['name'];?>
 / <?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
                        <?php } ?>
                    <?php }?>
                <?php } ?>
            </select>
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
</form><?php }} ?>
