<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-29 12:14:05
         compiled from "/var/www/engine.loc/themes/engine/views/mail_templates/edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:36886389356ebd679e1ec30-60166321%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9a0fab6a5e1a2d388a1171b2fb59fd516d56d494' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/mail_templates/edit.tpl',
      1 => 1458318072,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '36886389356ebd679e1ec30-60166321',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56ebd679e61d92_07205540',
  'variables' => 
  array (
    'data' => 0,
    't' => 0,
    'languages' => 0,
    'i' => 0,
    'lang' => 0,
    'token' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56ebd679e61d92_07205540')) {function content_56ebd679e61d92_07205540($_smarty_tpl) {?><form action="./mailTemplates/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal">
    <div class="form-group">
        <label for="data_code" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['mailTemplates']['name'];?>
</label>
        <div class="col-sm-9">
            <input name="data[name]" id="data_name"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
" required>
        </div>
    </div>
    <div class="form-group">
        <label for="data_code" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['mailTemplates']['code'];?>
</label>
        <div class="col-sm-9">
            <input name="data[code]" id="data_code"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['code'];?>
" required>
        </div>
    </div>

    <?php if (count($_smarty_tpl->tpl_vars['languages']->value)>1) {?>
        <div class="form-group">
            <label class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['lang'];?>
</label>
            <div class="btn-group col-md-9" id="switchLanguages" role="group">
                <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['lang']->key;
?>
                    <button type="button" class="btn <?php if ($_smarty_tpl->tpl_vars['i']->value==0) {?>btn-primary<?php }?>" data-code="<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
"><?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
</button>
                <?php } ?>
            </div>
        </div>
    <?php }?>
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['lang']->key;
?>
        <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
            <label for="subject_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['mailTemplates']['subject'];?>
</label>
            <div class="col-sm-9">
                <input name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][subject]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="subject_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['subject'];?>
" >
            </div>
        </div>
        <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
            <label for="body_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['mailTemplates']['body'];?>
</label>
            <div class="col-sm-9">
                <textarea style="height: 500px;" name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][body]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="info_body_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control ckeditor" ><?php echo $_smarty_tpl->tpl_vars['data']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['body'];?>
</textarea>
            </div>
        </div>
    <?php } ?>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
</form><?php }} ?>
