<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 09:44:28
         compiled from "/var/www/engine.loc/themes/engine/views/content/images/upload.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1397461153577a7046934656-84139101%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4f02d6a8f7d1bb72514dea7d5b1eab09062d0aa8' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/images/upload.tpl',
      1 => 1467657207,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1397461153577a7046934656-84139101',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577a7046950120_29388479',
  'variables' => 
  array (
    't' => 0,
    'id' => 0,
    'images' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577a7046950120_29388479')) {function content_577a7046950120_29388479($_smarty_tpl) {?><fieldset class="gallery-uploader">
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImages']['image'];?>

    <a href="javascript:;" class="add insert">
        <i class="fa fa-plus-circle"></i>
        <span><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</span>
    </a>
    <a href="javascript:;" class="add finished">
        <i class="fa fa-minus-circle"></i>
        <span><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImages']['remove'];?>
</span>
    </a>
    </legend>
    <div class="list-group">
        <div class="list-group-item dropzone-container">
            <div class="form-group">
                <div id="contentImagesDz" data-target="contentImages/upload/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
                    <div class="dz-message clearfix">
                        <i class="fa fa-picture-o"></i>
                        <span><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImages']['upload_i'];?>
</span>
                        <div class="hover">
                            <i class="fa fa-download"></i>
                            <span><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImages']['dragHere'];?>
</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="list-group-item preview-container">
            <div class="form-group">
                <div class="gallery-container"></div>
            </div>
        </div>
    </div>
</fieldset>

<?php echo '<script'; ?>
 type="text/template" id="dzTemplate" >
    <div class="dz-preview dz-file-preview" id='im-{id}'>
    <div class="dz-details">
            <img data-dz-thumbnail src="{src}"/>
            <div class="overlay">
                <div class="dz-filename text-overflow-hidden"><span data-dz-name></span></div>
                <div class="status">
                        <a class="dz-error-mark remove-item" href="javascript:;"><i class="icon-remove-sign"></i></a>
                        <div class="dz-error-message">Помилка <span data-dz-errormessage></span></div>
                </div>
                <div class="controls clearfix">
                        <a title="Обрізати" data-id="{id}" class="crop-image" href="javascript:;"><i class="fa fa-crop"></i></a>
                        <a title="Видалити" class="trash-item" href="javascript:;"><i class="fa fa-trash"></i></a>
                </div>
                <div class="controls confirm-removal clearfix">
                    <a data-id="{id}" class="remove-item" href="javascript:;">Так</a>
                    <a class="remove-cancel" href="javascript:;">Ні</a>
                </div>
                </div>
            </div>
            <div class="dz-progress"><span class="dz-upload" data-dz-uploadprogress></span></div>
    </div>
<?php echo '</script'; ?>
>


<?php echo '<script'; ?>
>
    var contentImagesList = <?php echo $_smarty_tpl->tpl_vars['images']->value;?>
;
 <?php echo '</script'; ?>
><?php }} ?>
