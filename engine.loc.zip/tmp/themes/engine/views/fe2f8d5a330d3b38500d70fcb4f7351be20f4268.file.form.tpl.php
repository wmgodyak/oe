<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-24 14:35:24
         compiled from "/var/www/engine.loc/themes/engine/views/callbacks/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2074033084576d0dc083a3f8-86733303%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fe2f8d5a330d3b38500d70fcb4f7351be20f4268' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/callbacks/form.tpl',
      1 => 1466768120,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2074033084576d0dc083a3f8-86733303',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_576d0dc08716a3_35375745',
  'variables' => 
  array (
    'data' => 0,
    't' => 0,
    'statuses' => 0,
    's' => 0,
    'token' => 0,
    'admin' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_576d0dc08716a3_35375745')) {function content_576d0dc08716a3_35375745($_smarty_tpl) {?><form action="module/run/callbacks/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal">
    <div class="form-group">
        <label class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['callbacks']['pib'];?>
</label>
        <div class="col-md-9">
            <?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
, тел:<?php echo $_smarty_tpl->tpl_vars['data']->value['phone'];?>

        </div>
    </div>
    <div class="form-group">
        <label for="data_message" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['callbacks']['message'];?>
</label>
        <div class="col-md-9">
            <?php echo $_smarty_tpl->tpl_vars['data']->value['message'];?>

        </div>
    </div>
    <div class="form-group">
        <label for="data_message" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['callbacks']['comment'];?>
</label>
        <div class="col-md-9">
            <textarea name="data[comment]" id="data_comment" class="form-control" style="height: 150px;" placeholder="<?php echo $_smarty_tpl->tpl_vars['t']->value['callbacks']['comment_not_r'];?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value['comment'];?>
</textarea>
        </div>
    </div>

    <div class="form-group">
        <label for="data_message" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['callbacks']['status'];?>
</label>
        <div class="col-md-9">
            <select name="data[status]" id="data_status">
                <?php  $_smarty_tpl->tpl_vars['s'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['s']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['statuses']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['s']->key => $_smarty_tpl->tpl_vars['s']->value) {
$_smarty_tpl->tpl_vars['s']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['s']->key;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['s']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['data']->value['status']==$_smarty_tpl->tpl_vars['s']->value) {?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['s']->value;?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>


    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="data[status]" value="processed">
    <input type="hidden" name="data[manager_id]" value="<?php echo $_smarty_tpl->tpl_vars['admin']->value['id'];?>
">
</form><?php }} ?>
