<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 15:38:45
         compiled from "/var/www/engine.loc/themes/engine/views/shop/products/variants/create.tpl" */ ?>
<?php /*%%SmartyHeaderCode:312714660577a1d130eae95-79116221%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd5b1ada1b0083697d6214c824d054cd0d682aa71' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/products/variants/create.tpl',
      1 => 1467635922,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '312714660577a1d130eae95-79116221',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577a1d1310c7b8_15862073',
  'variables' => 
  array (
    'content_id' => 0,
    'features' => 0,
    'item' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577a1d1310c7b8_15862073')) {function content_577a1d1310c7b8_15862073($_smarty_tpl) {?><form action="module/run/shop/products/variants/create/<?php echo $_smarty_tpl->tpl_vars['content_id']->value;?>
" method="post" id="productsVariantsForm" class="form-horizontal">
    <p>Згенеруйте варіанти товарів на основі вибраних властивостей. <b>Зверніть увагу!!!</b> Раніше створені варіанти <b>будуть видалені</b></p>
    <div class="form-group">
        <div class="col-md-12">
            <select name="features[]" multiple class="form-control variants-feature" required data-placeholder="Виберіть властивості">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['features']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="add">
</form><?php }} ?>
