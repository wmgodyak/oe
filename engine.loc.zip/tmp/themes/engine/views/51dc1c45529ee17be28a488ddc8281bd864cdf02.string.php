<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-31 11:56:16
         compiled from "51dc1c45529ee17be28a488ddc8281bd864cdf02" */ ?>
<?php /*%%SmartyHeaderCode:36597765656fce630da89e9-80867950%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '51dc1c45529ee17be28a488ddc8281bd864cdf02' => 
    array (
      0 => '51dc1c45529ee17be28a488ddc8281bd864cdf02',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '36597765656fce630da89e9-80867950',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fce630dc08a2_97805803',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fce630dc08a2_97805803')) {function content_56fce630dc08a2_97805803($_smarty_tpl) {?><p>Вітаємо <?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
. Ви отримали це повідомлення, так як слідкуєте за коментарями до статті <?php echo $_smarty_tpl->tpl_vars['data']->value['page_name'];?>
.</p>

<p>Ви можете <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['page_url'];?>
">переглянути його тут</a>.</p>
<?php }} ?>
