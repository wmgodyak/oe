<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-27 14:09:37
         compiled from "/var/www/engine.loc/themes/engine/views/comments/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:193315965457710971cc2c84-67815960%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7a7cded5032a24ecd8a5e1d18e933eccf6e01d9b' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/comments/index.tpl',
      1 => 1467010151,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '193315965457710971cc2c84-67815960',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57710971cdcc82_74870573',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57710971cdcc82_74870573')) {function content_57710971cdcc82_74870573($_smarty_tpl) {?><div id="tabs">
    <ul>
        
        <li><a href="module/run/comments/tab/new">Нові</a></li>
        <li><a href="module/run/comments/tab/spam">Спам</a></li>
        <li><a href="module/run/comments/tab/approved">Опубліковані</a></li>
    </ul>
</div>
<?php }} ?>
