<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-18 01:18:23
         compiled from "/var/www/engine.loc/themes/engine/views/contentFeatures/create.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18650237545764772f3b1b72-84466352%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd974b0a23880ef1cd2688cb12c0407f9055f283d' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/contentFeatures/create.tpl',
      1 => 1466020694,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18650237545764772f3b1b72-84466352',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'languages' => 0,
    'lang' => 0,
    't' => 0,
    'types' => 0,
    'item' => 0,
    'item_name' => 0,
    'token' => 0,
    'data' => 0,
    'content_id' => 0,
    'disable_values' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5764772f547ae9_02396799',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5764772f547ae9_02396799')) {function content_5764772f547ae9_02396799($_smarty_tpl) {?><form action="contentFeatures/process" method="post" id="formContentFeatures" class="form-horizontal" >
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="f_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
)</label>
            <div class="col-md-10">
                <input name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="f_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control f-info-name" data-lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
">
            </div>
        </div>
    <?php } ?>
    <div class="form-group">
        <label for="f_data_code" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['code'];?>
</label>
        <div class="col-md-10">
            <input name="data[code]" id="f_data_code"  class="form-control">
        </div>
    </div>
    <div class="form-group">
        <label for="data_type" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['type'];?>
</label>
        <div class="col-md-10">
            <select name="data[type]" id="data_type" class="form-control">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['types']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['item']->key;
?>
                    <?php $_smarty_tpl->tpl_vars["item_name"] = new Smarty_variable("type_".((string)$_smarty_tpl->tpl_vars['item']->value), null, 0);?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['item']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['t']->value['features'][$_smarty_tpl->tpl_vars['item_name']->value];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="form-group fg-multiple" style="display: none">
        <div class="col-md-10 col-md-offset-2">
            <div class="checkbox">
                <label>
                    <input type="hidden" name="data[multiple]" value="0">
                    <input type="checkbox" name="data[multiple]" id="data_multiple" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['multiple'];?>

                </label>
            </div>
        </div>
    </div>
    <div class="form-group fg-show-filter" style="display: none">
        <div class="col-md-10 col-md-offset-2">
            <div class="checkbox">
                <label>
                    <input type="hidden" name="data[on_filter]" value="0">
                    <input type="checkbox" name="data[on_filter]" id="data_on_filter" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['on_filter'];?>

                </label>
            </div>
        </div>
    </div>


    <div class="form-group">
        <div class="col-md-10 col-md-offset-2">
            <div class="checkbox">
                <label>
                    <input type="hidden" name="data[required]" value="0">
                    <input type="checkbox" name="data[required]" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['common']['required'];?>

                </label>
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-10 col-md-offset-2">
            <div class="checkbox">
                <label>
                    <input type="hidden" name="page_only" value="0">
                    <input type="checkbox" name="page_only" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['only_this_page'];?>

                </label>
            </div>
        </div>
    </div>


    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="data[status]" value="published">
    <input type="hidden" name="data[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['parent_id'];?>
">

    <input type="hidden" name="content_id" value="<?php echo $_smarty_tpl->tpl_vars['content_id']->value;?>
">
    <input type="hidden" name="disable_values" value="<?php echo $_smarty_tpl->tpl_vars['disable_values']->value;?>
">

</form><?php }} ?>
