<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-01-14 13:49:59
         compiled from "/var/www/engine.loc/themes/engine/views/components/install.tpl" */ ?>
<?php /*%%SmartyHeaderCode:179601866056978b67ea7976-40806996%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '435232699de232ba82d6f3f09571612556858d00' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/components/install.tpl',
      1 => 1452772197,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '179601866056978b67ea7976-40806996',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56978b67eb4392_36519917',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56978b67eb4392_36519917')) {function content_56978b67eb4392_36519917($_smarty_tpl) {?>qweqwe<?php }} ?>
