<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-17 10:49:13
         compiled from "/var/www/engine.loc/themes/engine/views/themes/tree.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3411612435763ab7949fa33-43022143%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bf70593bd6ae9f9fd0e01ca95dc49b450561190f' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/themes/tree.tpl',
      1 => 1460475860,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3411612435763ab7949fa33-43022143',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5763ab794aab31_76686813',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5763ab794aab31_76686813')) {function content_5763ab794aab31_76686813($_smarty_tpl) {?><div class="title">
    <i class="fa fa-files-o"></i>
    <span>Структура теми</span>
</div>
<div class="pages-tree" id="themesTree">

</div><?php }} ?>
