<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-30 16:02:00
         compiled from "/var/www/engine.loc/themes/engine/views/features/value.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14460857195762dbb6e61d01-83584805%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f132cfb79506252dd7e37e454786cf41b6f6ccdc' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/features/value.tpl',
      1 => 1467291657,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14460857195762dbb6e61d01-83584805',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5762dbb6e8ba23_64952561',
  'variables' => 
  array (
    'languages' => 0,
    'lang' => 0,
    't' => 0,
    'data' => 0,
    'token' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5762dbb6e8ba23_64952561')) {function content_5762dbb6e8ba23_64952561($_smarty_tpl) {?><form action="features/values/process" method="post" id="formFeaturesValue" class="form-horizontal">
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="name_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
)</label>
            <div class="col-sm-9">
                <input name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control info-name" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['name'])) {
echo $_smarty_tpl->tpl_vars['data']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['name'];
}?>">
            </div>
        </div>
    <?php } ?>
    

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
    <?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {?>
    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
">
    <?php }?>
    <?php if (isset($_smarty_tpl->tpl_vars['data']->value['parent_id'])) {?>
    <input type="hidden" name="data[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['parent_id'];?>
">
    <?php }?>
    <input type="hidden" name="data[type]" value="value">
    <input type="hidden" name="data[status]" value="published">
</form><?php }} ?>
