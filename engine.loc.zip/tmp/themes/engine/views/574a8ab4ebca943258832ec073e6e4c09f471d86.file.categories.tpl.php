<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-04-01 10:04:00
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/shop/categories.tpl" */ ?>
<?php /*%%SmartyHeaderCode:136502310956fe1d4dece2f2-84500499%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '574a8ab4ebca943258832ec073e6e4c09f471d86' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/shop/categories.tpl',
      1 => 1459494240,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '136502310956fe1d4dece2f2-84500499',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fe1d4dee5847_13896321',
  'variables' => 
  array (
    'tree_icon' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fe1d4dee5847_13896321')) {function content_56fe1d4dee5847_13896321($_smarty_tpl) {?><div class="title">
    <i class="fa <?php echo $_smarty_tpl->tpl_vars['tree_icon']->value;?>
"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['productsCategories']['tree_title'];?>
</span>
    <button class="btn btn-link b-products-categories-create" ><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</button>
</div>
<div class="pages-tree" id="productsCategories"></div><?php }} ?>
