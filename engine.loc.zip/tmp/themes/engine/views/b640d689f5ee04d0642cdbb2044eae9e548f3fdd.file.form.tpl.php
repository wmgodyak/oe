<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-28 11:53:57
         compiled from "/var/www/engine.loc/themes/engine/views/customers/groups/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:163991667156f8edabd5cc51-08813675%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b640d689f5ee04d0642cdbb2044eae9e548f3fdd' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/customers/groups/form.tpl',
      1 => 1459155235,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '163991667156f8edabd5cc51-08813675',
  'function' => 
  array (
    'renderSelect' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f8edabda4871_31193688',
  'variables' => 
  array (
    'items' => 0,
    'item' => 0,
    'parent' => 0,
    'data' => 0,
    't' => 0,
    'groups' => 0,
    'group' => 0,
    'languages' => 0,
    'lang' => 0,
    'info' => 0,
    'action' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => 0,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f8edabda4871_31193688')) {function content_56f8edabda4871_31193688($_smarty_tpl) {?><?php if (!function_exists('smarty_template_function_renderSelect')) {
    function smarty_template_function_renderSelect($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderSelect']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
    <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
        <option value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php if ($_smarty_tpl->tpl_vars['parent']->value) {
echo $_smarty_tpl->tpl_vars['parent']->value;?>
 / <?php }
echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
        <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
            <?php smarty_template_function_renderSelect($_smarty_tpl,array('items'=>$_smarty_tpl->tpl_vars['item']->value['items'],'parent'=>$_smarty_tpl->tpl_vars['item']->value['name']));?>

        <?php }?>
    <?php } ?>
<?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>

<form class="form-horizontal" action="plugins/customersGroup/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="customersGroupForm">
    <div class="form-group">
        <label for="data_parent_id" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['customers_group']['parent'];?>
</label>
        <div class="col-sm-9">
            <select class="form-control" name="data[parent_id]" id="data_parent_id">
                <option value="0">--</option>
                <?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value) {
$_smarty_tpl->tpl_vars['group']->_loop = true;
?>
                    <option <?php if ($_smarty_tpl->tpl_vars['data']->value['id']==$_smarty_tpl->tpl_vars['group']->value['id']) {?>disabled<?php }?> <?php if ($_smarty_tpl->tpl_vars['data']->value['parent_id']==$_smarty_tpl->tpl_vars['group']->value['id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['group']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['group']->value['name'];?>
</option>
                    <?php if ($_smarty_tpl->tpl_vars['group']->value['isfolder']) {?>
                        <?php smarty_template_function_renderSelect($_smarty_tpl,array('items'=>$_smarty_tpl->tpl_vars['items']->value));?>

                    <?php }?>
                <?php } ?>
            </select>
        </div>
    </div>
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
    <div class="form-group">
        <label for="info_name_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['customers_group']['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
)</label>
        <div class="col-sm-9">
            <input type="tel" class="form-control" name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]" id="info_name_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['info']->value[$_smarty_tpl->tpl_vars['lang']->value['id']]['name'];?>
" required>
        </div>
    </div>
    <?php } ?>
    <div class="form-group">
        <label for="data_phone" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['customers_group']['rang'];?>
</label>
        <div class="col-sm-9">
            <input type="tel" class="form-control" name="data[rang]" id="data_rang" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['rang'];?>
" required placeholder="101 - 999">
        </div>
    </div>

    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="a" value="1">
</form><?php }} ?>
