<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 09:53:26
         compiled from "/var/www/engine.loc/themes/engine/views/blog/tags.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20322910657736fdec23d81-73475695%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '47b1385a3fb22f3e36fdf6c22ed447fa76fe6bff' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/blog/tags.tpl',
      1 => 1467488193,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20322910657736fdec23d81-73475695',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57736fdec394e4_45006141',
  'variables' => 
  array (
    'languages' => 0,
    'lang' => 0,
    'posts_tags' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57736fdec394e4_45006141')) {function content_57736fdec394e4_45006141($_smarty_tpl) {?><fieldset>
    <legend>Мітки</legend>
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="content_published" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
</label>
            <div class="col-md-9">
                <input data-role="tagsinput" type="text" name="tags[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
]" id="tags_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" value="<?php if (isset($_smarty_tpl->tpl_vars['posts_tags']->value[$_smarty_tpl->tpl_vars['lang']->value['id']])) {
echo implode(',',$_smarty_tpl->tpl_vars['posts_tags']->value[$_smarty_tpl->tpl_vars['lang']->value['id']]);
}?>" class="tags-input form-control">
            </div>
        </div>
    <?php } ?>
</fieldset><?php }} ?>
