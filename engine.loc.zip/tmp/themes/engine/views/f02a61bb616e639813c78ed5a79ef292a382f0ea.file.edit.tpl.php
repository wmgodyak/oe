<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-17 10:49:13
         compiled from "/var/www/engine.loc/themes/engine/views/themes/edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8020701095763ab794ad6e4-63722053%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f02a61bb616e639813c78ed5a79ef292a382f0ea' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/themes/edit.tpl',
      1 => 1466146067,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8020701095763ab794ad6e4-63722053',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'error' => 0,
    'img' => 0,
    'source' => 0,
    'path' => 0,
    'token' => 0,
    'theme' => 0,
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5763ab794e3455_85715255',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5763ab794e3455_85715255')) {function content_5763ab794e3455_85715255($_smarty_tpl) {?><?php if (isset($_smarty_tpl->tpl_vars['error']->value)) {?>
    <div class="alert alert-error"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</div>
<?php }?>
<?php if (isset($_smarty_tpl->tpl_vars['img']->value)) {?>
    <div class="row col-md-8 col-md-offset-2"><img src="<?php echo $_smarty_tpl->tpl_vars['img']->value;?>
" style="max-width: 100%;" alt=""></div>
<?php }?>
<?php if (isset($_smarty_tpl->tpl_vars['source']->value)) {?>
<form id="form" action="themes/updateSource" method="post"  class="form-horizontal">
    <div class="row">
        <div class="col-md-12">
            <div class="response"></div>
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['path']->value;?>
</legend>
                <div class="form-group">
                    <div class="col-sm-12">
                        <textarea name="source" id="source" style="width: 100%; height: 500px;"><?php echo $_smarty_tpl->tpl_vars['source']->value;?>
</textarea>
                    </div>
                </div>
            </fieldset>
        </div>
    </div>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="path" value="<?php echo $_smarty_tpl->tpl_vars['path']->value;?>
">
    <input type="hidden" name="theme" value="<?php echo $_smarty_tpl->tpl_vars['theme']->value;?>
">
</form>

    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/lib/codemirror.css">
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/lib/codemirror.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/css.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/php.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/htmlmixed.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/sql.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/javascript.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        var cm = CodeMirror.fromTextArea(document.getElementById('source'), {
            theme: 'neo',
//                        mode: 'htmlmixed',
            styleActiveLine: true,
            lineNumbers: true,
            lineWrapping: true,
            autoCloseTags: true,
            matchBrackets: true
        });

        cm.on("change", function() {
            cm.save();
            var c = cm.getValue();
            $("textarea#source").html(c);
        });
    <?php echo '</script'; ?>
>
<?php }?>
<?php echo '<script'; ?>
>
    $(document).ready(function(){
        var  $tree = new engine.tree('themesTree');
        $tree.setUrl('./themes/tree/<?php echo $_smarty_tpl->tpl_vars['theme']->value;?>
').init();
        engine.validateAjaxForm('#adminLogin', function (res) {
            engine.alert(d.m, res.s > 0 ? 'success' : 'error');
        });
    });
<?php echo '</script'; ?>
><?php }} ?>
