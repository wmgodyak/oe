<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-23 16:10:51
         compiled from "/var/www/engine.loc/themes/engine/views/modules/edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:60369465856f2a3bef375c5-53451610%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6ab6bd5b8d6e78b75e8cfe2f0f0a00226c328367' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/modules/edit.tpl',
      1 => 1458742248,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '60369465856f2a3bef375c5-53451610',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f2a3bf0284a5_69303991',
  'variables' => 
  array (
    'data' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f2a3bf0284a5_69303991')) {function content_56f2a3bf0284a5_69303991($_smarty_tpl) {?><form action="./modules/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal">

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="update">
</form><?php }} ?>
