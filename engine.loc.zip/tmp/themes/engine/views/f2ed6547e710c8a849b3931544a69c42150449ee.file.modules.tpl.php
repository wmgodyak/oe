<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-23 18:09:32
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/content/pages/modules.tpl" */ ?>
<?php /*%%SmartyHeaderCode:136935749756f2ba88908f47-97543318%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f2ed6547e710c8a849b3931544a69c42150449ee' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/content/pages/modules.tpl',
      1 => 1458749372,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '136935749756f2ba88908f47-97543318',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f2ba88949004_98228594',
  'variables' => 
  array (
    't' => 0,
    'modules' => 0,
    'module' => 0,
    'a' => 0,
    'ps' => 0,
    'ac' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f2ba88949004_98228594')) {function content_56f2ba88949004_98228594($_smarty_tpl) {?><div class="form-group">
    <label for="settings_parent_id" class="col-md-3 control-label">
        <?php echo $_smarty_tpl->tpl_vars['t']->value['contentTypes']['modules'];?>

    </label>
    <div class="col-md-9">
        
        <select name="content[settings][modules][]" id="settingsModules" class="form-control" multiple>
            <?php  $_smarty_tpl->tpl_vars['a'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['a']->_loop = false;
 $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['modules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['a']->key => $_smarty_tpl->tpl_vars['a']->value) {
$_smarty_tpl->tpl_vars['a']->_loop = true;
 $_smarty_tpl->tpl_vars['module']->value = $_smarty_tpl->tpl_vars['a']->key;
?>
                <optgroup label="<?php echo $_smarty_tpl->tpl_vars['module']->value;?>
">
                    <?php  $_smarty_tpl->tpl_vars['ac'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['ac']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['a']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['ac']->key => $_smarty_tpl->tpl_vars['ac']->value) {
$_smarty_tpl->tpl_vars['ac']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['ac']->key;
?>
                        <option <?php if ($_smarty_tpl->tpl_vars['ps']->value['modules']&&in_array($_smarty_tpl->tpl_vars['ac']->value,$_smarty_tpl->tpl_vars['ps']->value['modules'])) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['ac']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['ac']->value;?>
</option>
                    <?php } ?>
                </optgroup>
            <?php } ?>
        </select>
        <p class="help-block"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentTypes']['modules_i'];?>
</p>
    </div>
</div><?php }} ?>
