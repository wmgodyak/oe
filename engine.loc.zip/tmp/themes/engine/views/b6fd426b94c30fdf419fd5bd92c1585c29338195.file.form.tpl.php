<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-21 14:13:09
         compiled from "/var/www/engine.loc/themes/engine/views/chunks/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:83901118356d95c17944627-67795668%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b6fd426b94c30fdf419fd5bd92c1585c29338195' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/chunks/form.tpl',
      1 => 1458315778,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '83901118356d95c17944627-67795668',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56d95c179e4f11_53177776',
  'variables' => 
  array (
    'data' => 0,
    'action' => 0,
    't' => 0,
    'template' => 0,
    'token' => 0,
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d95c179e4f11_53177776')) {function content_56d95c179e4f11_53177776($_smarty_tpl) {?><form class="form-horizontal" action="chunks/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"  method="post" id="form" data-success="engine.chunks.on<?php echo ucfirst($_smarty_tpl->tpl_vars['action']->value);?>
Success">
    <div class="row">
        <div class="col-md-9">
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['legend_main'];?>
</legend>
                <div class="form-group">
                    <label for="data_name" class="col-sm-3 control-label required"><?php echo $_smarty_tpl->tpl_vars['t']->value['chunks']['name'];?>
</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="data[name]" id="data_name" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
" required placeholder="[a-zA-Zа-яА-Я0-9]+">
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_template" class="col-sm-3 control-label required"><?php echo $_smarty_tpl->tpl_vars['t']->value['chunks']['type'];?>
</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="data[template]" id="data_template" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['template'];?>
" required placeholder="[a-z0-9]+">
                    </div>
                </div>
            </fieldset>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['chunks']['template_source'];?>
</legend>
                <div class="form-group">
                    <div class="col-sm-12">
                        <textarea name="template" id="template" style="width: 100%; height: 500px;"><?php echo $_smarty_tpl->tpl_vars['template']->value;?>
</textarea>
                    </div>
                </div>
            </fieldset>
        </div>
    </div>

     <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
     <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
     <input type="hidden" name="data[id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/lib/codemirror.css">
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/lib/codemirror.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/css.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/php.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/htmlmixed.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/sql.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/javascript.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        var cm = CodeMirror.fromTextArea(document.getElementById('template'), {
            theme: 'neo',
//                        mode: 'htmlmixed',
            styleActiveLine: true,
            lineNumbers: true,
            lineWrapping: true,
            autoCloseTags: true,
            matchBrackets: true
        });

        cm.on("change", function() {
        cm.save();
        var c = cm.getValue();
        $("textarea#template").html(c);
        });
    <?php echo '</script'; ?>
>
</form><?php }} ?>
