<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 09:51:10
         compiled from "/var/www/engine.loc/themes/engine/views/comments/post.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16914454145770cde0dbb5a6-34216018%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4c8444d4943671c08bd3291ab26b05cae4716749' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/comments/post.tpl',
      1 => 1467182691,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16914454145770cde0dbb5a6-34216018',
  'function' => 
  array (
    'renderComment' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5770cde0dfd936_93334518',
  'variables' => 
  array (
    'offset' => 0,
    'item' => 0,
    'c' => 0,
    'comments' => 0,
    'comments_total' => 0,
  ),
  'has_nocache_code' => 0,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5770cde0dfd936_93334518')) {function content_5770cde0dfd936_93334518($_smarty_tpl) {?><?php if (!function_exists('smarty_template_function_renderComment')) {
    function smarty_template_function_renderComment($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderComment']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
    <div class="col-md-<?php echo (12-$_smarty_tpl->tpl_vars['offset']->value);?>
 col-md-offset-<?php echo $_smarty_tpl->tpl_vars['offset']->value;?>
">
        <p><small>Додано: <?php echo $_smarty_tpl->tpl_vars['item']->value['created'];?>
</small></p>
        <p><?php echo $_smarty_tpl->tpl_vars['item']->value['message'];?>
</p>
        <p><small>Автор: <?php echo $_smarty_tpl->tpl_vars['item']->value['user']['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['user']['surname'];?>
</small></p>
        <hr>
    </div>
    <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
        <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
            <?php smarty_template_function_renderComment($_smarty_tpl,array('item'=>$_smarty_tpl->tpl_vars['c']->value,'offset'=>$_smarty_tpl->tpl_vars['offset']->value+1));?>

        <?php } ?>
    <?php }?>
<?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>


<?php if (count($_smarty_tpl->tpl_vars['comments']->value)) {?>
    <fieldset>
        <legend>Коментарі (<?php echo $_smarty_tpl->tpl_vars['comments_total']->value;?>
)</legend>

        <div class="row">
            <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['comments']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                <?php smarty_template_function_renderComment($_smarty_tpl,array('item'=>$_smarty_tpl->tpl_vars['item']->value,'offset'=>0));?>

            <?php } ?>
        </div>
    </fieldset>
<?php }?><?php }} ?>
