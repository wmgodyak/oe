<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-04-01 13:40:36
         compiled from "/var/www/engine.loc/themes/engine/views/currency/edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6113172356fe4eb21fe8f9-11260588%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ac087869755bda670256f1b310ffe3f29ada59ce' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/currency/edit.tpl',
      1 => 1459507234,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6113172356fe4eb21fe8f9-11260588',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fe4eb2235431_45488085',
  'variables' => 
  array (
    'data' => 0,
    't' => 0,
    'token' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fe4eb2235431_45488085')) {function content_56fe4eb2235431_45488085($_smarty_tpl) {?><form action="./currency/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal">
   <div class="form-group">
        <label for="data_name" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['currency']['name'];?>
</label>
        <div class="col-sm-9">
            <input name="data[name]" id="data_name"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
" placeholder="Гривня">
        </div>
    </div>
   <div class="form-group">
        <label for="data_code" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['currency']['code'];?>
</label>
        <div class="col-sm-9">
            <input name="data[code]" id="data_code"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['code'];?>
" placeholder="UAH">
        </div>
    </div>
   <div class="form-group">
        <label for="data_rate" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['currency']['rate'];?>
</label>
        <div class="col-sm-9">
            <input name="data[rate]" id="data_rate"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['rate'];?>
" placeholder="1">
        </div>
    </div>
    <div class="form-group">
        <label for="data_symbol" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['currency']['symbol'];?>
</label>
        <div class="col-sm-9">
            <input name="data[symbol]" id="data_symbol"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['symbol'];?>
" placeholder="грн.">
        </div>
    </div>
    <div class="form-group">
        <label for="data_is_main" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['currency']['is_main'];?>
</label>
        <div class="col-sm-9">
            <input type="hidden"  name="data[is_main]"  class="form-control" value="0" >
            <input type="checkbox" <?php if ($_smarty_tpl->tpl_vars['data']->value['is_main']) {?>checked<?php }?> name="data[is_main]" id="data_is_main" value="1" >
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
</form><?php }} ?>
