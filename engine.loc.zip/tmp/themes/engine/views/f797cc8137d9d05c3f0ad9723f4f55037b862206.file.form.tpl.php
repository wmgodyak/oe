<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 09:55:42
         compiled from "/var/www/engine.loc/themes/engine/views/banners/places/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:160382005657714372107783-63079448%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f797cc8137d9d05c3f0ad9723f4f55037b862206' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/banners/places/form.tpl',
      1 => 1467182691,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '160382005657714372107783-63079448',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5771437213d9d6_32064787',
  'variables' => 
  array (
    'action' => 0,
    't' => 0,
    'data' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5771437213d9d6_32064787')) {function content_5771437213d9d6_32064787($_smarty_tpl) {?><div class="row">
    <div class="col-md-8 col-md-offset-2">
    <fieldset>
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['banners_places'][$_smarty_tpl->tpl_vars['action']->value];?>
</legend>
    <form action="module/run/banners/places/process/<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>" method="post" id="placeForm" class="form-horizontal">
        <div class="form-group">
            <label for="data_name" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners_places']['name'];?>
</label>
            <div class="col-sm-9">
                <input name="data[name]" id="data_name"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['name'])) {
echo $_smarty_tpl->tpl_vars['data']->value['name'];
}?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="data_code" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners_places']['code'];?>
</label>
            <div class="col-sm-9">
                <input name="data[code]" id="data_code"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['code'])) {
echo $_smarty_tpl->tpl_vars['data']->value['code'];
}?>" placeholder="[a-z0-9_]+" required>
            </div>
        </div>
        <div class="form-group">
            <label for="data_width" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners_places']['width'];?>
</label>
            <div class="col-sm-9">
                <input name="data[width]" id="data_width"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['width'])) {
echo $_smarty_tpl->tpl_vars['data']->value['width'];
}?>" required onchange="this.value=parseInt(this.value); if(this.value == 0) this.value = '';">
            </div>
        </div>
        <div class="form-group">
            <label for="data_height" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners_places']['height'];?>
</label>
            <div class="col-sm-9">
                <input name="data[height]" id="data_height"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['height'])) {
echo $_smarty_tpl->tpl_vars['data']->value['height'];
}?>" required onchange="this.value=parseInt(this.value); if(this.value == 0) this.value = '';">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-9">
                <button type="button" class="btn btn-success btn-large" id="bSubmitPlaceForm" >Зберегти</button>
            </div>
        </div>

        <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
        <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
    </form>
    </fieldset>
    </div>
</div><?php }} ?>
