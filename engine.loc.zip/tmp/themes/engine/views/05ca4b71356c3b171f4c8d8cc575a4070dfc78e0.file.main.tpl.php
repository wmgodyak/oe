<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 16:44:07
         compiled from "/var/www/engine.loc/themes/engine/views/guides/main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10982826075773ce847648b8-69239254%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '05ca4b71356c3b171f4c8d8cc575a4070dfc78e0' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/guides/main.tpl',
      1 => 1467207838,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10982826075773ce847648b8-69239254',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5773ce84784583_74276349',
  'variables' => 
  array (
    't' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5773ce84784583_74276349')) {function content_5773ce84784583_74276349($_smarty_tpl) {?><div class="form-group">
    <label for="content_external_id" class="col-sm-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['guides']['external_id'];?>
</label>
    <div class="col-sm-10">
        <input name="content[external_id]" id="content_external_id"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['content']->value['external_id'])) {
echo $_smarty_tpl->tpl_vars['content']->value['external_id'];
}?>" placeholder="[a-z0-9_]+" required>
    </div>
</div><?php }} ?>
