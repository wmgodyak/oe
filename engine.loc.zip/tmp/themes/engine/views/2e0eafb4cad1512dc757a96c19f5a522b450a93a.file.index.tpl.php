<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-17 10:49:02
         compiled from "/var/www/engine.loc/themes/engine/views/themes/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6793161705763ab6e4cb5e3-28359531%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2e0eafb4cad1512dc757a96c19f5a522b450a93a' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/themes/index.tpl',
      1 => 1460543486,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6793161705763ab6e4cb5e3-28359531',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'items' => 0,
    'item' => 0,
    't' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5763ab6e50cce1_66496584',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5763ab6e50cce1_66496584')) {function content_5763ab6e50cce1_66496584($_smarty_tpl) {?><div class="themes row">
    <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
    <div class="col-md-4 theme <?php echo $_smarty_tpl->tpl_vars['item']->value['current'];?>
 ">
        <section class="panel panel-default panel-block">
            <div class="panel-heading text-overflow-hidden">
                <div class="screenshot">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['item']->value['urlpath'];?>
screenshot.png"/>
                    <div class="description">
                        <div class="author"><?php echo $_smarty_tpl->tpl_vars['t']->value['themes']['author'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['author'];?>
</div>
                        <div class="version"><?php echo $_smarty_tpl->tpl_vars['t']->value['themes']['version'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['version'];?>
</div>
                        <div class="info"><?php echo $_smarty_tpl->tpl_vars['item']->value['description'];?>
</div>
                    </div>
                </div>
                <h3 class="name"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</h3>
                <?php if ($_smarty_tpl->tpl_vars['item']->value['current']=='') {?>
                    <div class="actions">
                        <a
                            title="Download"
                            class="btn btn-success"
                            href="themes/download/<?php echo $_smarty_tpl->tpl_vars['item']->value['theme'];?>
"
                        ><i class="fa fa-file-zip-o"></i> Download</a>
                        <a onclick="return false;"
                           data-theme="<?php echo $_smarty_tpl->tpl_vars['item']->value['theme'];?>
"
                           class="btn btn-success b-themes-activate"
                           href="javascript:void(0);"
                        ><i class="fa fa-download"></i> <?php echo $_smarty_tpl->tpl_vars['t']->value['themes']['activate'];?>
</a>
                    </div>
                    <?php } else { ?>
                    <div class="actions">
                        <a
                           title="Download"
                           class="btn btn-success"
                           href="themes/download/<?php echo $_smarty_tpl->tpl_vars['item']->value['theme'];?>
"
                        ><i class="fa fa-file-zip-o"></i> Download</a>
                        <a
                           title="<?php echo $_smarty_tpl->tpl_vars['t']->value['themes']['edit'];?>
"
                           class="btn btn-primary"
                           href="themes/edit/<?php echo $_smarty_tpl->tpl_vars['item']->value['theme'];?>
"
                        ><i class="fa fa-code"></i> <?php echo $_smarty_tpl->tpl_vars['t']->value['themes']['edit'];?>
</a>
                    </div>
                <?php }?>
            </div>
        </section>
    </div>
    <?php } ?>
</div>
<div style="display: none;">
    <form action="themes/upload" id="uploadThemeForm" method="post" enctype="multipart/form-data">
        <input type="file" name="theme" id="uploadFileInp">
        <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    </form>
</div><?php }} ?>
