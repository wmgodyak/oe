<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-16 12:02:28
         compiled from "/var/www/engine.loc/themes/engine/views/contentFeatures/create_value.tpl" */ ?>
<?php /*%%SmartyHeaderCode:117714435656e92e9aaada34-46355604%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a61ca2891ea68bb0fc0355274d383624d31e3ce9' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/contentFeatures/create_value.tpl',
      1 => 1458122545,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '117714435656e92e9aaada34-46355604',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56e92e9aadb0e7_12333896',
  'variables' => 
  array (
    'languages' => 0,
    'lang' => 0,
    't' => 0,
    'token' => 0,
    'data' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e92e9aadb0e7_12333896')) {function content_56e92e9aadb0e7_12333896($_smarty_tpl) {?><form action="contentFeatures/createValue" method="post" id="formContentFeaturesValues" class="form-horizontal" >
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="f_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['value'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
)</label>
            <div class="col-sm-9">
                <input name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="f_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control f-info-name" data-lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
">
            </div>
        </div>
    <?php } ?>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="data[status]" value="published">
    <input type="hidden" name="data[type]" value="value">
    <input type="hidden" name="data[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['parent_id'];?>
">
    <input type="hidden" name="action" value="create">
</form><?php }} ?>
