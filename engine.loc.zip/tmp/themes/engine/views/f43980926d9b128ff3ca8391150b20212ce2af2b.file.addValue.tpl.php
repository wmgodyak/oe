<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 11:22:23
         compiled from "/var/www/engine.loc/themes/engine/views/shop/products/features/addValue.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20417469577a1cbf9f3178-72888050%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f43980926d9b128ff3ca8391150b20212ce2af2b' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/products/features/addValue.tpl',
      1 => 1467616402,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20417469577a1cbf9f3178-72888050',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'features_id' => 0,
    'products_id' => 0,
    'languages' => 0,
    'lang' => 0,
    't' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577a1cbfa28d21_37392668',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577a1cbfa28d21_37392668')) {function content_577a1cbfa28d21_37392668($_smarty_tpl) {?><form action="module/run/shop/products/features/addValue/<?php echo $_smarty_tpl->tpl_vars['features_id']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['products_id']->value;?>
"  method="post" id="formProductsFeaturesValues" class="form-horizontal" >
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="f_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
)</label>
            <div class="col-md-10">
                <input name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="f_info_value_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control f-info-value" data-lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
">
            </div>
        </div>
    <?php } ?>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="data[status]" value="published">
    <input type="hidden" name="data[type]" value="value">
    <input type="hidden" name="data[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['features_id']->value;?>
">
</form><?php }} ?>
