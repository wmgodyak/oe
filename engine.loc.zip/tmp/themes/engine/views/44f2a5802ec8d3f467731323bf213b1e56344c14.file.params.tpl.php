<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-23 17:58:42
         compiled from "/var/www/engine.loc/themes/engine/views/content/blocks/params.tpl" */ ?>
<?php /*%%SmartyHeaderCode:109745610956d4435adae6a9-82612487%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '44f2a5802ec8d3f467731323bf213b1e56344c14' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/blocks/params.tpl',
      1 => 1458748721,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '109745610956d4435adae6a9-82612487',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56d4435adaeac1_14456354',
  'variables' => 
  array (
    't' => 0,
    'subtypes' => 0,
    'content' => 0,
    'item' => 0,
    'plugins' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d4435adaeac1_14456354')) {function content_56d4435adaeac1_14456354($_smarty_tpl) {?><fieldset>
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['legend_params'];?>
</legend>
    <?php if (count($_smarty_tpl->tpl_vars['subtypes']->value)>1) {?>
        <div class="form-group">
            <label for="content_subtypes_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['subtypes'];?>
</label>
            <div class="col-md-9">
                <select name="content[subtypes_id]" id="content_subtypes_id" class="form-control">
                    <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['subtypes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                        <option <?php if ($_smarty_tpl->tpl_vars['content']->value['subtypes_id']==$_smarty_tpl->tpl_vars['item']->value['id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
                    <?php } ?>
                </select>
            </div>
        </div>
    <?php }?>

    <div class="form-group">
        <label for="content_status" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['status'];?>
</label>
        <div class="col-md-9">
            <select name="content[status]" id="content_status" class="form-control">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['content']->value['statuses']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['item']->key;
?>
                    <option <?php if ($_smarty_tpl->tpl_vars['content']->value['status']==$_smarty_tpl->tpl_vars['item']->value) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value;?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="content_owner_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['owner'];?>
</label>
        <div class="col-md-9">
            <select name="content[owner_id]" id="content_owner_id" class="form-control">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['content']->value['owners']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                    <option <?php if ($_smarty_tpl->tpl_vars['content']->value['owner_id']==$_smarty_tpl->tpl_vars['item']->value['id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['surname'];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="content_parent_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['parent_id'];?>
</label>
        <div class="col-md-9">
            <input name="content[parent_id]" id="content_parent_id" class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['parent_id'];?>
">
        </div>
    </div>
    <div class="form-group">
        <label for="content_published" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['pub_date'];?>
</label>
        <div class="col-md-9">
            <input name="content[published]" id="content_published" class="form-control datepicker" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['published'];?>
">
        </div>
    </div>
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['params'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['params']);
}?>
</fieldset><?php }} ?>
