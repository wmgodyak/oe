<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-28 10:27:46
         compiled from "/var/www/engine.loc/themes/engine/views/content/blocks/main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:184133491556d44351a124f9-72537823%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7745a9c25324ce808328e0d2a7a50cd4dc90a72b' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/blocks/main.tpl',
      1 => 1459150065,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '184133491556d44351a124f9-72537823',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56d44351a12b65_45476283',
  'variables' => 
  array (
    't' => 0,
    'languages' => 0,
    'i' => 0,
    'lang' => 0,
    'content' => 0,
    'plugins' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d44351a12b65_45476283')) {function content_56d44351a12b65_45476283($_smarty_tpl) {?><fieldset>
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['legend_main'];?>
</legend>
    <?php if (count($_smarty_tpl->tpl_vars['languages']->value)>1) {?>
    <div class="form-group">
        <label class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['lang'];?>
</label>
        <div class="btn-group col-md-9" id="switchLanguages" role="group">
            <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['lang']->key;
?>
                <button type="button" class="btn <?php if ($_smarty_tpl->tpl_vars['i']->value==0) {?>btn-primary<?php }?>" data-code="<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
"><?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
</button>
            <?php } ?>
        </div>
    </div>
    <?php }?>
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['lang']->key;
?>
    <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
        <label for="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_name" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['name'];?>
</label>
        <div class="col-md-9">
            <input type="text" class="form-control info-name" name="content_info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]" id="content_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_name" required="" placeholder="[a-zA-Zа-яА-Я0-9]+" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['name'];?>
" data-lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
">
        </div>
    </div>

    <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
        <label for="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_url" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['url'];?>
</label>
        <div class="col-md-9">
            <input type="text" data-parent-url="<?php echo $_smarty_tpl->tpl_vars['content']->value['parent_url'][$_smarty_tpl->tpl_vars['lang']->value['id']];?>
" class="form-control info-url" name="content_info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][url]" id="content_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_url" placeholder="[a-z0-9]+ max:160" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['url'];?>
">
        </div>
    </div>
    <?php } ?>
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['main'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['main']);
}?>
</fieldset><?php }} ?>
