<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 09:55:52
         compiled from "/var/www/engine.loc/themes/engine/views/banners/banner.tpl" */ ?>
<?php /*%%SmartyHeaderCode:697782586577370f84eb0a3-68552025%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0d0a9dfdeb37a222e50922e5c2a0b1c3ee45926a' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/banners/banner.tpl',
      1 => 1467182691,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '697782586577370f84eb0a3-68552025',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
    'sizes' => 0,
    't' => 0,
    'languages' => 0,
    'lang' => 0,
    'action' => 0,
    'place_id' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577370f85801c1_52499686',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577370f85801c1_52499686')) {function content_577370f85801c1_52499686($_smarty_tpl) {?><form action="module/run/banners/process/<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>" method="post" id="form" class="form-horizontal" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-5">
            <fieldset>
                <legend>Зображення</legend>
                <div class="form-group">
                    <div class="img" style="text-align: center">
                        <img src="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['img'])) {
echo $_smarty_tpl->tpl_vars['data']->value['img'];
} else { ?>/themes/engine/assets/img/no-image.png<?php }?>" alt="no-image" style="max-width:160px; cursor: pointer;" id="bannersImage">
                        <p>Розмір: <?php echo $_smarty_tpl->tpl_vars['sizes']->value['width'];?>
x<?php echo $_smarty_tpl->tpl_vars['sizes']->value['height'];?>
px</p>
                        <input type="file" name="image" style="display: none" id="bannersImageUpload" onchange="engine.banners.encodeImageFileAsURL();">
                    </div>
                </div>
            </fieldset>
        </div>
        <div class="col-md-7">
            <fieldset>
                <legend>Параметри</legend>

                <div class="form-group">
                    <label for="data_name" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['name'];?>
</label>
                    <div class="col-md-9">
                        <input name="data[name]" id="data_name"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['name'])) {
echo $_smarty_tpl->tpl_vars['data']->value['name'];
}?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_languages_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['lang'];?>
</label>
                    <div class="col-md-9">
                        <select class="form-control" name="data[languages_id]" id="data_languages_id">
                            <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
                                <option <?php if (isset($_smarty_tpl->tpl_vars['data']->value['languages_id'])&&$_smarty_tpl->tpl_vars['data']->value['languages_id']==$_smarty_tpl->tpl_vars['lang']->value['id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
</option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-9 col-md-offset-1">
                        <input type="hidden"  name="data[published]"  class="form-control" value="0" >
                        <input type="checkbox" <?php if ((isset($_smarty_tpl->tpl_vars['data']->value['published'])&&$_smarty_tpl->tpl_vars['data']->value['published'])||$_smarty_tpl->tpl_vars['action']->value=='create') {?>checked<?php }?> name="data[published]" id="data_published" value="1" > <?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['published'];?>

                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-9 col-md-offset-1">
                        <input type="hidden"  name="data[permanent]"  class="form-control" value="0" >
                        <input type="checkbox" <?php if ((isset($_smarty_tpl->tpl_vars['data']->value['permanent'])&&$_smarty_tpl->tpl_vars['data']->value['permanent'])||$_smarty_tpl->tpl_vars['action']->value=='create') {?>checked<?php }?> name="data[permanent]" id="data_permanent" value="1" > <?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['permanent'];?>

                    </div>
                </div>
                <div class="row" id="permanent_period" style="<?php if ($_smarty_tpl->tpl_vars['data']->value['permanent']==0&&$_smarty_tpl->tpl_vars['action']->value=='edit') {?>display:block<?php } else { ?>display:none<?php }?>">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="data_df" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['df'];?>
</label>
                            <div class="col-md-9">
                                <input name="data[df]" id="data_df"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['df'])) {
echo $_smarty_tpl->tpl_vars['data']->value['df'];
}?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="data_dt" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['dt'];?>
</label>
                            <div class="col-md-9">
                                <input name="data[dt]" id="data_dt"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['dt'])) {
echo $_smarty_tpl->tpl_vars['data']->value['dt'];
}?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_url" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['url'];?>
</label>
                    <div class="col-md-9">
                        <input name="data[url]" id="data_url"  class="form-control" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['url'])) {
echo $_smarty_tpl->tpl_vars['data']->value['url'];
}?>" placeholder="[a-z0-9_]+" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                        <input type="hidden"  name="data[target]"  class="form-control" value="_self" >
                        <input type="checkbox" <?php if (isset($_smarty_tpl->tpl_vars['data']->value['target'])&&$_smarty_tpl->tpl_vars['data']->value['target']=='_blank') {?>checked<?php }?> name="data[target]" value="_blank" >
                        <?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['target'];?>

                    </div>
                </div>
            </fieldset>
        </div>
    </div>

    <?php if (isset($_smarty_tpl->tpl_vars['place_id']->value)) {?>
        <input type="hidden" name="data[places_id]" value="<?php echo $_smarty_tpl->tpl_vars['place_id']->value;?>
">
    <?php }?>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
</form><?php }} ?>
