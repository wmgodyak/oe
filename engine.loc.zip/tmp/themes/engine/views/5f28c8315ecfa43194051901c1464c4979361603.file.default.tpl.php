<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-18 10:01:37
         compiled from "/var/www/engine.loc/themes/engine/views/content/default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:58525032756d44338dc0b58-11955796%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5f28c8315ecfa43194051901c1464c4979361603' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/default.tpl',
      1 => 1458288060,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '58525032756d44338dc0b58-11955796',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56d44338e66684_84843149',
  'variables' => 
  array (
    'form_action' => 0,
    'form_success' => 0,
    'plugins' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d44338e66684_84843149')) {function content_56d44338e66684_84843149($_smarty_tpl) {?><form action="<?php echo $_smarty_tpl->tpl_vars['form_action']->value;?>
" method="post" id="form" class="form-horizontal" <?php if ($_smarty_tpl->tpl_vars['form_success']->value) {?>data-success = '<?php echo $_smarty_tpl->tpl_vars['form_success']->value;?>
'<?php }?>>
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['top'])) {?>
        <div class="row">
            <div class="col-md-12">
                <?php echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['top']);?>

            </div>
        </div>
    <?php }?>
    <div class="row">
        <div class="col-md-8">
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_main'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_main']);
}?>
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/meta.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_meta'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_meta']);
}?>
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/content.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_content'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_content']);
}?>
        </div>
        <div class="col-md-4">
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/params.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_params'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_params']);
}?>
            <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/features.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['after_features'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['after_features']);
}?>
        </div>
    </div>
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['bottom'])) {?>
        <div class="row">
            <div class="col-md-12">
                <?php echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['bottom']);?>

            </div>
        </div>
    <?php }?>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
</form><?php }} ?>
