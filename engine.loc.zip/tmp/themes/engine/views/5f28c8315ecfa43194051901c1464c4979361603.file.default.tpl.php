<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 22:39:39
         compiled from "/var/www/engine.loc/themes/engine/views/content/default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:764380614577abb7be3e0a0-46067074%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5f28c8315ecfa43194051901c1464c4979361603' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/default.tpl',
      1 => 1466856018,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '764380614577abb7be3e0a0-46067074',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'form_action' => 0,
    'form_success' => 0,
    'content' => 0,
    'events' => 0,
    'form_display_blocks' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577abb7bead660_68806453',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577abb7bead660_68806453')) {function content_577abb7bead660_68806453($_smarty_tpl) {?><form action="<?php echo $_smarty_tpl->tpl_vars['form_action']->value;?>
" method="post" id="form" class="form-horizontal" <?php if ($_smarty_tpl->tpl_vars['form_success']->value) {?>data-success = '<?php echo $_smarty_tpl->tpl_vars['form_success']->value;?>
'<?php }?>>
    <?php echo $_smarty_tpl->tpl_vars['events']->value->call('form.top',array($_smarty_tpl->tpl_vars['content']->value));?>

    <div class="row">
        <div class="col-md-8">
            <?php if ($_smarty_tpl->tpl_vars['form_display_blocks']->value['main']) {?>
                <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php echo $_smarty_tpl->tpl_vars['events']->value->call('content.main.after',array($_smarty_tpl->tpl_vars['content']->value));?>

            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['form_display_blocks']->value['content']) {?>
                <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/content.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php echo $_smarty_tpl->tpl_vars['events']->value->call('content.content.after',array($_smarty_tpl->tpl_vars['content']->value));?>

            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['form_display_blocks']->value['intro']) {?>
                <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/intro.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php echo $_smarty_tpl->tpl_vars['events']->value->call('content.intro.after',array($_smarty_tpl->tpl_vars['content']->value));?>

            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['form_display_blocks']->value['meta']) {?>
                <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/meta.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php echo $_smarty_tpl->tpl_vars['events']->value->call('content.meta.after',array($_smarty_tpl->tpl_vars['content']->value));?>

            <?php }?>
        </div>
        <div class="col-md-4">
            <?php if ($_smarty_tpl->tpl_vars['form_display_blocks']->value['params']) {?>
                <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/params.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php echo $_smarty_tpl->tpl_vars['events']->value->call('content.params.after',array($_smarty_tpl->tpl_vars['content']->value));?>

            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['form_display_blocks']->value['features']) {?>
                <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/features.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php echo $_smarty_tpl->tpl_vars['events']->value->call('content.features.after',array($_smarty_tpl->tpl_vars['content']->value));?>

            <?php }?>
        </div>
    </div>
    <?php echo $_smarty_tpl->tpl_vars['events']->value->call('form.bottom',array($_smarty_tpl->tpl_vars['content']->value));?>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" id="content_id" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
">
</form><?php }} ?>
