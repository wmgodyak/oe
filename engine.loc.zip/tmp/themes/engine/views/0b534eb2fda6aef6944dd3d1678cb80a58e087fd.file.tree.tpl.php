<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 10:09:43
         compiled from "/var/www/engine.loc/themes/engine/views/shop/categories/tree.tpl" */ ?>
<?php /*%%SmartyHeaderCode:113562408757737437ec05b2-40480928%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b534eb2fda6aef6944dd3d1678cb80a58e087fd' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/categories/tree.tpl',
      1 => 1467182691,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '113562408757737437ec05b2-40480928',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    't' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57737437ed6138_11333342',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57737437ed6138_11333342')) {function content_57737437ed6138_11333342($_smarty_tpl) {?><div class="title">
    <i class="fa fa-pencil-square"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['shopCategories']['tree_title'];?>
</span>
    <button class="btn btn-link b-shop-categories-create" ><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</button>
</div>
<div class="pages-tree" id="shopCategories"></div><?php }} ?>
