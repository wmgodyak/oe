<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 22:27:03
         compiled from "/var/www/engine.loc/themes/engine/views/pages/tree.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2044977126577ab887ca5522-29068130%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f17a9bb93017a747598aa3cf8e4a55721640daf7' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/pages/tree.tpl',
      1 => 1466024340,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2044977126577ab887ca5522-29068130',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tree_icon' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577ab887cb1c29_88741346',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577ab887cb1c29_88741346')) {function content_577ab887cb1c29_88741346($_smarty_tpl) {?><div class="title">
    <i class="fa <?php echo $_smarty_tpl->tpl_vars['tree_icon']->value;?>
"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['pages']['tree_title'];?>
</span>
    
</div>
<div class="pages-tree" id="treecc"></div><?php }} ?>
