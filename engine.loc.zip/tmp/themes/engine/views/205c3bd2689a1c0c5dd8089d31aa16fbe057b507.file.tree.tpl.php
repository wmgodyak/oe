<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 16:25:22
         compiled from "/var/www/engine.loc/themes/engine/views/guides/tree.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20204862535773c2cb9a1622-63324593%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '205c3bd2689a1c0c5dd8089d31aa16fbe057b507' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/guides/tree.tpl',
      1 => 1467206722,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20204862535773c2cb9a1622-63324593',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5773c2cb9b6e92_69502239',
  'variables' => 
  array (
    't' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5773c2cb9b6e92_69502239')) {function content_5773c2cb9b6e92_69502239($_smarty_tpl) {?><div class="title">
    <i class="fa fa-book"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['guides']['tree_title'];?>
</span>
    <button class="btn btn-link b-guides-create" data-id="0"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</button>
</div>
<div class="pages-tree" id="guidesTree"></div><?php }} ?>
