<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-01 17:48:05
         compiled from "/var/www/engine.loc/themes/engine/views/shop/categories/features/selected.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1899739296577660085c1b90-20546057%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9012db3a1f4f84d7552486fab1d9145e7118cc0e' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/categories/features/selected.tpl',
      1 => 1467384484,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1899739296577660085c1b90-20546057',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577660085c3532_64542764',
  'variables' => 
  array (
    'features' => 0,
    'feature' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577660085c3532_64542764')) {function content_577660085c3532_64542764($_smarty_tpl) {?><div class="dd" id="categories_features">
    <ol class="dd-list">
        <?php  $_smarty_tpl->tpl_vars['feature'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['feature']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['features']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['feature']->key => $_smarty_tpl->tpl_vars['feature']->value) {
$_smarty_tpl->tpl_vars['feature']->_loop = true;
?>
            <li class="dd-item dd3-item" data-id="<?php echo $_smarty_tpl->tpl_vars['feature']->value['fc_id'];?>
" id="scf-<?php echo $_smarty_tpl->tpl_vars['feature']->value['fc_id'];?>
">
                <div class="dd-handle dd3-handle">Drag</div>
                <div class="dd3-content"><?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>

                    <a class="scf-remove dd-remove" style="right: 30px" data-id="<?php echo $_smarty_tpl->tpl_vars['feature']->value['fc_id'];?>
" href="javascript:void(0)" title="Видалити зв'язок"><i class="fa fa-remove"></i></a>
                    <a class="scf-drop dd-remove" data-fcid="<?php echo $_smarty_tpl->tpl_vars['feature']->value['fc_id'];?>
"  data-id="<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
" href="javascript:void(0)" title="Видалити властивість"><i class="fa fa-trash"></i></a>
                </div>
            </li>
            
        <?php } ?>
    </ol>
</div><?php }} ?>
