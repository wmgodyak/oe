<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 14:03:46
         compiled from "/var/www/engine.loc/themes/engine/views/shop/categories/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:149783064357737b95752247-52624190%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c3ed04f5273a5536c66b85a8a8a1bbb52e59adfc' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/categories/form.tpl',
      1 => 1467198219,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '149783064357737b95752247-52624190',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57737b9577e651_23114282',
  'variables' => 
  array (
    'content' => 0,
    'token' => 0,
    'admin' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57737b9577e651_23114282')) {function content_57737b9577e651_23114282($_smarty_tpl) {?><form action="module/run/shop/categories/process/<?php if (isset($_smarty_tpl->tpl_vars['content']->value['id'])) {
echo $_smarty_tpl->tpl_vars['content']->value['id'];
}?>" method="post" id="shopCategoriesForm" class="form-horizontal">

    <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/meta.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="content[status]" value="published">
    <input type="hidden" name="content[owner_id]" value="<?php echo $_smarty_tpl->tpl_vars['admin']->value['id'];?>
">
    <input type="hidden" name="content[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['parent_id'];?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
    <input type="hidden" name="modal" value="1">

</form><?php }} ?>
