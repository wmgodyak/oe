<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 09:48:03
         compiled from "/var/www/engine.loc/themes/engine/views/comments/dashboard.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1211529564577130275e14e2-74072680%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '65a0bdc1de78c503e16e3d8636149a6d123adf4e' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/comments/dashboard.tpl',
      1 => 1467182691,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1211529564577130275e14e2-74072680',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577130275e6388_65805440',
  'variables' => 
  array (
    'items' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577130275e6388_65805440')) {function content_577130275e6388_65805440($_smarty_tpl) {?><div class="col-md-6">
    <fieldset>
        <legend>Останні коментарі</legend>
        <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
            <div class="row">
                <div class="col-md-12">
                    <p><small><?php echo date('d.m.Y H:i:s',strtotime($_smarty_tpl->tpl_vars['item']->value['created']));?>
</small> <small>Автор: <?php echo $_smarty_tpl->tpl_vars['item']->value['user']['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['user']['surname'];?>
</small></p>
                    <p><?php echo $_smarty_tpl->tpl_vars['item']->value['message'];?>
</p>
                    <hr>
                </div>
            </div>
        <?php } ?>
        <p style="text-align: right"><a href="module/run/comments">Всі коментарі</a></p>
    </fieldset>
</div><?php }} ?>
