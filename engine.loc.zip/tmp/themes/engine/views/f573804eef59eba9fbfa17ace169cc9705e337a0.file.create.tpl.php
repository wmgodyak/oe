<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-01 17:16:05
         compiled from "/var/www/engine.loc/themes/engine/views/shop/categories/features/create.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14571626185776758adc4906-97965564%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f573804eef59eba9fbfa17ace169cc9705e337a0' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/categories/features/create.tpl',
      1 => 1467382558,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14571626185776758adc4906-97965564',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5776758ae21593_14748379',
  'variables' => 
  array (
    'languages' => 0,
    'lang' => 0,
    't' => 0,
    'token' => 0,
    'data' => 0,
    'content_id' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5776758ae21593_14748379')) {function content_5776758ae21593_14748379($_smarty_tpl) {?><form action="module/run/shop/categories/features/create" method="post" id="formContentFeatures" class="form-horizontal" >
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="f_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
)</label>
            <div class="col-md-10">
                <input name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="f_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control f-info-name" data-lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
">
            </div>
        </div>
    <?php } ?>
    <div class="form-group">
        <label for="f_data_code" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['code'];?>
</label>
        <div class="col-md-10">
            <input name="data[code]" id="f_data_code"  class="form-control">
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-10 col-md-offset-2">
            <div class="checkbox">
                <label>
                    <input type="hidden" name="data[type]"  value="select">
                    <input type="checkbox" name="data[type]" id="data_folder" value="folder"> Група
                </label>
            </div>
        </div>
    </div>

    <div class="form-group fg-required">
        <div class="col-md-10 col-md-offset-2">
            <div class="checkbox">
                <label>
                    <input type="hidden" name="data[required]" value="0">
                    <input type="checkbox" name="data[required]" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['common']['required'];?>

                </label>
            </div>
        </div>
    </div>

    <div class="form-group fg-multiple">
        <div class="col-md-10 col-md-offset-2">
            <div class="checkbox">
                <label>
                    <input type="hidden" name="data[multiple]" value="0">
                    <input type="checkbox" name="data[multiple]" id="data_multiple" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['multiple'];?>

                </label>
            </div>
        </div>
    </div>
    <div class="form-group fg-show-filter">
        <div class="col-md-10 col-md-offset-2">
            <div class="checkbox">
                <label>
                    <input type="hidden" name="data[on_filter]" value="0">
                    <input type="checkbox" name="data[on_filter]" id="data_on_filter" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['on_filter'];?>

                </label>
            </div>
        </div>
    </div>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="create">
    <input type="hidden" name="data[status]" value="published">
    <input type="hidden" name="data[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['parent_id'];?>
">
    <input type="hidden" name="content_id" value="<?php echo $_smarty_tpl->tpl_vars['content_id']->value;?>
">
</form><?php }} ?>
