<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-24 14:26:32
         compiled from "/var/www/engine.loc/themes/engine/views/callbacks/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1736282927576ce2702099a5-05294877%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '26889942c0b56e85bd915515ad3eea1deda59676' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/callbacks/index.tpl',
      1 => 1466767592,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1736282927576ce2702099a5-05294877',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_576ce270215b48_58972410',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_576ce270215b48_58972410')) {function content_576ce270215b48_58972410($_smarty_tpl) {?><div id="tabs">
    <ul>
        <li><a href="module/run/callbacks/tab/all">Всі</a></li>
        <li><a href="module/run/callbacks/tab/new">Нові</a></li>
        <li><a href="module/run/callbacks/tab/spam">Спам</a></li>
        <li><a href="module/run/callbacks/tab/processed">Опрацьовані</a></li>
    </ul>
</div>
<?php }} ?>
