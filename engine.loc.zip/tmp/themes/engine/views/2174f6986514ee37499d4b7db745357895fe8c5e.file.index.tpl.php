<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 11:21:52
         compiled from "/var/www/engine.loc/themes/engine/views/shop/products/features/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1049045468577a1ca0128b36-05493557%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2174f6986514ee37499d4b7db745357895fe8c5e' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/products/features/index.tpl',
      1 => 1467616402,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1049045468577a1ca0128b36-05493557',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577a1ca0132483_66503257',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577a1ca0132483_66503257')) {function content_577a1ca0132483_66503257($_smarty_tpl) {?><fieldset id="productsFeatures" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
">
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['legend_features'];?>

        <a href="javascript:;" type="button" class="b-spf-select" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
" data-parent="0" title="Додати">
            <i class="fa fa-plus-circle"></i>
        </a>
    </legend>
    <div id="content_features_0"><?php echo $_smarty_tpl->getSubTemplate ("shop/products/features/selected.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
</div>
</fieldset><?php }} ?>
