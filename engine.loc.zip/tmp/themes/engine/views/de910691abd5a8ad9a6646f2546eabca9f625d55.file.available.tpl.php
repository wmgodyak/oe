<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-27 13:43:44
         compiled from "/var/www/engine.loc/themes/engine/views/widgets/available.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1092760945770e8d30d8cd0-70414879%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'de910691abd5a8ad9a6646f2546eabca9f625d55' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/widgets/available.tpl',
      1 => 1467024224,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1092760945770e8d30d8cd0-70414879',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5770e8d30ea0b0_48753141',
  'variables' => 
  array (
    'available_widgets' => 0,
    'id' => 0,
    'class' => 0,
    'area' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5770e8d30ea0b0_48753141')) {function content_5770e8d30ea0b0_48753141($_smarty_tpl) {?><fieldset>
    <legend>Доступні віджети</legend>

    <div class="form-group">
        <label for="av_select_widget" class="col-md-2 control-label">Виберіть</label>
        <div class="col-md-10">
            <select id="inst_available_widgets">
                <option value=""> - Виберіть -</option>
                <?php  $_smarty_tpl->tpl_vars['class'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['class']->_loop = false;
 $_smarty_tpl->tpl_vars['id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['available_widgets']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['class']->key => $_smarty_tpl->tpl_vars['class']->value) {
$_smarty_tpl->tpl_vars['class']->_loop = true;
 $_smarty_tpl->tpl_vars['id']->value = $_smarty_tpl->tpl_vars['class']->key;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['class']->value->getName();?>
</option>
                <?php } ?>
            </select>
            <input type="hidden" id="area" value="<?php echo $_smarty_tpl->tpl_vars['area']->value;?>
">
        </div>
    </div>
</fieldset><?php }} ?>
