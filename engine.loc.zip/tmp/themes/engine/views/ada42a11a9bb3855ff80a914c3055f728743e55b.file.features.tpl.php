<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 22:39:40
         compiled from "/var/www/engine.loc/themes/engine/views/content/blocks/features.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1078329913577abb7c104f83-94794853%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ada42a11a9bb3855ff80a914c3055f728743e55b' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/blocks/features.tpl',
      1 => 1466851444,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1078329913577abb7c104f83-94794853',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
    't' => 0,
    'content_features' => 0,
    'events' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577abb7c121f80_73361672',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577abb7c121f80_73361672')) {function content_577abb7c121f80_73361672($_smarty_tpl) {?><fieldset id="contentFeaturesFs" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
">
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['legend_features'];?>

        
        <?php echo '<script'; ?>
>var features_settings = <?php if (isset($_smarty_tpl->tpl_vars['content']->value['settings']['type']['features'])) {
echo json_encode($_smarty_tpl->tpl_vars['content']->value['settings']['type']['features']);
} else { ?>null<?php }?><?php echo '</script'; ?>
>
        <a href="javascript:;" type="button" class="b-ct-features-add" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
" data-parent="0" title="Додати">
            <i class="fa fa-plus-circle"></i>
        </a>
    </legend>
    <div id="content_features_0">
        <?php if (isset($_smarty_tpl->tpl_vars['content_features']->value)) {
echo $_smarty_tpl->tpl_vars['content_features']->value;
}?>
    </div>
    <?php echo $_smarty_tpl->tpl_vars['events']->value->call('content.features',array($_smarty_tpl->tpl_vars['content']->value));?>

</fieldset><?php }} ?>
