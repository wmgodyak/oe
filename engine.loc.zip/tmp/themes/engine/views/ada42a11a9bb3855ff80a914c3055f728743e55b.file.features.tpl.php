<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-21 09:49:54
         compiled from "/var/www/engine.loc/themes/engine/views/content/blocks/features.tpl" */ ?>
<?php /*%%SmartyHeaderCode:139530718656e7d72c29eb59-47588006%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ada42a11a9bb3855ff80a914c3055f728743e55b' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/blocks/features.tpl',
      1 => 1458316653,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '139530718656e7d72c29eb59-47588006',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56e7d72c2aedb8_41365746',
  'variables' => 
  array (
    'content' => 0,
    't' => 0,
    'content_features' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e7d72c2aedb8_41365746')) {function content_56e7d72c2aedb8_41365746($_smarty_tpl) {?><fieldset id="contentFeaturesFs" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
">
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['legend_features'];?>
 <a href="javascript:;" type="button" class="b-ct-features-add" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
" data-parent="0"><i class="fa fa-plus-circle"></i> Додати</a></legend>
    <div id="content_features_0">
        <?php echo $_smarty_tpl->tpl_vars['content_features']->value;?>

    </div>
</fieldset><?php }} ?>
