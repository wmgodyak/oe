<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-18 13:50:40
         compiled from "/var/www/engine.loc/themes/engine/views/admins/groups/tree.tpl" */ ?>
<?php /*%%SmartyHeaderCode:134537314557652780bd6761-26524680%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ea79e9e634fdbe96749758333a85f2e81c0cf23c' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/admins/groups/tree.tpl',
      1 => 1466247039,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134537314557652780bd6761-26524680',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    't' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57652780be1248_11634775',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57652780be1248_11634775')) {function content_57652780be1248_11634775($_smarty_tpl) {?><div class="title">
    <i class="fa <?php echo $_smarty_tpl->tpl_vars['t']->value['admins']['tree_icon'];?>
"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['admins']['tree_title'];?>
</span>
    <button class="btn btn-link b-admins-group-create"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</button>
</div>
<div class="pages-tree" id="usersGroup"></div><?php }} ?>
