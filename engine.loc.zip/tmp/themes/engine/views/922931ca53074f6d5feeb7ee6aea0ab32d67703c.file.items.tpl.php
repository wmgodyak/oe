<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 15:36:26
         compiled from "/var/www/engine.loc/themes/engine/views/shop/products/variants/items.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1485400951577a1ca00d0c89-82219988%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '922931ca53074f6d5feeb7ee6aea0ab32d67703c' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/products/variants/items.tpl',
      1 => 1467635785,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1485400951577a1ca00d0c89-82219988',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577a1ca0123cc8_09696505',
  'variables' => 
  array (
    'variants' => 0,
    'customers_group' => 0,
    'group' => 0,
    'variant' => 0,
    'feature' => 0,
    'i' => 0,
    'total' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577a1ca0123cc8_09696505')) {function content_577a1ca0123cc8_09696505($_smarty_tpl) {?> <?php if (count($_smarty_tpl->tpl_vars['variants']->value)) {?>
     <table class="table">
         <tr>
             <th style="width: 50px;">Фото</th>
             <th>Варіант</th>
             <th>Наявність</th>
             <?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['customers_group']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value) {
$_smarty_tpl->tpl_vars['group']->_loop = true;
?>
                 <th> <?php echo $_smarty_tpl->tpl_vars['group']->value['name'];?>
</th>
             <?php } ?>
             <th style="width: 60px;">Видал.</th>
         </tr>
            <?php  $_smarty_tpl->tpl_vars['variant'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['variant']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['variants']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['variant']->key => $_smarty_tpl->tpl_vars['variant']->value) {
$_smarty_tpl->tpl_vars['variant']->_loop = true;
?>
                <tr id="variant-<?php echo $_smarty_tpl->tpl_vars['variant']->value['id'];?>
">
                    <td>
                        <a class="variant-picture variant-<?php echo $_smarty_tpl->tpl_vars['variant']->value['id'];?>
" data-id="<?php echo $_smarty_tpl->tpl_vars['variant']->value['id'];?>
">
                            <?php if (empty($_smarty_tpl->tpl_vars['variant']->value['img'])) {?>
                                <i class="fa fa-picture-o"></i>
                            <?php } else { ?>
                                <img style="max-width: 50px;" src="<?php echo $_smarty_tpl->tpl_vars['variant']->value['img'];?>
" alt="variant img">
                            <?php }?>
                        </a>
                    </td>
                    <td>
                        <?php $_smarty_tpl->tpl_vars["total"] = new Smarty_variable(count($_smarty_tpl->tpl_vars['variant']->value['features'])-1, null, 0);?>
                        <?php  $_smarty_tpl->tpl_vars['feature'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['feature']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['variant']->value['features']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['feature']->key => $_smarty_tpl->tpl_vars['feature']->value) {
$_smarty_tpl->tpl_vars['feature']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['feature']->key;
?>
                            <?php echo $_smarty_tpl->tpl_vars['feature']->value['values_name'];?>
 <?php if ($_smarty_tpl->tpl_vars['i']->value<$_smarty_tpl->tpl_vars['total']->value) {?>*<?php }?>
                        <?php } ?>
                    </td>
                    <td>
                        <select name="variants[<?php echo $_smarty_tpl->tpl_vars['variant']->value['id'];?>
][in_stock]" class="form-control">
                            <option <?php if ($_smarty_tpl->tpl_vars['variant']->value['in_stock']==1) {?>selected<?php }?> value="1">В наявності</option>
                            <option <?php if ($_smarty_tpl->tpl_vars['variant']->value['in_stock']==2) {?>selected<?php }?>  value="2">Під замовлення</option>
                            <option <?php if ($_smarty_tpl->tpl_vars['variant']->value['in_stock']==0) {?>selected<?php }?>  value="0">Немає</option>
                        </select>
                    </td>
                    <?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['variant']->value['prices']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value) {
$_smarty_tpl->tpl_vars['group']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['group']->key;
?>
                        <td><input name="variants[<?php echo $_smarty_tpl->tpl_vars['variant']->value['id'];?>
][prices][<?php echo $_smarty_tpl->tpl_vars['group']->value['id'];?>
]" type="text" required class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['group']->value['price'];?>
"></td>
                    <?php } ?>
                    <td>
                        <button type="button" class="btn btn-danger b-products-rm-variant " title="Видалити" data-id="<?php echo $_smarty_tpl->tpl_vars['variant']->value['id'];?>
"><i class="fa fa-remove"></i></button>
                    </td>
                </tr>
            <?php } ?>
     </table>
        <?php } else { ?>
     <p style="text-align: center">Немає варіантів</p>
    <?php }?><?php }} ?>
