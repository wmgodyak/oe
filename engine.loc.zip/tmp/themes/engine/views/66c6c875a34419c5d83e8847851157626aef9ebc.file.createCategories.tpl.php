<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-04-01 10:08:43
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/shop/createCategories.tpl" */ ?>
<?php /*%%SmartyHeaderCode:132193855556fe1e7b7d1310-42362330%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '66c6c875a34419c5d83e8847851157626aef9ebc' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/shop/createCategories.tpl',
      1 => 1459494489,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '132193855556fe1e7b7d1310-42362330',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
    'token' => 0,
    'admin' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fe1e7b7e96d2_93626829',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fe1e7b7e96d2_93626829')) {function content_56fe1e7b7e96d2_93626829($_smarty_tpl) {?><form action="./plugins/productsCategories/process/<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
" method="post" id="productsCategoriesForm" class="form-horizontal">

    <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <?php echo $_smarty_tpl->getSubTemplate ("content/blocks/meta.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="content[status]" value="published">
    <input type="hidden" name="content[owner_id]" value="<?php echo $_smarty_tpl->tpl_vars['admin']->value['id'];?>
">
    <input type="hidden" name="content[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['parent_id'];?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">

</form><?php }} ?>
