<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-25 17:24:21
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/content/tags.tpl" */ ?>
<?php /*%%SmartyHeaderCode:212116090456f5474e2cde14-64141678%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c1dd26f2a28d033fb6104ca0680500993ad6f908' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/content/tags.tpl',
      1 => 1458919460,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '212116090456f5474e2cde14-64141678',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f5474e2ebe57_91754128',
  'variables' => 
  array (
    'languages' => 0,
    'lang' => 0,
    'content_tags' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f5474e2ebe57_91754128')) {function content_56f5474e2ebe57_91754128($_smarty_tpl) {?><fieldset>
    <legend>Мітки</legend>
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="content_published" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
</label>
            <div class="col-md-9">
                <input data-role="tagsinput" type="text" name="tags[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
]" id="tags_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" value="<?php if (isset($_smarty_tpl->tpl_vars['content_tags']->value[$_smarty_tpl->tpl_vars['lang']->value['id']])) {
echo implode(',',$_smarty_tpl->tpl_vars['content_tags']->value[$_smarty_tpl->tpl_vars['lang']->value['id']]);
}?>" class="tags-input form-control">
            </div>
        </div>
    <?php } ?>
</fieldset>

<style>

    .bootstrap-tagsinput {
        background-color: #fff;
        border: 1px solid #eee;
        display: inline-block;
        padding: 5px 5px 0;
        margin-bottom: 10px;
        color: #555;
        vertical-align: middle;
        border-radius: 3px;
        width: 100%;
        min-height: 37px;
        line-height: 20px;
        font-size: 0
    }

    .bootstrap-tagsinput input {
        position: relative;
        border: 0;
        box-shadow: none;
        outline: 0;
        background-color: transparent;
        padding: 0;
        margin: 0;
        width: auto !important;
        max-width: inherit;
        font-size: 14px
    }

    .bootstrap-tagsinput input:focus {
        border: 0;
        box-shadow: none
    }

    .bootstrap-tagsinput .tag {
        display: inline-block;
        margin-right: 5px;
        margin-bottom: 5px;
        padding: 8px;
        color: #fff;
        font-size: 14px;
        font-weight: normal;
        border-radius: 3px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        -o-user-select: none;
        user-select: none;
        cursor: default
    }

    .bootstrap-tagsinput .tag [data-role="remove"] {
        margin-left: 8px;
        cursor: pointer;
        opacity: .5;
        filter: alpha(opacity=50)
    }

    .bootstrap-tagsinput .tag [data-role="remove"]:after {
        content: "\F057";
        font-family: FontAwesome;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        -webkit-font-smoothing: antialiased
    }

    .bootstrap-tagsinput .tag [data-role="remove"]:hover, .bootstrap-tagsinput .tag [data-role="remove"]:active {
        opacity: 1;
        filter: alpha(opacity=100)
    }
    .bootstrap-tagsinput .tag.label-info{
        background: #0a6aa1;
    }
</style>
<?php }} ?>
