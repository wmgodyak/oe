<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-27 14:57:21
         compiled from "/var/www/engine.loc/themes/engine/views/widgets/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24361950157710814db9999-70302207%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9a9ae60ced61432a4888f36eb7702cc16a6ee0e0' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/widgets/form.tpl',
      1 => 1467028416,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24361950157710814db9999-70302207',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57710814dc6dc7_87185213',
  'variables' => 
  array (
    'widget_form' => 0,
    'widget' => 0,
    'area' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57710814dc6dc7_87185213')) {function content_57710814dc6dc7_87185213($_smarty_tpl) {?><form action="widgets/update" id="widgetForm" method="post">
    <?php echo $_smarty_tpl->tpl_vars['widget_form']->value;?>

    <input type="hidden" name="widget" value="<?php echo $_smarty_tpl->tpl_vars['widget']->value;?>
">
    <input type="hidden" name="area" value="<?php echo $_smarty_tpl->tpl_vars['area']->value;?>
">
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
</form><?php }} ?>
