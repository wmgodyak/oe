<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-21 09:49:53
         compiled from "/var/www/engine.loc/themes/engine/views/content/blocks/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:107107573956d4435adacd44-92993871%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5e06e1fd82e471277c590efa5fa26aa257ee02bf' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/blocks/content.tpl',
      1 => 1458316653,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '107107573956d4435adacd44-92993871',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56d4435adad132_21403568',
  'variables' => 
  array (
    't' => 0,
    'languages' => 0,
    'lang' => 0,
    'i' => 0,
    'content' => 0,
    'plugins' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d4435adad132_21403568')) {function content_56d4435adad132_21403568($_smarty_tpl) {?><fieldset>
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['legend_description'];?>
</legend>
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['lang']->key;
?>
        <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
            <div class="col-md-12">
                <textarea class="form-control info-content ckeditor" name="content_info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][content]" id="content_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_description" placeholder="[a-zA-Zа-яА-Я0-9]+"><?php echo $_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['content'];?>
</textarea>
            </div>
        </div>
    <?php } ?>
    <?php if (isset($_smarty_tpl->tpl_vars['plugins']->value['content'])) {
echo implode("\r\n",$_smarty_tpl->tpl_vars['plugins']->value['content']);
}?>
</fieldset><?php }} ?>
