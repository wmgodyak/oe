<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-31 11:49:50
         compiled from "/var/www/engine.loc/themes/engine/views/comments/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:133082048156fcdd6b96e640-77759735%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '892487b4de96b483ed3c9c2349440cb018dd0e61' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/comments/form.tpl',
      1 => 1459414184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '133082048156fcdd6b96e640-77759735',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fcdd6b96ec64_90704955',
  'variables' => 
  array (
    'data' => 0,
    't' => 0,
    'token' => 0,
    'admin' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fcdd6b96ec64_90704955')) {function content_56fcdd6b96ec64_90704955($_smarty_tpl) {?><form action="./comments/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal">
    <div class="form-group">
        <label class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['comments']['pib'];?>
</label>
        <div class="col-md-9">
            <?php echo $_smarty_tpl->tpl_vars['data']->value['user']['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['user']['surname'];?>

        </div>
    </div>
    <div class="form-group">
        <label for="data_message" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['comments']['message'];?>
</label>
        <div class="col-md-9">
            <textarea name="data[message]" id="data_message" required  class="form-control" style="height: 250px;"><?php echo $_smarty_tpl->tpl_vars['data']->value['message'];?>
</textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="data_message" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['comments']['reply_message'];?>
</label>
        <div class="col-md-9">
            <textarea name="reply[message]" id="reply_message" class="form-control" style="height: 150px;" placeholder="<?php echo $_smarty_tpl->tpl_vars['t']->value['comments']['reply_message_not_r'];?>
"></textarea>
        </div>
    </div>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="data[status]" value="approved">
    <input type="hidden" name="reply[parent_id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
">
    <input type="hidden" name="reply[status]" value="approved">
    <input type="hidden" name="reply[content_id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['content_id'];?>
">
    <input type="hidden" name="reply[users_id]" value="<?php echo $_smarty_tpl->tpl_vars['admin']->value['id'];?>
">
</form><?php }} ?>
