<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 09:38:39
         compiled from "/var/www/engine.loc/themes/engine/views/contentTypes/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3790300075762ebbc5b6853-51684868%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '11202b342ca9b0bbce29bdbb108b30f3ceddf7e9' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/contentTypes/form.tpl',
      1 => 1467657207,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3790300075762ebbc5b6853-51684868',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5762ebbc6943b8_53815673',
  'variables' => 
  array (
    'data' => 0,
    'action' => 0,
    't' => 0,
    'imagesSizes' => 0,
    'item' => 0,
    'token' => 0,
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5762ebbc6943b8_53815673')) {function content_5762ebbc6943b8_53815673($_smarty_tpl) {?><form class="form-horizontal" action="contentTypes/process/<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>"  method="post" id="form" data-success="engine.contentTypes.on<?php echo ucfirst($_smarty_tpl->tpl_vars['action']->value);?>
Success">
    <div class="row">
        <div class="col-md-8">
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['legend_main'];?>
</legend>
                <div class="form-group">
                    <label for="data_name" class="col-md-2 control-label required"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentTypes']['name'];?>
</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" name="data[name]" id="data_name" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['name'])) {
echo $_smarty_tpl->tpl_vars['data']->value['name'];
}?>" required placeholder="[a-zA-Zа-яА-Я0-9]+">
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_type" class="col-md-2 control-label required"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentTypes']['type'];?>
</label>
                    <div class="col-md-10">
                        <input <?php if (isset($_smarty_tpl->tpl_vars['data']->value['isfolder'])&&$_smarty_tpl->tpl_vars['data']->value['isfolder']==1) {?>readonly<?php }?> type="text" class="form-control" name="data[type]" id="data_type" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['type'])) {
echo $_smarty_tpl->tpl_vars['data']->value['type'];
}?>" required placeholder="[a-z0-9]+">
                    </div>
                </div>
            </fieldset>
        </div>
        <div class="col-md-4">
            
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['params'];?>
</legend>
                <div class="form-group">
                    <div class="col-md-8 col-md-offset-4">
                        <div class="checkbox">
                            <label>
                                <input type="hidden" name="data[settings][ext_url]" value="0">
                                <input <?php if (isset($_smarty_tpl->tpl_vars['data']->value['settings']['ext_url'])&&$_smarty_tpl->tpl_vars['data']->value['settings']['ext_url']==1) {?>checked<?php }?> id="data_settings_ext_url" type="checkbox" name="data[settings][ext_url]" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['content_type_ext_url'];?>

                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group" id="data_settings_parent_id_cnt" style="display:<?php if (isset($_smarty_tpl->tpl_vars['data']->value['settings']['ext_url'])&&$_smarty_tpl->tpl_vars['data']->value['settings']['ext_url']==1) {?>block<?php } else { ?>none<?php }?>">
                    <label for="settings_parent_id" class="col-md-4 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['parent_page_id'];?>
</label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="data[settings][parent_id]" id="settings_parent_id" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['settings']['parent_id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['settings']['parent_id'];
}?>" placeholder="[0-9]+">
                        <p class="help-block"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['parent_id_help'];?>
</p>
                    </div>
                </div>
                <div class="form-group">
                    <label for="settings_parent_id" class="col-md-4 control-label">
                        <?php echo $_smarty_tpl->tpl_vars['t']->value['features']['images_sizes'];?>

                        <a href="javascript:;" class="ct-create-images-size" title="<?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
"><i class="fa fa-plus-circle"></i></a>
                    </label>
                    <div class="col-md-8">
                        <select name="ct_images_sizes[]" id="contentImagesSizes" class="form-control" multiple>
                            <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['imagesSizes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                                <option <?php if (in_array($_smarty_tpl->tpl_vars['item']->value['id'],$_smarty_tpl->tpl_vars['data']->value['images_sizes'])) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['size'];?>
 (<?php echo $_smarty_tpl->tpl_vars['item']->value['width'];?>
x<?php echo $_smarty_tpl->tpl_vars['item']->value['height'];?>
)</option>
                            <?php } ?>
                        </select>
                        <p class="help-block"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['images_sizes_help'];?>
</p>
                    </div>
                </div>
                <?php if (isset($_smarty_tpl->tpl_vars['data']->value['parent_id'])&&$_smarty_tpl->tpl_vars['data']->value['parent_id']) {?>
                <div class="form-group">
                    <div class="col-md-8 col-md-offset-4">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" name="data[settings][modules_ext]" value="0">
                                <input <?php if ($_smarty_tpl->tpl_vars['data']->value['settings']['modules_ext']==1) {?>checked<?php }?> id="data_settings_modules_ext" type="checkbox" name="data[settings][modules_ext]" value="1"> <?php echo $_smarty_tpl->tpl_vars['t']->value['contentTypes']['modules_ext'];?>

                            </label>
                        </div>
                    </div>
                </div>
                <?php }?>
            </fieldset>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['contentTypes']['template_src'];?>
</legend>
                <div class="form-group">
                    <div class="col-md-12">
                        <textarea name="template" id="template" style="width: 100%; height: 900px;"><?php if (isset($_smarty_tpl->tpl_vars['data']->value['template'])) {
echo $_smarty_tpl->tpl_vars['data']->value['template'];
}?></textarea>
                    </div>
                </div>
            </fieldset>
        </div>
    </div>

     <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
     <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
     <input type="hidden" id="typesID" name="data[parent_id]" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['parent_id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['parent_id'];
}?>">
     <input type="hidden" id="subTypesID" name="data[id]" value="<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>">
</form>

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/lib/codemirror.css">
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/lib/codemirror.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/css.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/php.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/htmlmixed.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/sql.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/codemirror/mode/javascript.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    var cm = CodeMirror.fromTextArea(document.getElementById('template'), {
        theme: 'neo',
        //                        mode: 'htmlmixed',
        styleActiveLine: true,
        lineNumbers: true,
        lineWrapping: true,
        autoCloseTags: true,
        matchBrackets: true
    });

    cm.on("change", function() {
        cm.save();
        var c = cm.getValue();
        $("textarea#template").html(c);
    });
<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 type="text/template" id="sizesCreate" >
    <form action="./contentImagesSizes/process" method="post" id="formCreateSize" class="form-horizontal">
        <div class="form-group">
            <label for="data_size" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImagesSizes']['size'];?>
</label>
            <div class="col-sm-9">
                <input name="data[size]" id="data_size"  class="form-control" required>
            </div>
        </div>
        <div class="form-group">
            <label for="data_width" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImagesSizes']['width'];?>
</label>
            <div class="col-sm-9">
                <input name="data[width]" id="data_width"  class="form-control" required onchange="this.value = parseInt(this.value); if (this.value == 'NaN') this.value=0">
            </div>
        </div>
        <div class="form-group">
            <label for="data_height" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['contentImagesSizes']['height'];?>
</label>
            <div class="col-sm-9">
                <input name="data[height]" id="data_height"  class="form-control" required onchange="this.value = parseInt(this.value); if (this.value == 'NaN') this.value=0">
            </div>
        </div>
        <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
        <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
    </form>
<?php echo '</script'; ?>
><?php }} ?>
