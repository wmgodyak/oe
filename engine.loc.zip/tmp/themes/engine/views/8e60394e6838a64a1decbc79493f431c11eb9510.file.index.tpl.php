<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 22:26:19
         compiled from "/var/www/engine.loc/themes/engine/views/dashboard/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1167864936577ab85bbec050-02534675%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8e60394e6838a64a1decbc79493f431c11eb9510' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/dashboard/index.tpl',
      1 => 1467044969,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1167864936577ab85bbec050-02534675',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'events' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577ab85bbef398_78269190',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577ab85bbef398_78269190')) {function content_577ab85bbef398_78269190($_smarty_tpl) {?><div class="row">
    <?php echo $_smarty_tpl->tpl_vars['events']->value->call('dashboard');?>

</div>
<?php }} ?>
