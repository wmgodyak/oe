<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 11:21:52
         compiled from "/var/www/engine.loc/themes/engine/views/shop/products/features/selected.tpl" */ ?>
<?php /*%%SmartyHeaderCode:973571798577a1ca0133998-28785787%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fa6aeb855f46d1dde1a52fd38534f1fdb8bd4c1e' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/products/features/selected.tpl',
      1 => 1467616402,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '973571798577a1ca0133998-28785787',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'features' => 0,
    'feature' => 0,
    'value' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577a1ca01568e2_44935081',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577a1ca01568e2_44935081')) {function content_577a1ca01568e2_44935081($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['feature'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['feature']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['features']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['feature']->key => $_smarty_tpl->tpl_vars['feature']->value) {
$_smarty_tpl->tpl_vars['feature']->_loop = true;
?>
    <div class="row" id="scf-<?php echo $_smarty_tpl->tpl_vars['feature']->value['fc_id'];?>
">
        <div class="form-group">
            <label for="features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
" class="col-md-4 control-label">
                <?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>

                <a class="spf-values-add" style="right: 30px" data-id="<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
" href="javascript:void(0)" title="Додати значення"><i class="fa fa-plus"></i></a>
                
                
            </label>
            <div class="col-md-8">
                <select name="products_features[<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
]<?php if ($_smarty_tpl->tpl_vars['feature']->value['multiple']) {?>[]<?php }?>" <?php if ($_smarty_tpl->tpl_vars['feature']->value['multiple']) {?>multiple<?php }?> id="products_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
"  class="form-control">
                    <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['feature']->value['values']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->_loop = true;
?>
                        <option <?php echo $_smarty_tpl->tpl_vars['value']->value['selected'];?>
 value="<?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
                    <?php } ?>
                </select>
            </div>
        </div>
    </div>
    
<?php } ?><?php }} ?>
