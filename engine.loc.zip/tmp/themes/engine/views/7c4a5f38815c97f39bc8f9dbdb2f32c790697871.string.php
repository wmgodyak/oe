<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-18 13:24:13
         compiled from "7c4a5f38815c97f39bc8f9dbdb2f32c790697871" */ ?>
<?php /*%%SmartyHeaderCode:6860405695765214d2b5141-72714643%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c4a5f38815c97f39bc8f9dbdb2f32c790697871' => 
    array (
      0 => '7c4a5f38815c97f39bc8f9dbdb2f32c790697871',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '6860405695765214d2b5141-72714643',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5765214d2d13d4_57845042',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5765214d2d13d4_57845042')) {function content_5765214d2d13d4_57845042($_smarty_tpl) {?>Вітаємо <?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
. Вам надіслано доступи до системи <?php echo $_smarty_tpl->tpl_vars['t']->value['system']['name'];?>
.
Ваш лоігн: <?php echo $_smarty_tpl->tpl_vars['data']->value['email'];?>

Ваш пароль: <?php echo $_smarty_tpl->tpl_vars['data']->value['password'];?>

Отримати доступ ви можете за адресою: <?php echo $_smarty_tpl->tpl_vars['data']->value['url'];?>
<?php }} ?>
