<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-31 16:41:09
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/comments/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:213822668756fcfb4fdd4dc4-87911205%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '987073930551992946907144c09da63619fe57dc' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/comments/index.tpl',
      1 => 1459431665,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '213822668756fcfb4fdd4dc4-87911205',
  'function' => 
  array (
    'renderComment' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fcfb4fde27f8_35606807',
  'variables' => 
  array (
    'comments' => 0,
    'comments_total' => 0,
    'offset' => 0,
    'item' => 0,
    'c' => 0,
  ),
  'has_nocache_code' => 0,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fcfb4fde27f8_35606807')) {function content_56fcfb4fde27f8_35606807($_smarty_tpl) {?>
<?php if (count($_smarty_tpl->tpl_vars['comments']->value)) {?>
    <h3>Коментарі (<?php echo $_smarty_tpl->tpl_vars['comments_total']->value;?>
)</h3>
    <div class="row">
        <?php if (!function_exists('smarty_template_function_renderComment')) {
    function smarty_template_function_renderComment($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderComment']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
            <div class="col-md-12 col-md-offset-<?php echo $_smarty_tpl->tpl_vars['offset']->value;?>
">
                <p><small>Додано: <?php echo $_smarty_tpl->tpl_vars['item']->value['created'];?>
</small></p>
                <p><?php echo $_smarty_tpl->tpl_vars['item']->value['message'];?>
</p>
                <p><small>Автор: <?php echo $_smarty_tpl->tpl_vars['item']->value['user']['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['user']['surname'];?>
</small></p>
                <hr>
            </div>
            <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
                <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
                    <?php smarty_template_function_renderComment($_smarty_tpl,array('item'=>$_smarty_tpl->tpl_vars['c']->value,'offset'=>$_smarty_tpl->tpl_vars['offset']->value+1));?>

                <?php } ?>
            <?php }?>
        <?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>

        <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['comments']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
            <?php smarty_template_function_renderComment($_smarty_tpl,array('item'=>$_smarty_tpl->tpl_vars['item']->value,'offset'=>0));?>

        <?php } ?>
    </div>
<?php }?><?php }} ?>
