<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-04-01 10:36:14
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/shop/categories_select.tpl" */ ?>
<?php /*%%SmartyHeaderCode:48793406956fe22be04d353-25163983%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '619f1c605dd8e4d5bdc542729176d1f57fe426be' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/shop/categories_select.tpl',
      1 => 1459496174,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '48793406956fe22be04d353-25163983',
  'function' => 
  array (
    'renderSelect' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
    'renderMainSelect' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fe22be0a8558_29515246',
  'variables' => 
  array (
    'items' => 0,
    'item' => 0,
    'selected_categories' => 0,
    'selected' => 0,
    'parent' => 0,
    't' => 0,
    'categories' => 0,
    'main_categories_id' => 0,
  ),
  'has_nocache_code' => 0,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fe22be0a8558_29515246')) {function content_56fe22be0a8558_29515246($_smarty_tpl) {?><?php if (!function_exists('smarty_template_function_renderMainSelect')) {
    function smarty_template_function_renderMainSelect($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderMainSelect']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
    <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
        <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
            <optgroup label="<?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
">
                <?php smarty_template_function_renderSelect($_smarty_tpl,array('items'=>$_smarty_tpl->tpl_vars['item']->value['items'],'parent'=>$_smarty_tpl->tpl_vars['item']->value['name'],'selected'=>$_smarty_tpl->tpl_vars['selected_categories']->value));?>

            </optgroup>
        <?php } else { ?>
            <option <?php if ($_smarty_tpl->tpl_vars['selected']->value==$_smarty_tpl->tpl_vars['item']->value['id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php if ($_smarty_tpl->tpl_vars['parent']->value) {
echo $_smarty_tpl->tpl_vars['parent']->value;?>
 / <?php }
echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
        <?php }?>
    <?php } ?>
<?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>

<?php if (!function_exists('smarty_template_function_renderSelect')) {
    function smarty_template_function_renderSelect($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderSelect']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
    <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
        <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
            <optgroup label="<?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
">
                <?php smarty_template_function_renderSelect($_smarty_tpl,array('items'=>$_smarty_tpl->tpl_vars['item']->value['items'],'parent'=>$_smarty_tpl->tpl_vars['item']->value['name'],'selected'=>$_smarty_tpl->tpl_vars['selected_categories']->value));?>

            </optgroup>
        <?php } else { ?>
            <option <?php if (in_array($_smarty_tpl->tpl_vars['item']->value['id'],$_smarty_tpl->tpl_vars['selected_categories']->value)) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php if ($_smarty_tpl->tpl_vars['parent']->value) {
echo $_smarty_tpl->tpl_vars['parent']->value;?>
 / <?php }
echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
        <?php }?>
    <?php } ?>
<?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>


<div class="form-group">
    <label for="content_published" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['products']['main_category'];?>
</label>
    <div class="col-md-9">
        <select name="main_categories_id" id="main_categories_id" class="form-control" required>
            <?php smarty_template_function_renderMainSelect($_smarty_tpl,array('items'=>$_smarty_tpl->tpl_vars['categories']->value,'selected'=>$_smarty_tpl->tpl_vars['main_categories_id']->value));?>

        </select>
    </div>
</div>

<div class="form-group">
    <label for="content_published" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['products']['categories'];?>
</label>
    <div class="col-md-9">
        <select name="categories[]" multiple id="categories" class="form-control" required>
            <?php smarty_template_function_renderSelect($_smarty_tpl,array('items'=>$_smarty_tpl->tpl_vars['categories']->value,'selected'=>$_smarty_tpl->tpl_vars['selected_categories']->value));?>

        </select>
    </div>
</div>
<?php }} ?>
