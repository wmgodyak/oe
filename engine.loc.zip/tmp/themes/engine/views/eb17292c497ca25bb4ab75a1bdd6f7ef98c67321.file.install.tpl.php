<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-23 16:01:54
         compiled from "/var/www/engine.loc/themes/engine/views/modules/install.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21763874656f2a1d2b4fa53-02354461%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eb17292c497ca25bb4ab75a1bdd6f7ef98c67321' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/modules/install.tpl',
      1 => 1458741712,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21763874656f2a1d2b4fa53-02354461',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    't' => 0,
    'components' => 0,
    'c' => 0,
    'place' => 0,
    'token' => 0,
    'plugin' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f2a1d2b7acc6_20418056',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f2a1d2b7acc6_20418056')) {function content_56f2a1d2b7acc6_20418056($_smarty_tpl) {?><form action="./modules/install" method="post" id="modulesInstall" class="form-horizontal">
    <div class="form-group">
        <label for="components" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['modules']['install_label_components'];?>
</label>
        <div class="col-sm-9">
            <select name="components[]" id="components" multiple required class="form-control">
                <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['components']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['c']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['c']->value['name'];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="data_place" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['modules']['install_label_place'];?>
</label>
        <div class="col-sm-9">
            <select name="data[place]" id="data_place" required class="form-control">
                <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['place']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['c']->key;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['c']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['c']->value;?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="c" value="<?php echo $_smarty_tpl->tpl_vars['plugin']->value;?>
">
    <input type="hidden" name="action" value="install">
</form><?php }} ?>
