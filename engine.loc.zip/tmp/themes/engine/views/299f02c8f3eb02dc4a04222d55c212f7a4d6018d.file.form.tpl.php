<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-22 17:34:39
         compiled from "/var/www/engine.loc/themes/engine/views/nav/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:145704617756e95807add9c1-43838746%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '299f02c8f3eb02dc4a04222d55c212f7a4d6018d' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/nav/form.tpl',
      1 => 1458660872,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '145704617756e95807add9c1-43838746',
  'function' => 
  array (
    'renderSelect' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56e95807b04e48_81102097',
  'variables' => 
  array (
    'items' => 0,
    'item' => 0,
    'parent' => 0,
    'data' => 0,
    'action' => 0,
    't' => 0,
    'i' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => 0,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e95807b04e48_81102097')) {function content_56e95807b04e48_81102097($_smarty_tpl) {?><?php if (!function_exists('smarty_template_function_renderSelect')) {
    function smarty_template_function_renderSelect($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderSelect']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
    <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
        <option value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php if ($_smarty_tpl->tpl_vars['parent']->value) {
echo $_smarty_tpl->tpl_vars['parent']->value;?>
 / <?php }
echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
        <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
            <?php smarty_template_function_renderSelect($_smarty_tpl,array('items'=>$_smarty_tpl->tpl_vars['item']->value['items'],'parent'=>$_smarty_tpl->tpl_vars['item']->value['name']));?>

        <?php }?>
    <?php } ?>
<?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>

<form class="form-horizontal" action="nav/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
"  method="post" id="form" data-success="engine.nav.on<?php echo ucfirst($_smarty_tpl->tpl_vars['action']->value);?>
Success">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['legend_main'];?>
</legend>
                <div class="form-group">
                    <label for="data_name" class="col-md-3 control-label required"><?php echo $_smarty_tpl->tpl_vars['t']->value['nav']['name'];?>
</label>
                    <div class="col-md-9">
                        <input type="text" class="form-control" name="data[name]" id="data_name" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
" required placeholder="[a-zA-Zа-яА-Я0-9]+">
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_code" class="col-md-3 control-label required"><?php echo $_smarty_tpl->tpl_vars['t']->value['nav']['code'];?>
</label>
                    <div class="col-md-9">
                        <input type="text" class="form-control" name="data[code]" id="data_code" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['code'];?>
" required placeholder="[a-z]+">
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['nav']['items'];?>
</legend>
                <?php if ($_smarty_tpl->tpl_vars['action']->value=='create') {?>
                    <p>Створення, редагування , сортування пунктів меню досутпні при редагуванні</p>
                <?php } else { ?>
                    <div class="form-group">
                        <div class="col-md-12">
                            <select id="selItems" class="form-control" data-nav="<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
">
                                <option value=""><?php echo $_smarty_tpl->tpl_vars['i']->value['common']['select'];?>
</option>
                                <?php smarty_template_function_renderSelect($_smarty_tpl,array('items'=>$_smarty_tpl->tpl_vars['items']->value));?>

                            </select>
                        </div>
                    </div>
                <?php }?>

                <div class="row">
                    <div class="col-md-12" id="navItems"></div>
                </div>
            </fieldset>
        </div>
    </div>

    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
    <input type="hidden" name="data[id]" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
">
    <input type="hidden" name="pos" id="pos" value="">
</form>

<?php echo '<script'; ?>
>var selected_items = <?php echo json_encode($_smarty_tpl->tpl_vars['data']->value['items']);?>
<?php echo '</script'; ?>
>


    <?php echo '<script'; ?>
 type="text/template" id="nItems" >
        <table class="table table-bordered" id="tblItems">
            <thead>
                <tr>
                    <th style="width: 20px;"><i class="fa fa-list"></i></th>
                    <th style="width: 20px;">#</th>
                    <th>Назва</th>
                    <th style="width: 20px;">Видалити</th>
                </tr>
            </thead>
            <tbody>
                <?php echo '<%'; ?>
 for(var i=0;i < items.length; i++) { <?php echo '%>'; ?>

                <tr id="nav-item-<?php echo '<%'; ?>
- items[i].id <?php echo '%>'; ?>
">
                    <td class="sort" style="cursor: move;"><i class="fa fa-list"></i></td>
                    <td><?php echo '<%'; ?>
- items[i].content_id <?php echo '%>'; ?>
</td>
                    <td><?php echo '<%'; ?>
- items[i].name <?php echo '%>'; ?>
</td>
                    <td><a class="b-nav-item-delete" data-id="<?php echo '<%'; ?>
- items[i].id <?php echo '%>'; ?>
" title="Видалити" href="javascript:;"><i class="fa fa-remove"></i></a></td>
                </tr>
                <?php echo '<%'; ?>
 } <?php echo '%>'; ?>

            </tbody>
        </table>
    <?php echo '</script'; ?>
>
<?php }} ?>
