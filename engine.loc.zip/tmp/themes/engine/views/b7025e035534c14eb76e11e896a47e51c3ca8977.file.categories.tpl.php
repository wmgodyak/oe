<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-21 09:49:51
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/content/posts/categories.tpl" */ ?>
<?php /*%%SmartyHeaderCode:90735812256ead44b8cd409-40290323%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b7025e035534c14eb76e11e896a47e51c3ca8977' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/content/posts/categories.tpl',
      1 => 1458318246,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '90735812256ead44b8cd409-40290323',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56ead44b8dc4c7_20510202',
  'variables' => 
  array (
    'tree_icon' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56ead44b8dc4c7_20510202')) {function content_56ead44b8dc4c7_20510202($_smarty_tpl) {?><div class="title">
    <i class="fa <?php echo $_smarty_tpl->tpl_vars['tree_icon']->value;?>
"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['postsCategories']['tree_title'];?>
</span>
    <button class="btn btn-link b-posts-categories-create" ><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</button>
</div>
<div class="pages-tree" id="postsCategories"></div><?php }} ?>
