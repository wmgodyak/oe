<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-04-01 15:52:59
         compiled from "/var/www/engine.loc/themes/engine/views/payment/edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:53913230656fe59d82ee399-30691996%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd84852c1b0ec0f76e5c20bda237d997b0fdf7d91' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/payment/edit.tpl',
      1 => 1459515176,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '53913230656fe59d82ee399-30691996',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fe59d8346dc9_81080768',
  'variables' => 
  array (
    'data' => 0,
    'languages' => 0,
    'lang' => 0,
    't' => 0,
    'delivery' => 0,
    'selected' => 0,
    'item' => 0,
    'token' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fe59d8346dc9_81080768')) {function content_56fe59d8346dc9_81080768($_smarty_tpl) {?><form action="./payment/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal">

    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['payment']['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
)</label>
            <div class="col-sm-9">
                <input name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" required id="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['name'];?>
">
            </div>
        </div>
        <div class="form-group">
            <label for="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['payment']['description'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
)</label>
            <div class="col-sm-9">
                <textarea name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][description]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" id="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control" ><?php echo $_smarty_tpl->tpl_vars['data']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['description'];?>
</textarea>
            </div>
        </div>
    <?php } ?>
    <div class="form-group">
        <label for="data_free_from" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['payment']['delivery'];?>
</label>
        <div class="col-sm-9">
            <select name="delivery[]" multiple id="data_delivery" required class="form-control">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['delivery']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                    <option <?php if (isset($_smarty_tpl->tpl_vars['selected']->value)&&in_array($_smarty_tpl->tpl_vars['item']->value['id'],$_smarty_tpl->tpl_vars['selected']->value)) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>

    <div class="form-group">
        <label for="data_published" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['payment']['published'];?>
</label>
        <div class="col-sm-9">
            <input type="hidden"  name="data[published]"  class="form-control" value="0" >
            <input type="checkbox" <?php if ($_smarty_tpl->tpl_vars['data']->value['published']) {?>checked<?php }?> name="data[published]" id="data_published" value="1" >
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
</form><?php }} ?>
