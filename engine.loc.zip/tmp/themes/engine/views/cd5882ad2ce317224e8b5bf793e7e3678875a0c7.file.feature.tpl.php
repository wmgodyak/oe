<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-18 01:18:34
         compiled from "/var/www/engine.loc/themes/engine/views/contentFeatures/feature.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19975912115764773a871ef3-35085491%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cd5882ad2ce317224e8b5bf793e7e3678875a0c7' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/contentFeatures/feature.tpl',
      1 => 1466020694,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19975912115764773a871ef3-35085491',
  'function' => 
  array (
    'renderFeature' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
  ),
  'variables' => 
  array (
    'feature' => 0,
    'languages' => 0,
    'lang' => 0,
    't' => 0,
    'item' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => 0,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5764773aa08c29_31908862',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5764773aa08c29_31908862')) {function content_5764773aa08c29_31908862($_smarty_tpl) {?><?php if (!function_exists('smarty_template_function_renderFeature')) {
    function smarty_template_function_renderFeature($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderFeature']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
<?php if ($_smarty_tpl->tpl_vars['feature']->value['type']=='text') {?>
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="content_features_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>
</label>
            <div class="col-md-9">
                <input name="content_features[<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
][<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" <?php if ($_smarty_tpl->tpl_vars['feature']->value['required']) {?>required<?php }?> id="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
x<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['feature']->value['values'][$_smarty_tpl->tpl_vars['lang']->value['id']];?>
">
            </div>
        </div>
    <?php } ?>
<?php } elseif ($_smarty_tpl->tpl_vars['feature']->value['type']=='textarea') {?>
    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
        <div class="form-group">
            <label for="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
x<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>
</label>
            <div class="col-md-9">
                <textarea name="content_features[<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
][<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
]"  placeholder="<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
" <?php if ($_smarty_tpl->tpl_vars['feature']->value['required']) {?>required<?php }?> id="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
x<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
"  class="form-control"><?php echo $_smarty_tpl->tpl_vars['feature']->value['values'][$_smarty_tpl->tpl_vars['lang']->value['id']];?>
</textarea>
            </div>
        </div>
    <?php } ?>
<?php } elseif ($_smarty_tpl->tpl_vars['feature']->value['type']=='select') {?>
    <div class="form-group">
        <label for="content_features" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>
 <?php if (!$_smarty_tpl->tpl_vars['feature']->value['disable_values']) {?><a data-parent="<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['t']->value['features']['add_value'];?>
" class="b-cf-add-val" href="javascript:;"><i class="fa fa-plus-circle"></i></a><?php }?></label>
        <?php if (!$_smarty_tpl->tpl_vars['feature']->value['disable_values']) {?>
        <div class="col-md-9">
            <select name="content_features[<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
]<?php if ($_smarty_tpl->tpl_vars['feature']->value['multiple']) {?>[]<?php }?>" <?php if ($_smarty_tpl->tpl_vars['feature']->value['multiple']) {?>multiple<?php }?> id="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
"  class="form-control cf-feature-select">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['feature']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                    <option <?php if ($_smarty_tpl->tpl_vars['item']->value['selected']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
                <?php } ?>
            </select>
        </div>
        <?php }?>
    </div>
<?php } elseif ($_smarty_tpl->tpl_vars['feature']->value['type']=='file') {?>
    <div class="form-group">
        <label for="content_features" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>
</label>
        <div class="col-md-7">
            <input type="text" readonly name="content_features[<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
]" id="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
"  class="form-control"  value="<?php echo $_smarty_tpl->tpl_vars['feature']->value['values'][0];?>
">
        </div>
        <div class="col-md-2">
            <button class="btn cf-file-browse" type="button" data-target="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
"><i class="fa fa-file"></i></button>
        </div>
    </div>
<?php } elseif ($_smarty_tpl->tpl_vars['feature']->value['type']=='number') {?>

    
    <div class="form-group">
        <label for="content_features" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>
</label>
        <div class="col-md-9">
            <input type="text" name="content_features[<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
]" id="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
"  class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['feature']->value['values'][0];?>
">
        </div>
    </div>
<?php } elseif ($_smarty_tpl->tpl_vars['feature']->value['type']=='checkbox') {?>
    <div class="col-md-9 col-md-offset-3">
        <div class="checkbox">
            <label>
                <input type="hidden" name="content_features[<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
]" value="0">
                <input <?php if ($_smarty_tpl->tpl_vars['feature']->value['checked']) {?>checked<?php }?> type="checkbox" name="content_features[<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
]" id="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
" value="1">
                 <?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>

            </label>
        </div>
    </div>
<?php } elseif ($_smarty_tpl->tpl_vars['feature']->value['type']=='folder') {?>
    <div class="row">
        <div class="col-md-11 col-md-offset-1">
            <div class="row">
                <div class="col-md-12">
                    <h3><?php echo $_smarty_tpl->tpl_vars['feature']->value['name'];?>
 <a href="javascript:;" class="b-ct-features-add" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
" data-parent="<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
"><i class="fa fa-plus-circle"></i> <?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</a></h3>
                </div>
            </div>
            <div class="row">
                <div id="content_features_<?php echo $_smarty_tpl->tpl_vars['feature']->value['id'];?>
">
                    <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['feature']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                        <?php $_smarty_tpl->createLocalArrayVariable('item', null, 0);
$_smarty_tpl->tpl_vars['item']->value['disable_values'] = $_smarty_tpl->tpl_vars['feature']->value['disable_values'];?>
                        <?php smarty_template_function_renderFeature($_smarty_tpl,array('feature'=>$_smarty_tpl->tpl_vars['item']->value));?>

                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
<?php } else { ?>
    <p>Wrong feature type</p>
    <pre><?php echo print_r($_smarty_tpl->tpl_vars['feature']->value);?>
</pre>
<?php }?>
<?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>

<?php smarty_template_function_renderFeature($_smarty_tpl,array('feature'=>$_smarty_tpl->tpl_vars['feature']->value));?>
<?php }} ?>
