<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-03 16:41:47
         compiled from "/var/www/engine.loc/themes/engine/views/plugins/edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:144864724656d70c5bee2fa9-53661840%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '22ddce39e9d3fa698e5243b90c5355b02efc5b05' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/plugins/edit.tpl',
      1 => 1457016105,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '144864724656d70c5bee2fa9-53661840',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56d70c5bf30395_62958664',
  'variables' => 
  array (
    'data' => 0,
    't' => 0,
    'components' => 0,
    'c' => 0,
    'place' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d70c5bf30395_62958664')) {function content_56d70c5bf30395_62958664($_smarty_tpl) {?><form action="./plugins/process/<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
" method="post" id="form" class="form-horizontal">
    <div class="form-group">
        <label for="components" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['plugins']['install_label_components'];?>
</label>
        <div class="col-sm-9">
            <select name="components[]" id="components" multiple required class="form-control">
                <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['components']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
                    <option <?php if (in_array($_smarty_tpl->tpl_vars['c']->value['id'],$_smarty_tpl->tpl_vars['data']->value['components'])) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['c']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['c']->value['name'];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="data_place" class="col-sm-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['plugins']['install_label_place'];?>
</label>
        <div class="col-sm-9">
            <select name="data[place]" id="data_place" required class="form-control">
                <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['place']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['c']->key;
?>
                    <option <?php if ($_smarty_tpl->tpl_vars['data']->value['place']==$_smarty_tpl->tpl_vars['c']->value) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['c']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['c']->value;?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="update">
</form><?php }} ?>
