<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 09:55:34
         compiled from "/var/www/engine.loc/themes/engine/views/banners/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:100716168257713f344330a1-43475017%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8972bc37cd341f48f841c5b560c4754a24cf05ef' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/banners/index.tpl',
      1 => 1467182691,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '100716168257713f344330a1-43475017',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57713f34448fc7_50293583',
  'variables' => 
  array (
    'places' => 0,
    'place' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57713f34448fc7_50293583')) {function content_57713f34448fc7_50293583($_smarty_tpl) {?><div id="places">
    <ul>
        <?php  $_smarty_tpl->tpl_vars['place'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['place']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['places']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['place']->key => $_smarty_tpl->tpl_vars['place']->value) {
$_smarty_tpl->tpl_vars['place']->_loop = true;
?>
        <li style="position: relative;"><a href="module/run/banners/place/<?php echo $_smarty_tpl->tpl_vars['place']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['place']->value['name'];?>
 [<?php echo $_smarty_tpl->tpl_vars['place']->value['code'];?>
]</a> <span style="position: absolute;top:0;right:0;;" class="b-banners-places-delete" title="Видалити" data-id="<?php echo $_smarty_tpl->tpl_vars['place']->value['id'];?>
"><i class="fa fa-remove"></i></span></li>
        <?php } ?>
        <li><a href="module/run/banners/places/create"><i class="fa fa-plus"></i></a></li>
    </ul>
</div>
<?php }} ?>
