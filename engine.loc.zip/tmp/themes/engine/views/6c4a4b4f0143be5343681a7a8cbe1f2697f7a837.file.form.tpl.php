<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-18 15:41:35
         compiled from "/var/www/engine.loc/themes/engine/views/admins/groups/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13167248815765403e050ce6-25609265%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6c4a4b4f0143be5343681a7a8cbe1f2697f7a837' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/admins/groups/form.tpl',
      1 => 1466253693,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13167248815765403e050ce6-25609265',
  'function' => 
  array (
    'renderGroups' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5765403e0bd182_88755998',
  'variables' => 
  array (
    'selected' => 0,
    'group' => 0,
    'item' => 0,
    'parent' => 0,
    'c' => 0,
    'data' => 0,
    't' => 0,
    'groups' => 0,
    'languages' => 0,
    'lang' => 0,
    'info' => 0,
    'action' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => 0,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5765403e0bd182_88755998')) {function content_5765403e0bd182_88755998($_smarty_tpl) {?><?php if (!function_exists('smarty_template_function_renderGroups')) {
    function smarty_template_function_renderGroups($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderGroups']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
    <option <?php if ($_smarty_tpl->tpl_vars['selected']->value==$_smarty_tpl->tpl_vars['group']->value['id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php if (isset($_smarty_tpl->tpl_vars['parent']->value)) {
echo $_smarty_tpl->tpl_vars['parent']->value;?>
 / <?php }
echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
    <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
        <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
            <?php smarty_template_function_renderGroups($_smarty_tpl,array('item'=>$_smarty_tpl->tpl_vars['c']->value,'selected'=>$_smarty_tpl->tpl_vars['selected']->value,'parent'=>$_smarty_tpl->tpl_vars['item']->value['name']));?>

        <?php } ?>
    <?php }?>
<?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>

<form class="form-horizontal" action="admins/groups/process/<?php if (isset($_smarty_tpl->tpl_vars['data']->value['id'])) {
echo $_smarty_tpl->tpl_vars['data']->value['id'];
}?>" method="post" id="adminsGroupForm">
    <fieldset>
        <legend>Основне</legend>
        <div class="form-group">
            <label for="data_parent_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['admins_group']['parent'];?>
</label>
            <div class="col-md-9">
                <select class="form-control" name="data[parent_id]" id="data_parent_id">
                    <option value="0">--</option>
                    <?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value) {
$_smarty_tpl->tpl_vars['group']->_loop = true;
?>
                        <?php smarty_template_function_renderGroups($_smarty_tpl,array('item'=>$_smarty_tpl->tpl_vars['group']->value,'selected'=>$_smarty_tpl->tpl_vars['data']->value['parent_id'],'parent'=>''));?>

                    <?php } ?>
                </select>
            </div>
        </div>
        <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
?>
            <div class="form-group">
                <label for="info_name_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['admins_group']['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['lang']->value['name'];?>
)</label>
                <div class="col-md-9">
                    <input type="tel" class="form-control" name="info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][name]" id="info_name_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
" value="<?php if (isset($_smarty_tpl->tpl_vars['info']->value[$_smarty_tpl->tpl_vars['lang']->value['id']]['name'])) {
echo $_smarty_tpl->tpl_vars['info']->value[$_smarty_tpl->tpl_vars['lang']->value['id']]['name'];
}?>" required>
                </div>
            </div>
        <?php } ?>
        <div class="form-group">
            <div class="col-md-10">
                <input type="hidden"  name="permissions[full_access]"  class="form-control" value="0" >
                <input type="checkbox" <?php if (isset($_smarty_tpl->tpl_vars['data']->value['permissions']['full_access'])&&$_smarty_tpl->tpl_vars['data']->value['permissions']['full_access']) {?>checked<?php }?> name="permissions[full_access]" id="permissions_full_access" value="1" > Повний доступ
            </div>
        </div>
    </fieldset>
    

    <input type="hidden" name="action" value="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="a" value="1">
</form><?php }} ?>
