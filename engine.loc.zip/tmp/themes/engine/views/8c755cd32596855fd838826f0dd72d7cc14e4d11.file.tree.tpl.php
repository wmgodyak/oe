<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-28 11:36:36
         compiled from "/var/www/engine.loc/themes/engine/views/customers/groups/tree.tpl" */ ?>
<?php /*%%SmartyHeaderCode:131137086556f8ec83188370-45588000%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c755cd32596855fd838826f0dd72d7cc14e4d11' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/customers/groups/tree.tpl',
      1 => 1459154196,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '131137086556f8ec83188370-45588000',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f8ec83199514_41713388',
  'variables' => 
  array (
    'admins_groups_icon' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f8ec83199514_41713388')) {function content_56f8ec83199514_41713388($_smarty_tpl) {?><div class="title">
    <i class="fa <?php echo $_smarty_tpl->tpl_vars['admins_groups_icon']->value;?>
"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['admins']['tree_title'];?>
</span>
    <button class="btn btn-link b-customers-group-create"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</button>
</div>
<div class="pages-tree" id="customersGroup"></div><?php }} ?>
