<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 17:15:34
         compiled from "/var/www/engine.loc/themes/engine/views/customers/groups/tree.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20923394145773d8067e5975-15904906%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c755cd32596855fd838826f0dd72d7cc14e4d11' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/customers/groups/tree.tpl',
      1 => 1467182691,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20923394145773d8067e5975-15904906',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    't' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5773d8068076e4_00105567',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5773d8068076e4_00105567')) {function content_5773d8068076e4_00105567($_smarty_tpl) {?><div class="title">
    <i class="fa fa-users"></i>
    <span><?php echo $_smarty_tpl->tpl_vars['t']->value['customers']['tree_title'];?>
</span>
    <button class="btn btn-link b-customers-group-create"><?php echo $_smarty_tpl->tpl_vars['t']->value['common']['create'];?>
</button>
</div>
<div class="pages-tree" id="customersGroups"></div><?php }} ?>
