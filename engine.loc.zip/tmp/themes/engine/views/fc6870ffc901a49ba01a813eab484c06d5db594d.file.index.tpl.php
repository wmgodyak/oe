<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-01 15:32:03
         compiled from "/var/www/engine.loc/themes/engine/views/shop/categories/features/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1186044551577634f6c12366-12583599%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fc6870ffc901a49ba01a813eab484c06d5db594d' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/categories/features/index.tpl',
      1 => 1467376323,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1186044551577634f6c12366-12583599',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577634f6c12cc8_74813425',
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577634f6c12cc8_74813425')) {function content_577634f6c12cc8_74813425($_smarty_tpl) {?><fieldset id="shopCategoriesFeatures" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
">
    <legend>Властивості товарів
        <a href="javascript:;" type="button" class="b-shop-categories-features-select" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
" data-parent="0" title="Додати">
            <i class="fa fa-plus-circle"></i>
        </a>
    </legend>
    <div id="content_features_0"><?php echo $_smarty_tpl->getSubTemplate ("shop/categories/features/selected.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
</div>
</fieldset><?php }} ?>
