<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 09:44:28
         compiled from "/var/www/engine.loc/themes/engine/views/content/blocks/meta.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16197554305761b43a956931-28734362%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd8b4e9e3afb4570c5787e13fe4bf69ecbb47ac65' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/content/blocks/meta.tpl',
      1 => 1467227271,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16197554305761b43a956931-28734362',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5761b43a9aa989_00870303',
  'variables' => 
  array (
    't' => 0,
    'languages' => 0,
    'lang' => 0,
    'i' => 0,
    'content' => 0,
    'events' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5761b43a9aa989_00870303')) {function content_5761b43a9aa989_00870303($_smarty_tpl) {?><fieldset>
    <legend><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['legend_meta'];?>
</legend>

    <?php  $_smarty_tpl->tpl_vars['lang'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['lang']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['lang']->key => $_smarty_tpl->tpl_vars['lang']->value) {
$_smarty_tpl->tpl_vars['lang']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['lang']->key;
?>
        <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
            <label for="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_h1" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['h1'];?>
</label>
            <div class="col-md-10">
                <input type="text" class="form-control info-h1" name="content_info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][h1]" id="content_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_h1" placeholder="<?php echo $_smarty_tpl->tpl_vars['t']->value['content']['h1_i'];?>
" value="<?php if (isset($_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['h1'])) {
echo $_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['h1'];
}?>">
            </div>
        </div>

        <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
            <label for="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_title" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['title'];?>
</label>
            <div class="col-md-10">
                <input type="text" class="form-control info-title" name="content_info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][title]" id="content_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_title" placeholder="<?php echo $_smarty_tpl->tpl_vars['t']->value['content']['title_i'];?>
" value="<?php if (isset($_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['title'])) {
echo $_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['title'];
}?>">
            </div>
        </div>

        <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
            <label for="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_keywords" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['keywords'];?>
</label>
            <div class="col-md-10">
                <input type="text" class="form-control info-keywords tags-input" data-role="tagsinput" name="content_info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][keywords]" id="content_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_keywords" placeholder="<?php echo $_smarty_tpl->tpl_vars['t']->value['content']['keywords_i'];?>
" value="<?php if (isset($_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['keywords'])) {
echo $_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['keywords'];
}?>">
            </div>
        </div>

        <div class="form-group lang-<?php echo $_smarty_tpl->tpl_vars['lang']->value['code'];?>
 switch-lang" <?php if ($_smarty_tpl->tpl_vars['i']->value>0) {?>style="display:none"<?php }?>>
            <label for="info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_description" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['content']['description'];?>
</label>
            <div class="col-md-10">
                <textarea class="form-control info-description" name="content_info[<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
][description]" id="content_info_<?php echo $_smarty_tpl->tpl_vars['lang']->value['id'];?>
_description" placeholder="<?php echo $_smarty_tpl->tpl_vars['t']->value['content']['description_i'];?>
"><?php if (isset($_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['description'])) {
echo $_smarty_tpl->tpl_vars['content']->value['info'][$_smarty_tpl->tpl_vars['lang']->value['id']]['description'];
}?></textarea>
            </div>
        </div>
    <?php } ?>
    <?php echo $_smarty_tpl->tpl_vars['events']->value->call('content.meta',array($_smarty_tpl->tpl_vars['content']->value));?>

</fieldset><?php }} ?>
