<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-14 17:06:19
         compiled from "/var/www/engine.loc/themes/engine/views/features/sel_content_types.tpl" */ ?>
<?php /*%%SmartyHeaderCode:158718462856e6d36b53db05-76764218%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cb96f7cc3808e42d197a9a1465a997f12cc7df7b' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/features/sel_content_types.tpl',
      1 => 1457966182,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '158718462856e6d36b53db05-76764218',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'features_id' => 0,
    't' => 0,
    'types' => 0,
    'item' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56e6d36b56cb05_41602821',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e6d36b56cb05_41602821')) {function content_56e6d36b56cb05_41602821($_smarty_tpl) {?><form action="features/selectContent/<?php echo $_smarty_tpl->tpl_vars['features_id']->value;?>
" method="post" id="formFeaturesContent" class="form-horizontal">
    <div class="form-group">
        <label for="data_types_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['content_type'];?>
</label>
        <div class="col-md-9">
            <select name="content_types_id" id="data_types_id" class="form-control">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['types']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="data_subtypes_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['content_subtype'];?>
</label>
        <div class="col-md-9">
            <select name="content_subtypes_id" id="data_subtypes_id" class="form-control" disabled></select>
        </div>
    </div>
    <div class="form-group">
        <label for="data_content_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['content_page'];?>
</label>
        <div class="col-md-9">
            <select name="content_id[]" id="data_content_id" class="form-control" multiple disabled></select>
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="process">
</form><?php }} ?>
