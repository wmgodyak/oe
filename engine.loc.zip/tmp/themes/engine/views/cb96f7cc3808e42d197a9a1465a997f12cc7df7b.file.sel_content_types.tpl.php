<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-30 17:10:37
         compiled from "/var/www/engine.loc/themes/engine/views/features/sel_content_types.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15267329465762dd8836ca74-31132075%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cb96f7cc3808e42d197a9a1465a997f12cc7df7b' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/features/sel_content_types.tpl',
      1 => 1467295833,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15267329465762dd8836ca74-31132075',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5762dd883a1cd2_99479743',
  'variables' => 
  array (
    'features_id' => 0,
    't' => 0,
    'types' => 0,
    'item' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5762dd883a1cd2_99479743')) {function content_5762dd883a1cd2_99479743($_smarty_tpl) {?><form action="features/content/index/<?php echo $_smarty_tpl->tpl_vars['features_id']->value;?>
" method="post" id="formFeaturesContent" class="form-horizontal">
    <div class="form-group">
        <label for="data_types_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['content_type'];?>
</label>
        <div class="col-md-9">
            <select name="content_types_id" id="data_types_id" class="form-control">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['types']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="data_subtypes_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['content_subtype'];?>
</label>
        <div class="col-md-9">
            <select name="content_subtypes_id" id="data_subtypes_id" class="form-control" disabled></select>
        </div>
    </div>
    <div class="form-group">
        <label for="data_content_id" class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['content_page'];?>
</label>
        <div class="col-md-9">
            <select name="content_id[]" id="data_content_id" class="form-control" multiple disabled></select>
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="process">
</form><?php }} ?>
