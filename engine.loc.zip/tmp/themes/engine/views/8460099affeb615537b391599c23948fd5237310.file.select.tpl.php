<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-01 16:15:52
         compiled from "/var/www/engine.loc/themes/engine/views/shop/categories/features/select.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4929649115776555dd5ec47-94247883%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8460099affeb615537b391599c23948fd5237310' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/categories/features/select.tpl',
      1 => 1467378945,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4929649115776555dd5ec47-94247883',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5776555dd8c7f1_15993424',
  'variables' => 
  array (
    'content_id' => 0,
    't' => 0,
    'features' => 0,
    'item' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5776555dd8c7f1_15993424')) {function content_5776555dd8c7f1_15993424($_smarty_tpl) {?><form action="module/run/shop/categories/features/select/<?php echo $_smarty_tpl->tpl_vars['content_id']->value;?>
" method="post" id="formContentFeatures" class="form-horizontal" >
   <div class="form-group">
        <label for="data_type" class="col-md-2 control-label"><?php echo $_smarty_tpl->tpl_vars['t']->value['features']['type'];?>
</label>
        <div class="col-md-10">
            <select name="categories_features[]" id="categories_features" required multiple class="form-control">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['features']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                    <option <?php echo $_smarty_tpl->tpl_vars['item']->value['selected'];?>
 value="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</option>
                <?php } ?>
            </select>
        </div>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="action" value="create">
</form><?php }} ?>
