<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-01 12:04:18
         compiled from "/var/www/engine.loc/themes/engine/views/shop/categories/features.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12102959975776188f362ac1-40192553%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e3d2615e90ba9f9c3e741359a561993ce25e4c31' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/categories/features.tpl',
      1 => 1467357429,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12102959975776188f362ac1-40192553',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5776188f3f95e6_35741433',
  'variables' => 
  array (
    'content' => 0,
    'categories_features' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5776188f3f95e6_35741433')) {function content_5776188f3f95e6_35741433($_smarty_tpl) {?><fieldset id="shopCategoriesFeatures" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
">
    <legend>Властивості товарів
        <a href="javascript:;" type="button" class="b-shop-categories-features-add" data-id="<?php echo $_smarty_tpl->tpl_vars['content']->value['id'];?>
" data-parent="0" title="Додати">
            <i class="fa fa-plus-circle"></i>
        </a>
    </legend>
    <div id="content_features_0">
        <?php if (isset($_smarty_tpl->tpl_vars['categories_features']->value)) {
echo $_smarty_tpl->tpl_vars['categories_features']->value;
}?>
    </div>
</fieldset><?php }} ?>
