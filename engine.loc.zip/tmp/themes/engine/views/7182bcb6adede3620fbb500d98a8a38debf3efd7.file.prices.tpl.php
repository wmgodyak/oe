<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-04 16:42:21
         compiled from "/var/www/engine.loc/themes/engine/views/shop/prices.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4131906665773d7f769bde2-00440058%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7182bcb6adede3620fbb500d98a8a38debf3efd7' => 
    array (
      0 => '/var/www/engine.loc/themes/engine/views/shop/prices.tpl',
      1 => 1467639740,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4131906665773d7f769bde2-00440058',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5773d7f772ed27_06812114',
  'variables' => 
  array (
    'content' => 0,
    'units' => 0,
    'unit' => 0,
    'groups' => 0,
    'g' => 0,
    'prices' => 0,
    'currency' => 0,
    'c' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5773d7f772ed27_06812114')) {function content_5773d7f772ed27_06812114($_smarty_tpl) {?><fieldset>
    <legend>Ціни та наявність</legend>

    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="content_code" class="col-md-4 control-label">Артикул</label>
                <div class="col-md-8">
                    <input name="content[sku]" id="content_code" class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['sku'];?>
">
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="content_units" class="col-md-4 control-label">Од.виміру</label>
                <div class="col-md-8">
                    <select name="content[unit_id]" id="content_units" class="form-control">
                        <?php  $_smarty_tpl->tpl_vars['unit'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['unit']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['units']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['unit']->key => $_smarty_tpl->tpl_vars['unit']->value) {
$_smarty_tpl->tpl_vars['unit']->_loop = true;
?>
                            <option <?php if (isset($_smarty_tpl->tpl_vars['content']->value['unit_id'])&&$_smarty_tpl->tpl_vars['content']->value['unit_id']==$_smarty_tpl->tpl_vars['unit']->value['id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['unit']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['unit']->value['name'];?>
</option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="content_in_stock" class="col-md-4 control-label">Наявність</label>
                <div class="col-md-8">
                    <select name="content[in_stock]" id="content_in_stock" class="form-control">
                        <option <?php if ($_smarty_tpl->tpl_vars['content']->value['in_stock']==1) {?>selected<?php }?> value="1">в наявності</option>
                        <option <?php if ($_smarty_tpl->tpl_vars['content']->value['in_stock']==2) {?>selected<?php }?> value="2">під замовлення</option>
                        <option <?php if ($_smarty_tpl->tpl_vars['content']->value['in_stock']==0) {?>selected<?php }?> value="0">немає</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <table style="width: 100%" class="table">
                <tr>
                    <th>Група</th>
                    <?php  $_smarty_tpl->tpl_vars['g'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['g']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['g']->key => $_smarty_tpl->tpl_vars['g']->value) {
$_smarty_tpl->tpl_vars['g']->_loop = true;
?>
                        <th><?php echo $_smarty_tpl->tpl_vars['g']->value['name'];?>
</th>
                    <?php } ?>
                    <th>Валюта</th>
                </tr>
                <tr>
                    <td>Ціна</td>
                    <?php  $_smarty_tpl->tpl_vars['g'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['g']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['groups']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['g']->key => $_smarty_tpl->tpl_vars['g']->value) {
$_smarty_tpl->tpl_vars['g']->_loop = true;
?>
                        <td><input type="text" name="prices[<?php echo $_smarty_tpl->tpl_vars['g']->value['id'];?>
]" class="form-control" onchange="this.value = parseFloat(this.value); if(this.value == 'NaN') this.value = '';" required value="<?php if (isset($_smarty_tpl->tpl_vars['prices']->value[$_smarty_tpl->tpl_vars['g']->value['id']])) {
echo $_smarty_tpl->tpl_vars['prices']->value[$_smarty_tpl->tpl_vars['g']->value['id']];
}?>"></td>
                    <?php } ?>
                    <td>

                        <select name="content[currency_id]" id="content_currency" class="form-control">
                            <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['currency']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
                                <option <?php if ($_smarty_tpl->tpl_vars['content']->value['currency_id']==$_smarty_tpl->tpl_vars['c']->value['id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['c']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['c']->value['code'];?>
</option>
                            <?php } ?>
                        </select>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</fieldset><?php }} ?>
