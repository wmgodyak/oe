<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-25 12:23:49
         compiled from "/var/www/engine.loc/themes/default/views/modules/blog/categories.tpl" */ ?>
<?php /*%%SmartyHeaderCode:110209726756f511b5996fe1-56239395%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '265e5dff60289af896d766709211f0fb026093fe' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/blog/categories.tpl',
      1 => 1458901427,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '110209726756f511b5996fe1-56239395',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'blog' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f511b59a1ff7_05541608',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f511b59a1ff7_05541608')) {function content_56f511b59a1ff7_05541608($_smarty_tpl) {?><div class="best-hits">
    <strong>Категорії</strong>
    <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['blog']->value['categories']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
        <a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a>
        <br>
    <?php } ?>
</div><?php }} ?>
