<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 14:22:40
         compiled from "/var/www/engine.loc/themes/default/views/modules/blog/categories.tpl" */ ?>
<?php /*%%SmartyHeaderCode:110209726756f511b5996fe1-56239395%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '265e5dff60289af896d766709211f0fb026093fe' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/blog/categories.tpl',
      1 => 1467717760,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '110209726756f511b5996fe1-56239395',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f511b59a1ff7_05541608',
  'variables' => 
  array (
    'mod' => 0,
    'page' => 0,
    'item' => 0,
    'k' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f511b59a1ff7_05541608')) {function content_56f511b59a1ff7_05541608($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['mod']->value->blog->categories(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['item']->key;
?>
    <div class="filter-news">
        <a class="btn md <?php if ($_smarty_tpl->tpl_vars['page']->value['id']==$_smarty_tpl->tpl_vars['item']->value['id']||($_smarty_tpl->tpl_vars['page']->value['id']==5&&$_smarty_tpl->tpl_vars['k']->value==0)) {?>red<?php } else { ?>white-red<?php }?>" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a>
    </div>
<?php } ?><?php }} ?>
