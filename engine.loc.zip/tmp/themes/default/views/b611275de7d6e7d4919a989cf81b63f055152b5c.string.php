<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-29 16:18:45
         compiled from "b611275de7d6e7d4919a989cf81b63f055152b5c" */ ?>
<?php /*%%SmartyHeaderCode:190197163056fa80b5f00368-07497379%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b611275de7d6e7d4919a989cf81b63f055152b5c' => 
    array (
      0 => 'b611275de7d6e7d4919a989cf81b63f055152b5c',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '190197163056fa80b5f00368-07497379',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fa80b5f16360_01635808',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fa80b5f16360_01635808')) {function content_56fa80b5f16360_01635808($_smarty_tpl) {?><p>Вітаємо <?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
&nbsp;<?php echo $_smarty_tpl->tpl_vars['data']->value['surname'];?>
. Ви успішно зареєстувались на нашому сайті.&nbsp;</p>

<p>Ваш логін:&nbsp;<?php echo $_smarty_tpl->tpl_vars['data']->value['email'];?>
</p>

<p>Ваш пароль:&nbsp;<?php echo $_smarty_tpl->tpl_vars['data']->value['password'];?>
</p>

<p>Бажаєм хороших покупок</p>
<?php }} ?>
