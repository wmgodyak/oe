<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-04-11 10:33:18
         compiled from "62bf054e4acdf638b2f858cf81790743f1619e5a" */ ?>
<?php /*%%SmartyHeaderCode:1688420034570b533e885248-20795225%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '62bf054e4acdf638b2f858cf81790743f1619e5a' => 
    array (
      0 => '62bf054e4acdf638b2f858cf81790743f1619e5a',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '1688420034570b533e885248-20795225',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_570b533e893ca8_90965576',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_570b533e893ca8_90965576')) {function content_570b533e893ca8_90965576($_smarty_tpl) {?><p>Вітаємо. Замовлено зворотній дзвінок.</p>

<p>Ім&#39;я: <?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
</p>

<p>Телефон: <?php echo $_smarty_tpl->tpl_vars['data']->value['phone'];?>
</p>

<p>Повідомлення</p>

<p><?php echo $_smarty_tpl->tpl_vars['data']->value['message'];?>
</p>
<?php }} ?>
