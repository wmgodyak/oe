<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 11:08:22
         compiled from "themes/default/views/layouts/pages/home.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1231158338577b5449de2b62-67050332%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6816731ac28a7c8c5fbe749846be31c3e04b3445' => 
    array (
      0 => 'themes/default/views/layouts/pages/home.tpl',
      1 => 1467706097,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1231158338577b5449de2b62-67050332',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b5449edfbb1_05294890',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b5449edfbb1_05294890')) {function content_577b5449edfbb1_05294890($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<!-- begin wrapper -->
<div class="wrapper">

    <?php echo $_smarty_tpl->getSubTemplate ("chunks/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <!-- begin main -->
    <main class="main">

        <!-- begin container -->
        <div class="container clearfix">
            <?php echo $_smarty_tpl->getSubTemplate ("modules/shop/nav.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php echo $_smarty_tpl->getSubTemplate ("modules/banners/home.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


        </div>
        <!-- end container -->

    </main>
    <!-- end main -->

    <!-- begin main-goods -->
    <div class="main-goods">

        <div class="container">

            <?php echo $_smarty_tpl->getSubTemplate ("modules/shop/widgets/actions.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php echo $_smarty_tpl->getSubTemplate ("modules/shop/widgets/new.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


        </div>

    </div>
    <!-- end main-goods -->

    <?php echo $_smarty_tpl->getSubTemplate ("modules/blog/latest.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


</div>
<!-- end wrapper -->
<?php echo $_smarty_tpl->getSubTemplate ("chunks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
