<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-25 12:39:33
         compiled from "themes/default/views/content_types/post.tpl" */ ?>
<?php /*%%SmartyHeaderCode:109794897056f511f3672759-56797624%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '33d4f7894e729e2aee82e806c758cbdd4e3dcd6e' => 
    array (
      0 => 'themes/default/views/content_types/post.tpl',
      1 => 1458902371,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '109794897056f511f3672759-56797624',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f511f3684cb1_14008208',
  'variables' => 
  array (
    'post' => 0,
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f511f3684cb1_14008208')) {function content_56f511f3684cb1_14008208($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<body id="blogpost">
<?php echo $_smarty_tpl->getSubTemplate ("modules/nav/top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div id="blogpost-wrapper">
    <div class="container">
        <?php if ($_smarty_tpl->tpl_vars['post']->value['image']) {?>
        <div class="row">
            <div class="col-md-12">
                <div class="main-pic">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['post']->value['image'];?>
" class="img-responsive" alt="blogpost" />
                </div>
            </div>
        </div>
        <?php }?>
        <div class="row">
            <div class="col-md-10 post">
                <div class="title">
                    A brief history of climate science gone wrong
                </div>
                <div class="author">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/images/testimonials/testimonial3.jpg" class="avatar" alt="author" />
                    By Lawrence Stewart, August 16, 2013
                </div>
                <div class="content">
                    <p>
                        I love making the stuff, that’s sort of the core of it. I love creating the stuff. It’s so satisfying to get from the beginning to the end, from a shaky nothing idea to something that’s well formed and the audience really likes. It’s like a drug: You keep trying to do it again and again and again. I’ve learned from experience that if you work harder at it, and apply more energy and time to it, and more consistency, you get a better result. It comes from the work.
                        <br />
                        Functionality is so over-valued in design, and we’ve kept design very small in that way. Functionality is the sheer minimum. If your house burns down, what do you take? The cat in the window that you got from your mother, or the chair you have?
                    </p>
                    <p>
                        Some people say design is about solving problems. Obviously designers solve problems but so do dentists. Design is about <a href="#">cultural invention.</a>
                    </p>
                    <blockquote>
                        <p>
                            “We’re all naturally curious when we’re eight years old. But as most people get older, they become less and less curious, so they ask other people to be curious for them. That’s what I do for a living.”
                        </p>
                        <p class="quote-author">
                            Ron Miriello
                        </p>
                    </blockquote>
                    <p>
                        You have to roll up your sleeves and be a stonecutter before you can become a sculptor – command of craft always precedes art: apprentice, journeyman, master. <br />
                        It doesn’t matter one damn bit whether fashion is art or not. You don’t question whether an incredible chef is an artist or not – his cakes are delicious and that’s all that matters.
                    </p>
                    <div class="divider"></div>
                    <p>
                        If you want to set off and go develop some grand new thing, you don’t need millions of dollars of capitalization. You need enough pizza and Diet Coke to stick in your refrigerator, a cheap PC to work on and the dedication to go through with it.
                    </p>
                    <p>
                        Well you’re in your little room and you’re working on something good but if it’s really good you’re gonna need a bigger room and when you’re in the bigger room you might not know what to do you might have to think of how you got started sitting in your little room.
                    </p>
                    <p>
                        <img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/images/slider/slide1.png" class="img-responsive" alt="slide" />
                    </p>
                    <p>
                        Chances are, unless I’m a designer, I don’t know what I want. All I know is I want something functional that looks good, is comparable with my competitors, and features constant colour schemes for branding.
                    </p>
                    <p>
                        I’ll look at other designs that have already been created and ask for something similar. Hence, it is important that you can take the information I give and help me visualize what it is you
                        <a href="#">think I want.</a>
                    </p>
                    <p>
                        I want everything we do to be beautiful. I don’t give a damn whether the client understands that that’s worth anything, or that the client thinks it’s worth anything, or whether it is worth anything. It’s worth it to me. It’s the way I want to live my life. I want to make beautiful things, even if nobody cares.
                    </p>
                    <p>
                        Inspiration is hogwash. My work comes directly out of my loves and hates. Muses don’t whisper in my ear, and ideas don’t flow over my body like a cool rain.
                        <br />
                        Functionality is so over-valued in design, and we’ve kept design very small in that way. Functionality is the sheer minimum. If your house burns down, what do you take? The cat in the window that you got from your mother, or the chair you have?
                    </p>
                </div>
                <div class="share">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/images/share.png" alt="share" />
                </div>
                <div class="other-posts">
                    <a href="#" class="prev">
                        ← Learn Rails in 30 days
                    </a>
                    <a href="#" class="next pull-right">
                        Take care of yourself →
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>


<?php echo $_smarty_tpl->getSubTemplate ("chunks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</body>
</html><?php }} ?>
