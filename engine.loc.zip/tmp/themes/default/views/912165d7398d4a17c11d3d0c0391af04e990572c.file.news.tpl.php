<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 14:28:16
         compiled from "themes/default/views/layouts/pages/news.tpl" */ ?>
<?php /*%%SmartyHeaderCode:839673644577b57525053f6-31100435%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '912165d7398d4a17c11d3d0c0391af04e990572c' => 
    array (
      0 => 'themes/default/views/layouts/pages/news.tpl',
      1 => 1467718095,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '839673644577b57525053f6-31100435',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b5752537620_88157972',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b5752537620_88157972')) {function content_577b5752537620_88157972($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("modules/blog/index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
