<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 14:13:39
         compiled from "/var/www/engine.loc/themes/default/views/modules/breadcrumbs.tpl" */ ?>
<?php /*%%SmartyHeaderCode:506231203577b9600d14bb8-28883984%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9e50eddc0a8228d9a3735a02984b1b6582a2615f' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/breadcrumbs.tpl',
      1 => 1467717218,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '506231203577b9600d14bb8-28883984',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b9600d16272_38701321',
  'variables' => 
  array (
    'mod' => 0,
    'page' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b9600d16272_38701321')) {function content_577b9600d16272_38701321($_smarty_tpl) {?><!-- begin m_breadcrumbs -->
<div class="m_breadcrumbs">
    <div class="container">
        <ul class="breadcrumbs__list">
            <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['mod']->value->breadcrumbs->get(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
            <li class="breadcrumbs__item<?php if ($_smarty_tpl->tpl_vars['page']->value['id']==$_smarty_tpl->tpl_vars['item']->value['id']) {?> breadcrumbs__item--current<?php }?>">
                <a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
" class="breadcrumbs__link"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a>
            </li>
            <?php } ?>
        </ul>
    </div>
</div>
<!-- end m_breadcrumbs --><?php }} ?>
