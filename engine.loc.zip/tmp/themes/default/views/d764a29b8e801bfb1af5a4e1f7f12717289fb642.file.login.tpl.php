<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-23 13:49:15
         compiled from "/var/www/engine.loc/themes/default/views/modules/account/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:23750798056f9239738c275-62921911%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd764a29b8e801bfb1af5a4e1f7f12717289fb642' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/account/login.tpl',
      1 => 1466020694,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23750798056f9239738c275-62921911',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f9239738f2a7_55327075',
  'variables' => 
  array (
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f9239738f2a7_55327075')) {function content_56f9239738f2a7_55327075($_smarty_tpl) {?>
<div class="container">
    <div class="row header">
        <div class="col-md-12">
            <h3 class="logo">
                <a href="1">Login form</a>
            </h3>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="wrapper clearfix">
                <div class="formy">
                    <div class="row">
                        <div class="col-md-12">

                            <form role="form" action="ajax/account/login" data-href="31" method="post" id="accountLogin">
                               <div class="form-group">
                                    <label for="email">Email address</label>
                                    <input type="email" class="form-control" name="data[email]" required />
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" name="data[password]" required />
                                </div>
                                <div class="submit">
                                    <button type="submit" class="button-clear">
                                        <span>Login</span>
                                    </button>
                                </div>
                                <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="already-account">
                Go to register
                <a href="30" data-toggle="popover" data-placement="top" data-content="Register here!" data-trigger="manual">register  here</a> |
                <a href="34">forgot passwd</a>
            </div>
        </div>
    </div>
</div><?php }} ?>
