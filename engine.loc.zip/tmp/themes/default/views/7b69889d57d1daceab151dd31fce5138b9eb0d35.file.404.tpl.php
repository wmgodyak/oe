<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-27 09:55:17
         compiled from "themes/default/views/layouts/pages/404.tpl" */ ?>
<?php /*%%SmartyHeaderCode:174103128856f532528e68d5-43626997%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7b69889d57d1daceab151dd31fce5138b9eb0d35' => 
    array (
      0 => 'themes/default/views/layouts/pages/404.tpl',
      1 => 1466100772,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '174103128856f532528e68d5-43626997',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f532528f1108_83713052',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f532528f1108_83713052')) {function content_56f532528f1108_83713052($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<body id="not-found" class="not-found-page">
<div class="info">
    <h1>404</h1>
    <p>Отакої. Сторінка відсутня.</p>

    <p class="go-back">
        напевне вам вартує повернутись на <a href="/">головну</a>.
    </p>
</div><?php }} ?>
