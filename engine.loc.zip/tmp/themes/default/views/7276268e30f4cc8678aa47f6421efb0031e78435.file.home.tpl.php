<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 10:51:41
         compiled from "/var/www/engine.loc/themes/default/views/modules/banners/home.tpl" */ ?>
<?php /*%%SmartyHeaderCode:503170007577b63395ec932-04522579%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7276268e30f4cc8678aa47f6421efb0031e78435' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/banners/home.tpl',
      1 => 1467704846,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '503170007577b63395ec932-04522579',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b63395f8c41_48384355',
  'variables' => 
  array (
    'mod' => 0,
    'item' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b63395f8c41_48384355')) {function content_577b63395f8c41_48384355($_smarty_tpl) {?><!-- begin banners -->
<div class="banners">

    <div class="row">
        <div class="m_banner-slider">
            <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['mod']->value->banners->get('home-top'); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
            <div class="slide" style="background-image: url('<?php echo $_smarty_tpl->tpl_vars['item']->value['img'];?>
');"></div>
            <?php } ?>
        </div>
    </div>

    <div class="row clearfix">
        <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['mod']->value->banners->get('home-bottom',2,'rand'); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
            <div class="m_small-banner">
                <div class="wrap" style="background-image: url('<?php echo $_smarty_tpl->tpl_vars['item']->value['img'];?>
');">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
" class="btn md white-red"><?php echo $_smarty_tpl->tpl_vars['t']->value['banners']['more'];?>
</a>
                </div>
            </div>
        <?php } ?>
    </div>

</div>
<!-- end banners --><?php }} ?>
