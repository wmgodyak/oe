<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-31 17:37:51
         compiled from "/var/www/engine.loc/themes/default/views/modules/feedback/form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:98382512156fd2dfa306b14-80461021%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6f367c01746b0d92470530935fa1ae6749befaba' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/feedback/form.tpl',
      1 => 1459434612,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '98382512156fd2dfa306b14-80461021',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fd2dfa308672_91179534',
  'variables' => 
  array (
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fd2dfa308672_91179534')) {function content_56fd2dfa308672_91179534($_smarty_tpl) {?><form role="form" id="feedback" action="ajax/feedback/send" method="post">
    <div class="response"></div>
    <div class="form-group">
        <label for="name">Your name</label>
        <input type="text" name="data[name]" class="form-control" id="data_name" required>
    </div>
    <div class="form-group">
        <label for="email">Email address</label>
        <input type="email" name="data[email]" class="form-control" id="data_email" required>
    </div>
    <div class="form-group">
        <label for="phone">Phone</label>
        <input type="text" name="data[phone]" class="form-control" id="data_phone" required>
    </div>
    <div class="form-group">
        <label for="message">Your message</label>
        <textarea name="data[message]" class="form-control" id="data_message" rows="6" required></textarea>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <div class="submit">
        <button type="submit" id="bSubmit" class="button button-small" data-loading-text="Sending..." data-complete-text="Send success!">Send</button>
    </div>
</form><?php }} ?>
