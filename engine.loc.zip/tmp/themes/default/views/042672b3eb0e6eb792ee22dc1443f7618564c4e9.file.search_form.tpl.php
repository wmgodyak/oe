<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 14:17:05
         compiled from "/var/www/engine.loc/themes/default/views/modules/blog/search_form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2055265071577b9731cdb247-54907357%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '042672b3eb0e6eb792ee22dc1443f7618564c4e9' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/blog/search_form.tpl',
      1 => 1467717338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2055265071577b9731cdb247-54907357',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b9731cdc0b4_15435966',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b9731cdc0b4_15435966')) {function content_577b9731cdc0b4_15435966($_smarty_tpl) {?>
<form class="search-form" action="#">
    <input type="text" placeholder="Пошук у новинах та акціях">
    <button class="search-btn"></button>
</form>
<?php }} ?>
