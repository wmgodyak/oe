<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-21 16:48:40
         compiled from "themes/default/views/technical_works.tpl" */ ?>
<?php /*%%SmartyHeaderCode:73973764956f0076922f400-67992643%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7887fc84e0b83e29aefa83cf79f84bfc9a5c7b66' => 
    array (
      0 => 'themes/default/views/technical_works.tpl',
      1 => 1458571720,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '73973764956f0076922f400-67992643',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f00769246555_72985919',
  'variables' => 
  array (
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f00769246555_72985919')) {function content_56f00769246555_72985919($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/css/vendor/flipclock.css">
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/flipclock/libs/base.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/flipclock/flipclock.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/flipclock/faces/hourlycounter.js"><?php echo '</script'; ?>
>


<body id="coming-soon" class="dark">

<div class="container">
    <div class="row info">
        <div class="col-md-12">
            <h1><a href="1">Отакої</a></h1>
            <h3>на сайті проводяться технічні роботи</h3>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div id="countdown">
                <div id="clock"></div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <form class="form-inline" role="form">
                <div class="form-group">
                    <label class="sr-only" for="exampleInputEmail2">Введіть ваш email</label>
                    <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Введіть ваш emaill">
                </div>
                <a href="1" class="button">Повідомте мене</a>
                <!-- <button type="submit" class="btn btn-primary">Notify me</button> -->
            </form>
        </div>
    </div>

</div>

<?php echo '<script'; ?>
 type="text/javascript">
    $(function () {

        var clock;

        // Grab the current date
        var currentDate = new Date();

        // Set some date in the future. In this case, it's always Jan 1
        var futureDate  = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), currentDate.getHours() + 20);

        // Calculate the difference in seconds between the future and current date
        var diff = futureDate.getTime() / 1000 - currentDate.getTime() / 1000;

        // Instantiate a coutdown FlipClock
        clock = $('#clock').FlipClock(diff, {
            countdown: true
        });
    });
<?php echo '</script'; ?>
>
</body><?php }} ?>
