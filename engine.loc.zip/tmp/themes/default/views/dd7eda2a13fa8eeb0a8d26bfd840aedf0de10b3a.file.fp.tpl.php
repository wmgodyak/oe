<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 10:56:12
         compiled from "/var/www/engine.loc/themes/default/views/modules/account/fp.tpl" */ ?>
<?php /*%%SmartyHeaderCode:80342789156fb83890f6684-00502733%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dd7eda2a13fa8eeb0a8d26bfd840aedf0de10b3a' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/account/fp.tpl',
      1 => 1459324572,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '80342789156fb83890f6684-00502733',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fb8389105e92_73937544',
  'variables' => 
  array (
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fb8389105e92_73937544')) {function content_56fb8389105e92_73937544($_smarty_tpl) {?><div class="container">
    <div class="row header">
        <div class="col-md-12">
            <h3 class="logo">
                <a href="1">Forgot password</a>
            </h3>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="wrapper clearfix">
                <div class="formy">
                    <div class="row">
                        <div class="col-md-12">

                            <form role="form" action="ajax/account/fp" data-href="1" method="post" id="accountFp">
                                <div class="response"></div>
                               <div class="form-group">
                                    <label for="email">Email address</label>
                                    <input type="email" class="form-control" name="data[email]" required />
                                </div>
                                <div class="submit">
                                    <button type="submit" class="button-clear">
                                        <span>Reset</span>
                                    </button>
                                </div>
                                <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="already-account">
                Go to register
                <a href="30" >register here</a> |
                <a href="29">login</a>
            </div>
        </div>
    </div>
</div><?php }} ?>
