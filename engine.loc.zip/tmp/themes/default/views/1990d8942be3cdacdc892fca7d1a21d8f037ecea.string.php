<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 10:54:05
         compiled from "1990d8942be3cdacdc892fca7d1a21d8f037ecea" */ ?>
<?php /*%%SmartyHeaderCode:88825772656fb861ddf3ee0-47328685%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1990d8942be3cdacdc892fca7d1a21d8f037ecea' => 
    array (
      0 => '1990d8942be3cdacdc892fca7d1a21d8f037ecea',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '88825772656fb861ddf3ee0-47328685',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fb861de075c7_69307686',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fb861de075c7_69307686')) {function content_56fb861de075c7_69307686($_smarty_tpl) {?><p>Вітаємо <?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
. Ви отримали це повідомлення, так як здійснили запит на відновлення паролю.</p>

<p>Для цього вам необхідно перейти по <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['fp_link'];?>
">цьому&nbsp;посиланню</a></p>
<?php }} ?>
