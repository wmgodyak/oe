<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-21 18:35:51
         compiled from "/var/www/engine.loc/themes/default/views/modules/callback.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1856277083570b4d4616f683-61117743%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3712b45bdddaef5b6e1b3c0edb4b427ff547e1d2' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/callback.tpl',
      1 => 1466020694,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1856277083570b4d4616f683-61117743',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_570b4d46173220_48251644',
  'variables' => 
  array (
    'user' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_570b4d46173220_48251644')) {function content_570b4d46173220_48251644($_smarty_tpl) {?>
<form role="form" id="callback" action="ajax/callback/process" method="post">
    <div class="response"></div>
    <div class="form-group">
        <label for="name">Your name</label>
        <input type="text" name="data[name]" class="form-control" id="data_name" value="<?php if ($_smarty_tpl->tpl_vars['user']->value) {
echo $_smarty_tpl->tpl_vars['user']->value['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['user']->value['surname'];
}?>" required>
    </div>
    <div class="form-group">
        <label for="phone">Phone</label>
        <input type="text" name="data[phone]" class="form-control" id="data_c_phone" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['phone'];?>
" required>
    </div>
    <div class="form-group">
        <label for="message">Your message</label>
        <textarea name="data[message]" class="form-control" id="data_message" rows="6" required></textarea>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <div class="submit">
        <button type="submit" id="bSubmit" class="button button-small" data-loading-text="Sending..." data-complete-text="Send success!">Send</button>
    </div>
</form><?php }} ?>
