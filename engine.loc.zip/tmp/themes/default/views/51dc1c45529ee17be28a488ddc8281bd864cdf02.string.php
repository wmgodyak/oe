<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-31 10:02:01
         compiled from "51dc1c45529ee17be28a488ddc8281bd864cdf02" */ ?>
<?php /*%%SmartyHeaderCode:100433989656fccb698dce25-56960777%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '51dc1c45529ee17be28a488ddc8281bd864cdf02' => 
    array (
      0 => '51dc1c45529ee17be28a488ddc8281bd864cdf02',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '100433989656fccb698dce25-56960777',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fccb698f4df1_44804353',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fccb698f4df1_44804353')) {function content_56fccb698f4df1_44804353($_smarty_tpl) {?><p>Вітаємо <?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
. Ви отримали це повідомлення, так як слідкуєте за коментарями до статті <?php echo $_smarty_tpl->tpl_vars['data']->value['page_name'];?>
.</p>

<p>Ви можете <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['page_url'];?>
">переглянути його тут</a>.</p>
<?php }} ?>
