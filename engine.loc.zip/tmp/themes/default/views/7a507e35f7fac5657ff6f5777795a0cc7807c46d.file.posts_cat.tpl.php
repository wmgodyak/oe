<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-25 14:42:09
         compiled from "themes/default/views/layouts/posts_cat.tpl" */ ?>
<?php /*%%SmartyHeaderCode:84638738656f531ea06d695-89969547%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7a507e35f7fac5657ff6f5777795a0cc7807c46d' => 
    array (
      0 => 'themes/default/views/layouts/posts_cat.tpl',
      1 => 1458909728,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '84638738656f531ea06d695-89969547',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f531ea080061_52708982',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f531ea080061_52708982')) {function content_56f531ea080061_52708982($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("layouts/blog.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
