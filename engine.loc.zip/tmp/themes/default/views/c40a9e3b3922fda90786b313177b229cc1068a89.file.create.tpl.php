<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 18:08:38
         compiled from "/var/www/engine.loc/themes/default/views/modules/comments/create.tpl" */ ?>
<?php /*%%SmartyHeaderCode:144391943856fbceabd01168-79548952%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c40a9e3b3922fda90786b313177b229cc1068a89' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/comments/create.tpl',
      1 => 1459350518,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '144391943856fbceabd01168-79548952',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fbceabd092c8_32764821',
  'variables' => 
  array (
    'token' => 0,
    'post' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fbceabd092c8_32764821')) {function content_56fbceabd092c8_32764821($_smarty_tpl) {?>
<form role="form" action="ajax/comments/create" method="post" class="comments-reply-form" id="commentsCreate">
    <div class="response"></div>
    <div class="form-group">
        <label for="message">Message</label>
        <textarea class="form-control" name="data[message]" cols="30" rows="10" required></textarea>
    </div>
    <div class="submit">
        <button type="submit" class="button-clear">
            <span>Add</span>
        </button>
    </div>
    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
    <input type="hidden" name="data[content_id]" value="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
">
    <input type="hidden" name="data[parent_id]" value="0" id="commentsParentId">
    <input type="hidden" name="post_name" value="<?php echo $_smarty_tpl->tpl_vars['post']->value['name'];?>
">
</form><?php }} ?>
