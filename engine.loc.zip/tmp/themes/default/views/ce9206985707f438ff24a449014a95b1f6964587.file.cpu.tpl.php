<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-22 13:54:01
         compiled from "themes/default/views/content_types/pages/cpu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:98219439056f0f085461d27-70391813%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce9206985707f438ff24a449014a95b1f6964587' => 
    array (
      0 => 'themes/default/views/content_types/pages/cpu.tpl',
      1 => 1458647640,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '98219439056f0f085461d27-70391813',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f0f0854ca500_27373283',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f0f0854ca500_27373283')) {function content_56f0f0854ca500_27373283($_smarty_tpl) {?>
<ul>
    <li><a href="1"></a></li>
    <li><a href="2"></a></li>
    <li><a href="3"></a></li>
    <li><a href="4"></a></li>
    <li><a href="8"></a></li>
    <li><a href="1;p=1"></a></li>
    <li><a href="2;p=3"></a></li>
    <li><a href="3;q=asdjklфів3"></a></li>
    <li><a href="3;q=asdjklфів3;p=4"></a></li>
    <li><a href="4;tag=seo"></a></li>
    <li><a href="4;tag=seo;author=wg"></a></li>
    <li><a href="4;tag=іущ"></a></li>
    <li><a href="4;author=wg"></a></li>
    <li><a href="4;author=wg;p=4"></a></li>
    <li><a href="4;brand=apple"></a></li>
    <li><a href="4;brand=apple;p=4"></a></li>
    <li><a href="4;filter/12=23"></a></li>
    <li><a href="4;filter/12=23;23=34"></a></li>
    <li><a href="4;filter/12=23;23=34;45=67"></a></li>
    <li><a href="4;filter/12=23,33,45;23=34;45=67"></a></li>
    <li><a href="4;filter/vendor=acer;display=14"></a></li>
    <li><a href="4;filter/vendor=acer;display=14;p=4"></a></li>
    <li><a href="4;filter/vendor=acer;display=14;ram=ddr3"></a></li>
    <li><a href="4;filter/vendor=acer,lenovo;display=14,15-16;ram=ddr3"></a></li>
    <li><a href="4;filter/vendor=acer,lenovo;display=14,15-16;ram=ddr3"></a></li>

    <li><a href="4;filter/vendor=acer;display=14;ram=ddr3;p=4"></a></li>

    <li><a href="8;order=name-desc"></a></li>
    <li><a href="8;order=name-asc"></a></li>
    <li><a href="8;order=price-asc"></a></li>
    <li><a href="8;order=price-asc"></a></li>
    <li><a href="8;order=action-asc"></a></li>
    <li><a href="8;order=action-desc"></a></li>
    <li><a href="8;order=action-desc;p=5"></a></li>
</ul><?php }} ?>
