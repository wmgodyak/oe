<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-21 16:48:56
         compiled from "/var/www/engine.loc/themes/default/views/chunks/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:51514328956efe62994a055-71038456%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5536caea60bcbc70e4980975adfc8943328028d8' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/chunks/footer.tpl',
      1 => 1458571268,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '51514328956efe62994a055-71038456',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56efe62994eec3_39856951',
  'variables' => 
  array (
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56efe62994eec3_39856951')) {function content_56efe62994eec3_39856951($_smarty_tpl) {?>

<div id="footer-white">
    <div class="container">
        <div class="row">
            <div class="col-sm-3 menu">
                <h3>Overview</h3>
                <ul>
                    <li>
                        <a href="features.html">Features</a>
                    </li>
                    <li>
                        <a href="services.html">Services</a>
                    </li>
                    <li>
                        <a href="pricing.html">Pricing</a>
                    </li>
                    <li>
                        <a href="support.html">Support</a>
                    </li>
                    <li>
                        <a href="blog.html">Blog</a>
                    </li>
                    <li>
                        <a href="blog.html">Coming soon</a>
                    </li>
                </ul>
            </div>
            <div class="col-sm-3 menu">
                <h3>Menu</h3>
                <ul>
                    <li>
                        <a href="features.html">About us</a>
                    </li>
                    <li>
                        <a href="services.html">Contact us</a>
                    </li>
                    <li>
                        <a href="aboutus.html">Jobs</a>
                        <a href="aboutus.html" class="hiring">
                            We're hiring!
                        </a>
                    </li>
                    <li>
                        <a href="support.html">Portfolio</a>
                    </li>
                    <li>
                        <a href="blog.html">Status</a>
                    </li>
                </ul>
            </div>
            <div class="col-sm-2 menu">
                <h3>Social</h3>
                <ul>
                    <li>
                        <a href="features.html">Youtube</a>
                    </li>
                    <li>
                        <a href="services.html">Facebook</a>
                    </li>
                    <li>
                        <a href="pricing.html">Twitter</a>
                    </li>
                </ul>
            </div>
            <div class="col-sm-4 newsletter">
                <div class="signup clearfix">
                    <p>
                        Sign up for the newsletter and we'll inform you of updates, offers and more.
                    </p>
                    <form>
                        <input type="text" name="email" class="form-control" placeholder="Your email address" />
                        <input type="submit" value="Sign up" />
                    </form>
                </div>
                <a href="#">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/images/social/social-tw.png" alt="twitter" />
                </a>
                <a href="#">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/images/social/social-dbl.png" alt="dribbble" />
                </a>
            </div>
        </div>
        <div class="row credits">
            <div class="col-md-12">
                Copyright © 2016. OYi.Engine7
            </div>
        </div>
    </div>
</div>
</body>
</html><?php }} ?>
