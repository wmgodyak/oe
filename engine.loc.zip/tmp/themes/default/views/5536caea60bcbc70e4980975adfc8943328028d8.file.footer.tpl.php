<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 09:31:38
         compiled from "/var/www/engine.loc/themes/default/views/chunks/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:51514328956efe62994a055-71038456%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5536caea60bcbc70e4980975adfc8943328028d8' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/chunks/footer.tpl',
      1 => 1467700127,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '51514328956efe62994a055-71038456',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56efe62994eec3_39856951',
  'variables' => 
  array (
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56efe62994eec3_39856951')) {function content_56efe62994eec3_39856951($_smarty_tpl) {?>

<!-- become l_footer -->
<footer class="l_footer">

    <!-- begin footer__main -->
    <div class="footer__main">
        <div class="container">

            <!-- begin footer__first -->
            <div class="footer__first">
                <div class="footer__logo">
                    <a class="footer__link" href="#">
                        <img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/footer-logo.png" alt="">
                    </a>
                </div>
                <div class="footer__c-description">
                    <span>Світ Мобільних Аксесуарів</span> - це
                    магазин, що пропонує якісний ремонт
                    та різні аксесуари для ваших телефонів
                    чи планшетів. Завжди якісно!
                </div>
                <div class="m_social">
                    <div class="social__heading">
                        Приєднуйтесь до нас у соцмережах:
                    </div>
                    <ul class="social__list">
                        <li class="social__item">
                            <a href="#" class="social__link social__link--vk"></a>
                        </li>
                        <li class="social__item">
                            <a href="#" class="social__link social__link--fb"></a>
                        </li>
                        <li class="social__item">
                            <a href="#" class="social__link social__link--ok"></a>
                        </li>
                        <li class="social__item">
                            <a href="#" class="social__link social__link--yt"></a>
                        </li>
                        <li class="social__item">
                            <a href="#" class="social__link social__link--ig"></a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- end footer__first -->

            <!-- begin footer__second -->
            <div class="footer__second">
                <div class="footer__heading">
                    Інформація
                </div>
                <div class="footer-nav">
                    <ul class="footer-nav__list">
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">
                                Про нас
                            </a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">
                                Доставка
                            </a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">
                                Оплата
                            </a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">
                                Сервіс
                            </a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">
                                Ми на карті
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- end footer__second -->

            <!-- begin footer__thirth -->
            <div class="footer__thirth">

                <div class="footer__heading">
                    Працюємо
                </div>

                <div class="footer__whours">
                    <span>З понеділка по п’ятницю:</span>

                    <span>09:00 - 19:00</span>

                    <span>Субота: 09:00 до 15:00</span>

                    <span>Неділя - вихідний</span>
                </div>
            </div>
            <!-- end footer__thirth -->

            <!-- begin footer__fourth -->
            <div class="footer__fourth">

                <div class="footer__heading">
                    Наші контакти
                </div>

                <div class="footer__contacts">

                    <a class="ks" href="#">
                        +38 (097) 59 88 666
                    </a>

                    <a class="vf" href="#">
                        +38 (099) 25 88 666
                    </a>

                    <a class="lc" href="#">
                        +38 (063) 59 88 666
                    </a>

                    <a class="gm" href="#">
                        sma.lviv@gmail.com
                    </a>

                    <a class="sk" href="#">
                        sma_lviv
                    </a>

                </div>

            </div>
            <!-- end footer__fourth -->

            <!-- begin footer__fifth -->
            <div class="footer__fifth">

                <div class="footer__heading">
                    Підписка
                </div>

                <div class="footer__subscription">
                    <div class="text">
                        Підпишіться на розсилку від СМА та
                        отримуйте завжди свіжі новини, акції
                        та пропозиції на свою електронну
                        скриньку.
                    </div>
                    <form action="#">
                        <div class="input-row">
                            <input type="email" placeholder="введіть ваш  e-mail">
                        </div>
                        <div class="btn-row">
                            <button>Підписатись</button>
                        </div>
                    </form>
                </div>

            </div>
            <!-- end footer__fifth -->


        </div>
    </div>
    <!-- end footer__main -->

    <!-- begin footer__bottom -->
    <div class="footer__bottom">
        <div class="container">
            <div class="copyright">
                © 2013-2016, Інтернет-магазин СМА
            </div>
        </div>
    </div>
    <!-- end footer__bottom -->

</footer>
<!-- end l_footer -->


<!-- become scripts -->
<?php echo '<script'; ?>
 src='<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/js/vendor/jquery-1.11.3.min.js'><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src='<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/js/vendor/jquery-ui.min.js'><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src='<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/js/vendor/jquery.formstyler.js'><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src='<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/js/vendor/owl.carousel.min.js'><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src='<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/js/vendor/jquery.barrating.min.js'><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src='<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/js/vendor/waterfall.min.js'><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/js/main.js"><?php echo '</script'; ?>
>
<!-- end scripts -->


</body>
</html><?php }} ?>
