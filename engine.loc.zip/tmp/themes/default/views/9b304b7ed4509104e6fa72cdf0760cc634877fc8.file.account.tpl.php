<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-29 18:22:21
         compiled from "themes/default/views/layouts/pages/account.tpl" */ ?>
<?php /*%%SmartyHeaderCode:181375353756f8de71cef196-79175100%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b304b7ed4509104e6fa72cdf0760cc634877fc8' => 
    array (
      0 => 'themes/default/views/layouts/pages/account.tpl',
      1 => 1459264941,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '181375353756f8de71cef196-79175100',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f8de71d064b5_26318822',
  'variables' => 
  array (
    'acc_content' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f8de71d064b5_26318822')) {function content_56f8de71d064b5_26318822($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<body id="signup">
    <?php echo $_smarty_tpl->tpl_vars['acc_content']->value;?>


<?php echo '<script'; ?>
 type="text/javascript">
    $(function () {
        $(".already-account a").popover();
        $(".already-account a").popover('show');
    });
<?php echo '</script'; ?>
><?php }} ?>
