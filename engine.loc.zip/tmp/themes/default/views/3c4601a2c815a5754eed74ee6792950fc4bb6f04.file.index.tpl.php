<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 14:28:15
         compiled from "/var/www/engine.loc/themes/default/views/modules/blog/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:599195946577b99cf85a288-66490558%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3c4601a2c815a5754eed74ee6792950fc4bb6f04' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/blog/index.tpl',
      1 => 1467718095,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '599195946577b99cf85a288-66490558',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b99cf87a8e3_29040006',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b99cf87a8e3_29040006')) {function content_577b99cf87a8e3_29040006($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<!-- begin wrapper -->
<div class="wrapper">

    <?php echo $_smarty_tpl->getSubTemplate ("chunks/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <!-- begin newspage -->
    <div class="newspage">
        <?php echo $_smarty_tpl->getSubTemplate ("modules/breadcrumbs.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


        <div class="container">

            <!-- begin newspage__content -->
            <div class="newspage__content">

                <div class="newspage__filter">

                    <?php echo $_smarty_tpl->getSubTemplate ("modules/blog/categories.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                    <?php echo $_smarty_tpl->getSubTemplate ("modules/blog/search_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


                </div>

                <?php echo $_smarty_tpl->getSubTemplate ("modules/blog/posts.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php echo $_smarty_tpl->getSubTemplate ("modules/pagiation.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


            </div>
            <!-- end newspage__content -->

            <?php echo $_smarty_tpl->getSubTemplate ("chunks/sidebar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


        </div>

    </div>
    <!-- end newspage -->

</div>
<!-- end wrapper -->
<?php echo $_smarty_tpl->getSubTemplate ("chunks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
