<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 13:46:13
         compiled from "/var/www/engine.loc/themes/default/views/chunks/head.tpl" */ ?>
<?php /*%%SmartyHeaderCode:34337200856efe5e54fe0f7-33785684%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dbc5ac8f830ec5a872c0cd0d98aa4c8304ffde13' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/chunks/head.tpl',
      1 => 1459334773,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '34337200856efe5e54fe0f7-33785684',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56efe5e5505504_80895939',
  'variables' => 
  array (
    'base_url' => 0,
    'page' => 0,
    'theme_url' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56efe5e5505504_80895939')) {function content_56efe5e5505504_80895939($_smarty_tpl) {?>

<!DOCTYPE html>
<html>
<head>

    <!-- (c) Developed by Otakoyi.com | http://www.otakoyi.com/ -->
    <!-- (c) Powered by OYi.Engine | http://www.engine.otakoyi.com/ -->

    <base href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <title><?php echo $_smarty_tpl->tpl_vars['page']->value['title'];?>
</title>
    <meta name="description" content="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['page']->value['description'], ENT_QUOTES, 'UTF-8', true);?>
"/>
    <meta name="keywords" content="<?php ob_start();?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['page']->value['keywords'], ENT_QUOTES, 'UTF-8', true);?>
<?php $_tmp1=ob_get_clean();?><?php echo $_tmp1;?>
" />
    <meta name="author" content="<?php echo $_smarty_tpl->tpl_vars['page']->value['author']['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['page']->value['author']['surname'];?>
">
    <meta name="generator" content="OYi.Engine7">

    <link rel="icon" type="image/x-icon" href=<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- stylesheets -->
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/css/compiled/theme.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/css/vendor/animate.css">

    <!-- javascript -->
    <?php echo '<script'; ?>
 src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/bootstrap/bootstrap.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/theme.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/plugins.js" id="appScr"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/app.js" id="appScr"><?php echo '</script'; ?>
>

    <!--[if lt IE 9]>
    <?php echo '<script'; ?>
 src="http://html5shim.googlecode.com/svn/trunk/html5.js"><?php echo '</script'; ?>
>
    <![endif]-->
    <?php echo '<script'; ?>
>
        var TOKEN = '<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
', LANG_ID=<?php echo $_smarty_tpl->tpl_vars['page']->value['languages_id']*1;?>
;
    <?php echo '</script'; ?>
>
</head><?php }} ?>
