<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 14:18:51
         compiled from "/var/www/engine.loc/themes/default/views/chunks/sidebar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:304818074577b979b3d7a75-32967419%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e48275eb8ef9bf826a8a5173c9ef197a090cd44b' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/chunks/sidebar.tpl',
      1 => 1467717531,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '304818074577b979b3d7a75-32967419',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b979b3df588_08665309',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b979b3df588_08665309')) {function content_577b979b3df588_08665309($_smarty_tpl) {?>
<!-- begin asider -->
<aside class="asider">
    <div class="vk-widget">

    </div>
    <div class="fb-widget">

    </div>
    <div class="m_discount-widget">
        <div class="discount__heading1">
            Ви у нас вперше?
        </div>
        <div class="discount__content">
            <div class="discount__img-block">
                <div class="discount__img" style="background-image: url('<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/discount-widget/img1.png');"></div>
            </div>
            <div class="discount__heading2">
                Отримайте знижку!
            </div>
            <div class="discount__text">
                Введіть свою електронну скриньку
                та отримайте знижку у нашому
                інтернет магазині, а також будьте
                завжди в курсі наших новин.
            </div>
            <form action="#">
                <div class="input-group">
                    <input type="email" placeholder="Введіть свій e-mail">
                </div>
                <div class="btn-row">
                    <button class="btn md red">Хочу знижку</button>
                </div>
            </form>
        </div>
    </div>
    <div class="weather-widget"></div>
</aside>
<!-- end asider --><?php }} ?>
