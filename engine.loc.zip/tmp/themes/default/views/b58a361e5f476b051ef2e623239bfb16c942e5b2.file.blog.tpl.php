<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-25 12:24:49
         compiled from "/var/www/engine.loc/themes/default/views/content_types/blog.tpl" */ ?>
<?php /*%%SmartyHeaderCode:127351552956f3f42baa0fb9-78276233%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b58a361e5f476b051ef2e623239bfb16c942e5b2' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/content_types/blog.tpl',
      1 => 1458901488,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '127351552956f3f42baa0fb9-78276233',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f3f42babcbb1_46773367',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f3f42babcbb1_46773367')) {function content_56f3f42babcbb1_46773367($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<body id="blog">
<?php echo $_smarty_tpl->getSubTemplate ("modules/nav/top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<div id="posts">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <?php echo $_smarty_tpl->getSubTemplate ("modules/blog/posts.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php echo $_smarty_tpl->getSubTemplate ("modules/pagiation.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            </div>
            <div class="col-md-3 sidebar">
                <div class="search">
                    <form action="25">
                        <span class="icomoon-search"></span>
                        <input type="text" name="q" placeholder="Search on blog..." />
                    </form>
                </div>
                <?php echo $_smarty_tpl->getSubTemplate ("modules/blog/categories.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            </div>
        </div>
    </div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("chunks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<?php echo '<script'; ?>
 type="text/javascript">
    $(function () {
        $(".search input:text").focus(function () {
            $(".icomoon-search").addClass("active");
        });
        $(".search input:text").blur(function () {
            $(".icomoon-search").removeClass("active");
        });
    });
<?php echo '</script'; ?>
>
</body>
</html><?php }} ?>
