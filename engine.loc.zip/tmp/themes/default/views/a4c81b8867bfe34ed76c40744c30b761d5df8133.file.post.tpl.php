<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-31 09:52:14
         compiled from "themes/default/views/layouts/post.tpl" */ ?>
<?php /*%%SmartyHeaderCode:108580936056f53252845f65-72151898%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a4c81b8867bfe34ed76c40744c30b761d5df8133' => 
    array (
      0 => 'themes/default/views/layouts/post.tpl',
      1 => 1459407134,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '108580936056f53252845f65-72151898',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f532528748e5_09462372',
  'variables' => 
  array (
    'post' => 0,
    'theme_url' => 0,
    'blog_page_id' => 0,
    'tag' => 0,
    'user' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f532528748e5_09462372')) {function content_56f532528748e5_09462372($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<body id="blogpost">
<?php echo $_smarty_tpl->getSubTemplate ("modules/nav/top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div id="blogpost-wrapper">
    <div class="container">
        
        <?php if ($_smarty_tpl->tpl_vars['post']->value['image']) {?>
        <div class="row">
            <div class="col-md-12">
                <div class="main-pic">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['post']->value['image']['path'];?>
post/<?php echo $_smarty_tpl->tpl_vars['post']->value['image']['image'];?>
" class="img-responsive" alt="blogpost" />
                </div>
            </div>
        </div>
        <?php }?>
        <div class="row">
            <div class="col-md-10 post">
                <div class="title">
                    <?php echo $_smarty_tpl->tpl_vars['post']->value['name'];?>

                </div>
                <div class="author">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['post']->value['author']['avatar'];?>
" class="avatar" alt="author" />
                    By <?php echo $_smarty_tpl->tpl_vars['post']->value['author']['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['post']->value['author']['surname'];?>
, <?php echo $_smarty_tpl->tpl_vars['post']->value['published'];?>

                </div>
                <div class="content">
                   <?php echo $_smarty_tpl->tpl_vars['post']->value['content'];?>

                </div>
                <div class="share">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/images/share.png" alt="share" />
                </div>
                <?php if (count($_smarty_tpl->tpl_vars['post']->value['tags'])) {?>
                <div class="share">
                    <?php  $_smarty_tpl->tpl_vars['tag'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['tag']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['post']->value['tags']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['tag']->key => $_smarty_tpl->tpl_vars['tag']->value) {
$_smarty_tpl->tpl_vars['tag']->_loop = true;
?>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['blog_page_id']->value;?>
;tag=<?php echo $_smarty_tpl->tpl_vars['tag']->value['tag'];?>
"><?php echo $_smarty_tpl->tpl_vars['tag']->value['tag'];?>
</a>
                    <?php } ?>
                </div>
                <?php }?>
                <div class="other-posts">
                    <?php if ($_smarty_tpl->tpl_vars['post']->value['prev_post']) {?>
                    <a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['prev_post']['id'];?>
" class="prev">
                        ← <?php echo $_smarty_tpl->tpl_vars['post']->value['prev_post']['name'];?>

                    </a>
                    <?php }?>
                    <?php if ($_smarty_tpl->tpl_vars['post']->value['next_post']) {?>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['next_post']['id'];?>
" class="next pull-right">
                            <?php echo $_smarty_tpl->tpl_vars['post']->value['next_post']['name'];?>
 →
                        </a>
                    <?php }?>
                </div>
            </div>
        </div>
        <?php if ($_smarty_tpl->tpl_vars['post']->value['comments']['enabled']) {?>
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <h3>Comments to <?php echo $_smarty_tpl->tpl_vars['post']->value['name'];?>
.</h3>
                    <h4>Total comments <?php echo $_smarty_tpl->tpl_vars['post']->value['comments']['total'];?>
</h4>
                    <?php if ($_smarty_tpl->tpl_vars['user']->value) {?>
                        <p><a href="javascript:;" class="<?php if ($_smarty_tpl->tpl_vars['post']->value['comments']['subscribe']) {?>b-comments-un-subscribe<?php } else { ?>b-comments-subscribe<?php }?>" data-s="Subscribe" data-us="Un subscribe" data-id="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
"><?php if ($_smarty_tpl->tpl_vars['post']->value['comments']['subscribe']) {?>b-comments-un-subscribe<?php } else { ?>b-comments-subscribe<?php }?></a></p>
                        <?php echo $_smarty_tpl->getSubTemplate ("modules/comments/create.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                    <?php } else { ?>
                        <p><a href="29">Авторизуйтесь, щоб мати можливість коментувати статті</a></p>
                    <?php }?>

                    <?php echo $_smarty_tpl->getSubTemplate ("modules/comments/items.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                </div>
            </div>
        <?php }?>
    </div>
</div>


<?php echo $_smarty_tpl->getSubTemplate ("chunks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</body>
</html><?php }} ?>
