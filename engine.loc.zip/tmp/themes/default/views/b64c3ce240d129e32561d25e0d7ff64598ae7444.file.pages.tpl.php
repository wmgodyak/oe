<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-24 16:12:47
         compiled from "themes/default/views/content_types/pages.tpl" */ ?>
<?php /*%%SmartyHeaderCode:80217639156efe4b35c7757-33643915%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b64c3ce240d129e32561d25e0d7ff64598ae7444' => 
    array (
      0 => 'themes/default/views/content_types/pages.tpl',
      1 => 1458828345,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '80217639156efe4b35c7757-33643915',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56efe4b35d9027_29243483',
  'variables' => 
  array (
    'theme_url' => 0,
    'page' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56efe4b35d9027_29243483')) {function content_56efe4b35d9027_29243483($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<body id="about-us">
<?php echo $_smarty_tpl->getSubTemplate ("modules/nav/top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/jquery.flexslider.min.js"><?php echo '</script'; ?>
>
<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/css/vendor/flexslider.css">
<div id="slider">
    <div class="container">
        <div class="row header">
            <div class="col-md-12">
                <h3><?php echo $_smarty_tpl->tpl_vars['page']->value['name'];?>
</h3>
                <p>
                    <?php echo $_smarty_tpl->tpl_vars['page']->value['description'];?>

                </p>
            </div>
        </div>
        <?php echo $_smarty_tpl->getSubTemplate ("modules/slider.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>
</div>

<div id="info">
    <div class="container">
        <a href="2;#abourt">about anchor</a>
        <?php echo $_smarty_tpl->tpl_vars['page']->value['content'];?>

    </div>
</div>

<div id="cta">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wrapper clearfix">
                    <h4>Try React now and take your own project to a whole new level.</h4>
                    <a href="signup.html" class="button button-small">Sign up free</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("chunks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<?php echo '<script'; ?>
 type="text/javascript">
    $(function() {
        $('.flexslider').flexslider({
            directionNav: false,
            slideshowSpeed: 4000
        });
        $('[data-toggle="tooltip"]').tooltip();
    });
<?php echo '</script'; ?>
>
</body><?php }} ?>
