<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-24 11:58:26
         compiled from "/var/www/engine.loc/themes/default/views/modules/nav/top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1118257356f00133b77757-50079377%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5f8520bc44224d07c86d4abe0800d87f41cf3e16' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/nav/top.tpl',
      1 => 1458813506,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1118257356f00133b77757-50079377',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f00133b7cc17_87588021',
  'variables' => 
  array (
    'nav' => 0,
    'page' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f00133b7cc17_87588021')) {function content_56f00133b7cc17_87588021($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['nav']->value['top']) {?>
<header class="navbar navbar-inverse <?php if ($_smarty_tpl->tpl_vars['page']->value['id']==1) {?>hero<?php } else { ?>normal<?php }?>" role="banner">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="1" class="navbar-brand">OYi.Engine7</a>
        </div>
        <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
            <ul class="nav navbar-nav navbar-right">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['nav']->value['top']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                <li <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>class="dropdown"<?php }?>>
                    <a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
" <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>class="dropdown-toggle" data-toggle="dropdown"<?php }?>>
                        <?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
 <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?><b class="caret"></b><?php }?>
                    </a>
                    <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
                    <ul class="dropdown-menu">
                        <li><a href="1">Home 1 (Current)</a></li>
                        <li><a href="index2.html">Home 2 (Slider)</a></li>
                        <li><a href="index3.html">Home 3 (Off-canvas menu)</a></li>
                    </ul>
                    <?php }?>
                </li>
                <?php } ?>
            </ul>
        </nav>
    </div>
</header>
<?php }?><?php }} ?>
