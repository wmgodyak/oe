<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 09:31:38
         compiled from "/var/www/engine.loc/themes/default/views/modules/nav/top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1118257356f00133b77757-50079377%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5f8520bc44224d07c86d4abe0800d87f41cf3e16' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/nav/top.tpl',
      1 => 1467700127,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1118257356f00133b77757-50079377',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f00133b7cc17_87588021',
  'variables' => 
  array (
    'app' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f00133b7cc17_87588021')) {function content_56f00133b7cc17_87588021($_smarty_tpl) {?><!-- begin main-nav -->
<nav class="main-nav">
    <ul class="main-nav__list">
        <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['app']->value->nav->get('top'); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
        <li class="main-nav__item">
            <a class="main-nav__link" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a>
        </li>
        <?php } ?>
    </ul>
</nav>
<!-- end main-nav --><?php }} ?>
