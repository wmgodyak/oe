<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-24 16:12:36
         compiled from "themes/default/views/content_types/pages/blog.tpl" */ ?>
<?php /*%%SmartyHeaderCode:118288468256f3f42ba8ddb8-08248673%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b9bd7fe27e606949c623c0948261cd1e7943f180' => 
    array (
      0 => 'themes/default/views/content_types/pages/blog.tpl',
      1 => 1458828755,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '118288468256f3f42ba8ddb8-08248673',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f3f42ba9e001_93933069',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f3f42ba9e001_93933069')) {function content_56f3f42ba9e001_93933069($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("content_types/blog.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
