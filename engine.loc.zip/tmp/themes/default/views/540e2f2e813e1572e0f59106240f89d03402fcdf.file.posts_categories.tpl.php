<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-25 11:54:05
         compiled from "themes/default/views/content_types/posts_categories.tpl" */ ?>
<?php /*%%SmartyHeaderCode:168414724656f50abd7c0173-19694071%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '540e2f2e813e1572e0f59106240f89d03402fcdf' => 
    array (
      0 => 'themes/default/views/content_types/posts_categories.tpl',
      1 => 1458230141,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '168414724656f50abd7c0173-19694071',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f50abd7d81e5_84844448',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f50abd7d81e5_84844448')) {function content_56f50abd7d81e5_84844448($_smarty_tpl) {?>
<?php }} ?>
