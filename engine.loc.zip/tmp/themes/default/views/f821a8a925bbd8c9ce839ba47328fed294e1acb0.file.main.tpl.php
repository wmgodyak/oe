<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-29 10:00:01
         compiled from "themes/default/views/layouts/pages/main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:135537450756f535ca2a84b9-04854566%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f821a8a925bbd8c9ce839ba47328fed294e1acb0' => 
    array (
      0 => 'themes/default/views/layouts/pages/main.tpl',
      1 => 1467183600,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '135537450756f535ca2a84b9-04854566',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f535ca3141b9_09149076',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f535ca3141b9_09149076')) {function content_56f535ca3141b9_09149076($_smarty_tpl) {?>







It works!<?php }} ?>
