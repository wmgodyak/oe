<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 09:31:37
         compiled from "/var/www/engine.loc/themes/default/views/modules/languages/switcher.tpl" */ ?>
<?php /*%%SmartyHeaderCode:537310138577b544a000b45-62739474%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a3bbad09a7bdc5ccb640c2adaa4f4596cba39978' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/languages/switcher.tpl',
      1 => 1467700127,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '537310138577b544a000b45-62739474',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'app' => 0,
    'page' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b544a00d654_24587848',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b544a00d654_24587848')) {function content_577b544a00d654_24587848($_smarty_tpl) {?>
<!-- begin lang-switcher -->
<div class="lang-switcher">
    <span>Мова:</span>
    <ul class="lang-switcher__list">
        <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['app']->value->languages->get(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
        <li class="lang-switcher__item lang-switcher__item--active">
            <a class="lang-switcher__link" href="<?php echo $_smarty_tpl->tpl_vars['page']->value['id'];?>
;lang=<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a>
        </li>
        <?php } ?>
    </ul>
</div>
<!-- end lang-switcher -->
<?php }} ?>
