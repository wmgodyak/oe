<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 13:47:25
         compiled from "/var/www/engine.loc/themes/default/views/modules/blog/latest.tpl" */ ?>
<?php /*%%SmartyHeaderCode:768086374577b6af471e102-08471537%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '89a1072152e4620435678961f88205874671026c' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/blog/latest.tpl',
      1 => 1467715536,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '768086374577b6af471e102-08471537',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b6af4732936_99902682',
  'variables' => 
  array (
    't' => 0,
    'mod' => 0,
    'post' => 0,
    'app' => 0,
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b6af4732936_99902682')) {function content_577b6af4732936_99902682($_smarty_tpl) {?><!-- begin main-articles -->
<div class="main-articles">

    <div class="container">

        <div class="heading"><?php echo $_smarty_tpl->tpl_vars['t']->value['blog']['widget_title'];?>
</div>
        <a class="show-all-news" href="5"><?php echo $_smarty_tpl->tpl_vars['t']->value['blog']['widget_more'];?>
</a>
        <ul class="main-news__list">
            <?php  $_smarty_tpl->tpl_vars['post'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['post']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['mod']->value->blog->latestPosts(0,0,3); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['post']->key => $_smarty_tpl->tpl_vars['post']->value) {
$_smarty_tpl->tpl_vars['post']->_loop = true;
?>
            <li class="main-news__item">
                <a class="main-news__link" href="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
">
                        <span class="main-news__img-block">
                            <img style="max-width: 132px;" class="main-news__img" src="<?php echo $_smarty_tpl->tpl_vars['app']->value->images->cover($_smarty_tpl->tpl_vars['post']->value['id'],'post');?>
" alt="<?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
">
                        </span>
                        <span class="main-news__text-block">
                            <span class="main-news__heading">
                                <?php echo $_smarty_tpl->tpl_vars['post']->value['name'];?>

                            </span>
                            <span class="main-news__content-text">
                                <?php echo $_smarty_tpl->tpl_vars['post']->value['intro'];?>

                            </span>
                            <span class="main-news__date">
                                18 березня 2016
                            </span>
                        </span>
                </a>
            </li>
            <?php } ?>
        </ul>

        <a class="show-all-news xs" href="5"><?php echo $_smarty_tpl->tpl_vars['t']->value['blog']['widget_more'];?>
</a>

        <div class="main-about-us">

            <div class="about-us__left-banner">
                <div class="wrap">
                    <div class="left-block">
                        <div class="img-block">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/seo_logo.png" alt="">
                            <span>Завжди обирай краще!</span>
                        </div>
                    </div>

                    <div class="right-block">
                        <div class="benefits__list">
                            <div class="benefits__item">
                                <div class="benefits__icon i1"></div>
                                <div class="benefits__text">Доступно</div>
                            </div>
                            <div class="benefits__item">
                                <div class="benefits__icon i2"></div>
                                <div class="benefits__text">Сучасно</div>
                            </div>
                            <div class="benefits__item">
                                <div class="benefits__icon i3"></div>
                                <div class="benefits__text">Якісно</div>
                            </div>
                            <div class="benefits__item">
                                <div class="benefits__icon i4"></div>
                                <div class="benefits__text">Швидко</div>
                            </div>
                        </div>
                        <div class="description">
                            Купуючи продукцію в СМА, Ви стаєте для нас важливим
                            клієнтом та маєте шанс отримати знижки і бути учасником
                            наших акцій. Обирайте саме те, що вам потрібно.
                        </div>
                    </div>
                </div>
            </div>
            <div class="about-us__right-banner">

                <div class="heading">
                    Інтернет-магазин «Світ Мобільних Аксесуарів»
                </div>

                <div class="content">
                    У інтернет-магазині СМА ви завжди можете замовити аксесуари та запчастини для вашого
                    телефону чи планшету. Також ми пропонуємо вам якісний ремонт телефонів, планшетів та
                    цифрових фотоапаратів із гарантією якості. Ми доставимо ваші замовлення у будь-яку точку
                    України (Львів, Тернопіль, Рівне, Івано-Франківськ, Житомир, Київ, Одеса, Полтава, Чернігів,
                    Суми, Хмельницький, Вінниця, Чернівці,). Звертайтесь у Світ Мобільних Аксесуарів і Вам
                    завжди радо допоможуть та нанадуть необхідні консультації.
                </div>

                <div class="address-row">
                    Вул. Наукова 7а, Офіс №124. <a href="#">Детальніше про нас</a>
                </div>
            </div>
        </div>

    </div>

</div>
<!-- end main-articles --><?php }} ?>
