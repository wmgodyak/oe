<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 13:41:17
         compiled from "/var/www/engine.loc/themes/default/views/modules/account/new_psw.tpl" */ ?>
<?php /*%%SmartyHeaderCode:67540990656fb8da2781bd8-09031643%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dc17fd62da79609541f47629a042ae293ba86640' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/account/new_psw.tpl',
      1 => 1459334390,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '67540990656fb8da2781bd8-09031643',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fb8da279cc54_97280513',
  'variables' => 
  array (
    'user' => 0,
    'token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fb8da279cc54_97280513')) {function content_56fb8da279cc54_97280513($_smarty_tpl) {?><div class="container">
    <div class="row header">
        <div class="col-md-12">
            <h3 class="logo">
                <a href="1">New password</a>
            </h3>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="wrapper clearfix">
                <div class="formy">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if (!$_smarty_tpl->tpl_vars['user']->value['id']) {?>
                                <p>Wrong key</p>
                                <?php } else { ?>
                                <form role="form" action="ajax/account/newPsw" data-href="29" method="post" id="accountNewPsw">
                                    <div class="response"></div>
                                    <p>Change password</p>
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" class="form-control" name="data[password]" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="password_c">Password Confirm</label>
                                        <input type="password" class="form-control" name="data[password_c]" required />
                                    </div>
                                    <div class="submit">
                                        <button type="submit" class="button-clear">
                                            <span>Save</span>
                                        </button>
                                    </div>
                                    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
                                    <input type="hidden" name="id"    value="<?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
">
                                </form>
                            <?php }?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="already-account">
                Go to register
                <a href="30" >register here</a> |
                <a href="29">login</a>
            </div>
        </div>
    </div>
</div><?php }} ?>
