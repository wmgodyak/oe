<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 17:34:39
         compiled from "787c92e3e5876020dd24d59c0f84d7ddd162162d" */ ?>
<?php /*%%SmartyHeaderCode:86652861256fbe3ff060419-90335435%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '787c92e3e5876020dd24d59c0f84d7ddd162162d' => 
    array (
      0 => '787c92e3e5876020dd24d59c0f84d7ddd162162d',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '86652861256fbe3ff060419-90335435',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fbe3ff07a074_45471465',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fbe3ff07a074_45471465')) {function content_56fbe3ff07a074_45471465($_smarty_tpl) {?><p>Вітаємо.<br />
Новий коментар до статі <?php echo $_smarty_tpl->tpl_vars['data']->value['post_name'];?>
.<br />
Ім&#39;я: <?php echo $_smarty_tpl->tpl_vars['data']->value['user']['name'];?>
<br />
Email: <?php echo $_smarty_tpl->tpl_vars['data']->value['user']['email'];?>
<br />
Коментар: <?php echo $_smarty_tpl->tpl_vars['data']->value['message'];?>
<br />
<br />
----------------------------------<br />
Ви можете <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['approve_url'];?>
">опублікувати коменар</a> або <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['delete_url'];?>
">видалити</a> його.</p>
<?php }} ?>
