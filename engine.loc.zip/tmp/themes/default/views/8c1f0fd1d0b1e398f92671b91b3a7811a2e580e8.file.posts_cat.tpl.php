<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-25 12:01:51
         compiled from "themes/default/views/content_types/posts_cat.tpl" */ ?>
<?php /*%%SmartyHeaderCode:32523319656f50c3671e1a8-82950448%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c1f0fd1d0b1e398f92671b91b3a7811a2e580e8' => 
    array (
      0 => 'themes/default/views/content_types/posts_cat.tpl',
      1 => 1458900109,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32523319656f50c3671e1a8-82950448',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f50c36732b02_38179760',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f50c36732b02_38179760')) {function content_56f50c36732b02_38179760($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("content_types/blog.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
