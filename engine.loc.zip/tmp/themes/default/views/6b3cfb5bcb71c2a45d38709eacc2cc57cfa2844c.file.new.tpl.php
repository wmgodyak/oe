<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 11:06:09
         compiled from "/var/www/engine.loc/themes/default/views/modules/shop/widgets/new.tpl" */ ?>
<?php /*%%SmartyHeaderCode:549352326577b6a71d134d8-21109976%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6b3cfb5bcb71c2a45d38709eacc2cc57cfa2844c' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/shop/widgets/new.tpl',
      1 => 1467705969,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '549352326577b6a71d134d8-21109976',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b6a71d40da8_03131111',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b6a71d40da8_03131111')) {function content_577b6a71d40da8_03131111($_smarty_tpl) {?>
<div class="m_goods-multiple-carousel">

    <div class="goods-multiple-carousel__wrap">

        <div class="goods-multiple-slider__name">Нові товари</div>

        <div class="goods-multiple-slider goods-multiple-slider--5">

            <div class="goods-multiple-slider__item">

                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                        <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/r-sim.png" alt="">
                                   </span>

                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>

                                   <span class="product-item__name">
                                       R-SIM 9 Pro для iPhone 4/4s та iPhone 5/5s
                                   </span>

                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>

                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>

                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>

                                   <span class="m_novelty"></span>
                               </span>
                </a>

            </div>

            <div class="goods-multiple-slider__item">

                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/3D-plivka.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>

                                   <span class="product-item__name">
                                      Захисна 3D плівка для iPhone 4/4s
                                   </span>

                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>

                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>

                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>

                                   <span class="m_novelty"></span>
                               </span>
                </a>

            </div>

            <div class="goods-multiple-slider__item">

                <a href="#" class="product-item__slider__link">
                                <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/Lenovo_ZP.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>
                                   <span class="product-item__name">
                                       Зарядний пристрій Lenovo
                                   </span>
                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>
                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>
                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>
                                   <span class="m_novelty"></span>
                               </span>
                </a>

            </div>

            <div class="goods-multiple-slider__item">
                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/kvanta.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>
                                   <span class="product-item__name">
                                       Акумулятор підвищеної ємності Kvanta HTC ...
                                   </span>
                                   <span class="product-item__price product-item__price--disabled">
                                       399,00 грн
                                   </span>
                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>
                                   <span class="product-item__activities">

                                       <button class="btn sm disabled-gray">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--disabled">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>
                                   <span class="m_novelty"></span>
                                </span>
                </a>
            </div>

            <div class="goods-multiple-slider__item">
                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/Glass.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>
                                   <span class="product-item__name">
                                       Захисне скло Tempered Glass Pro+ для Samsu...
                                   </span>
                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>
                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>
                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>
                                   <span class="m_novelty"></span>
                               </span>
                </a>
            </div>

            <div class="goods-multiple-slider__item">

                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/r-sim.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>
                                   <span class="product-item__name">
                                       R-SIM 9 Pro для iPhone 4/4s та iPhone 5/5s
                                   </span>
                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>
                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>
                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>
                                   <span class="m_novelty"></span>
                               </span>
                </a>

            </div>

            <div class="goods-multiple-slider__item">

                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/3D-plivka.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>
                                   <span class="product-item__name">
                                      Захисна 3D плівка для iPhone 4/4s
                                   </span>
                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>
                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>
                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>
                                   <span class="m_novelty"></span>
                               </span>
                </a>

            </div>

            <div class="goods-multiple-slider__item">

                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/Lenovo_ZP.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>
                                   <span class="product-item__name">
                                       Зарядний пристрій Lenovo
                                   </span>
                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>
                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>
                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>
                                   <span class="m_novelty"></span>
                               </span>
                </a>

            </div>

            <div class="goods-multiple-slider__item">

                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/kvanta.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>
                                   <span class="product-item__name">
                                       Акумулятор підвищеної ємності Kvanta HTC ...
                                   </span>
                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>
                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>
                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>
                                   <span class="m_novelty"></span>
                               </span>
                </a>

            </div>

            <div class="goods-multiple-slider__item">

                <a href="#" class="goods-multiple-slider__link">
                               <span class="m_product-item">
                                   <span class="product-item__img-row">
                                       <img class="product-item__img" src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
/assets/img/TOVARS/Glass.png" alt="">
                                   </span>
                                   <span class="m_star-rating">
                                       <select class="star-rating read-only">
                                           <option value="1">1</option>
                                           <option value="2">2</option>
                                           <option value="3">3</option>
                                           <option value="4">4</option>
                                           <option value="5">5</option>
                                       </select>
                                   </span>
                                   <span class="product-item__name">
                                       Захисне скло Tempered Glass Pro+ для Samsu...
                                   </span>
                                   <span class="product-item__price">
                                       399,00 грн
                                   </span>
                                   <span class="product-item__bonus">
                                       Ваш СМА бонус: <span>+42,92 грн</span>
                                   </span>
                                   <span class="product-item__activities">

                                       <button class="btn sm red">Купити в 1 клік</button>

                                       <span class="m_cart-indicator m_cart-indicator--out">
                                       </span>

                                       <span class="m_hearth-like">
                                           <span class="hearth-like__link"></span>
                                       </span>

                                   </span>
                                   <span class="m_novelty"></span>
                               </span>
                </a>

            </div>

        </div>

    </div>

</div><?php }} ?>
