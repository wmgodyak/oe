<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-24 16:36:40
         compiled from "themes/default/views/content_types/posts.tpl" */ ?>
<?php /*%%SmartyHeaderCode:197446974256f3fb7887dfe2-56557215%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '229c30e44acf136aa9c54604238054b023f5e7a5' => 
    array (
      0 => 'themes/default/views/content_types/posts.tpl',
      1 => 1458229719,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '197446974256f3fb7887dfe2-56557215',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f3fb78887d42_42026387',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f3fb78887d42_42026387')) {function content_56f3fb78887d42_42026387($_smarty_tpl) {?>
<?php }} ?>
