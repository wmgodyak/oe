<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 18:18:54
         compiled from "/var/www/engine.loc/themes/default/views/modules/comments/items.tpl" */ ?>
<?php /*%%SmartyHeaderCode:65150247856fbe5f0f39b49-75734325%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '36b348b3e7d95f1031abe169b35baaba46f3effb' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/comments/items.tpl',
      1 => 1459351134,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '65150247856fbe5f0f39b49-75734325',
  'function' => 
  array (
    'renderComment' => 
    array (
      'parameter' => 
      array (
      ),
      'compiled' => '',
    ),
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fbe5f0f3c656_28438314',
  'variables' => 
  array (
    'post' => 0,
    'offset' => 0,
    'item' => 0,
    'c' => 0,
  ),
  'has_nocache_code' => 0,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fbe5f0f3c656_28438314')) {function content_56fbe5f0f3c656_28438314($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['post']->value['comments']['total']>0) {?>
    
    <?php if (!function_exists('smarty_template_function_renderComment')) {
    function smarty_template_function_renderComment($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['renderComment']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>

        <div class="com-md-12 col-md-offset-<?php echo $_smarty_tpl->tpl_vars['offset']->value;?>
">
            <div class="date">
                <div class="day"><?php echo $_smarty_tpl->tpl_vars['item']->value['pubdate'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['user']['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['user']['surname'];?>
</div>
                <p class="ok">
                    <?php echo $_smarty_tpl->tpl_vars['item']->value['message'];?>

                </p>
                <p><button class="btn btn-link comment-reply" data-parent="<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
">Reply</button></p>
            </div>
            <?php if ($_smarty_tpl->tpl_vars['item']->value['isfolder']) {?>
                    <?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
                        <?php smarty_template_function_renderComment($_smarty_tpl,array('item'=>$_smarty_tpl->tpl_vars['c']->value,'offset'=>$_smarty_tpl->tpl_vars['offset']->value+1));?>

                    <?php } ?>
            <?php }?>
        </div>
    <?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>

<div class="row">
    <div class="col-md-12">
        <div class="messages">
            <h3>Messages</h3>
            <div class="com-md-12">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['post']->value['comments']['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                    <?php smarty_template_function_renderComment($_smarty_tpl,array('item'=>$_smarty_tpl->tpl_vars['item']->value,'offset'=>0));?>

                <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php }?><?php }} ?>
