<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-31 17:16:19
         compiled from "0ad352bd45f5869f85cb58c9b2619e4a9075c86c" */ ?>
<?php /*%%SmartyHeaderCode:13292502156fd31330cbf81-51593557%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0ad352bd45f5869f85cb58c9b2619e4a9075c86c' => 
    array (
      0 => '0ad352bd45f5869f85cb58c9b2619e4a9075c86c',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '13292502156fd31330cbf81-51593557',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fd31330e45b0_64020411',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fd31330e45b0_64020411')) {function content_56fd31330e45b0_64020411($_smarty_tpl) {?><p>Вітаємо. Нове повідомлення з форми контактів.</p>

<p>Ім&#39;я: <?php echo $_smarty_tpl->tpl_vars['data']->value['name'];?>
</p>

<p>Телефон: <?php echo $_smarty_tpl->tpl_vars['data']->value['phone'];?>
</p>

<p>Email: <?php echo $_smarty_tpl->tpl_vars['data']->value['email'];?>
</p>

<p>Повідомлення</p>

<p><?php echo $_smarty_tpl->tpl_vars['data']->value['message'];?>
</p>
<?php }} ?>
