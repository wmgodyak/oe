<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-31 17:03:23
         compiled from "themes/default/views/layouts/pages/contacts.tpl" */ ?>
<?php /*%%SmartyHeaderCode:143184610756fd2d8db30bf5-42723508%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3d9500130b32494eb51b8b268ec322a9572ccf99' => 
    array (
      0 => 'themes/default/views/layouts/pages/contacts.tpl',
      1 => 1459433002,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '143184610756fd2d8db30bf5-42723508',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fd2d8db4ca87_30968937',
  'variables' => 
  array (
    'theme_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fd2d8db4ca87_30968937')) {function content_56fd2d8db4ca87_30968937($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<body id="contact-us">
<?php echo $_smarty_tpl->getSubTemplate ("modules/nav/top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div id="map" style="height:400px;">

    <iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com.mx/?ie=UTF8&amp;ll=32.689593,-117.18039&amp;spn=0.023259,0.038495&amp;t=m&amp;z=15&amp;output=embed"></iframe>

    <div class="marker-wrapper">
        <div class="marker-icon"></div>
        <div class="marker"></div>
    </div>

    <div id="directions">
        <p>Get directions to our office</p>
        <form>
            <div class="form-group">
                <input class="form-control" type="text" placeholder="Write your zip code" />
            </div>
            <button type="submit" class="button button-small">
                <span>Get directions</span>
            </button>
        </form>
    </div>
</div>

<div id="info">
    <div class="container">
        <div class="row">
            <div class="col-md-8 message">
                <h3>Send us a message</h3>
                <p>
                    You can contact us with anything related to React. <br/> We'll get in touch with you as soon as possible.
                </p>
                <?php echo $_smarty_tpl->getSubTemplate ("modules/feedback/form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            </div>
            <div class="col-md-4 contact">
                <div class="address">
                    <h3>Our Address</h3>
                    <p>
                        The Old Road Willington, <br />
                        7 Kings Road, <br />
                        Southshore, 64890
                    </p>
                </div>
                <div class="phone">
                    <h3>By Phone</h3>
                    <p>
                        1-800-346-3344
                    </p>
                </div>
                <div class="online-support">
                    <strong>Looking for online support?</strong>
                    <p>
                        Talk to us now with our online chat
                    </p>
                </div>
                <div class="social">
                    <a href="#" class="fb"><img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/images/social/fb.png" alt="facebook" /></a>
                    <a href="#" class="tw"><img src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/images/social/tw.png" alt="twitter" /></a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("chunks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
