<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 14:29:48
         compiled from "/var/www/engine.loc/themes/default/views/modules/blog/posts.tpl" */ ?>
<?php /*%%SmartyHeaderCode:152826510556f511f12bc117-13331780%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '03e1c85d1510ca5f685b9f44344ed741e49b7d1f' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/blog/posts.tpl',
      1 => 1459337388,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '152826510556f511f12bc117-13331780',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f511f12dae34_65118982',
  'variables' => 
  array (
    'blog' => 0,
    'post' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f511f12dae34_65118982')) {function content_56f511f12dae34_65118982($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['post'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['post']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['blog']->value['posts']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['post']->key => $_smarty_tpl->tpl_vars['post']->value) {
$_smarty_tpl->tpl_vars['post']->_loop = true;
?>
    <div class="post">
        <?php if ($_smarty_tpl->tpl_vars['post']->value['image']) {?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
" class="pic">
                <img src="<?php echo $_smarty_tpl->tpl_vars['post']->value['image'];?>
" class="img-responsive" alt="blogpost" />
            </a>
        <?php }?>

        <div class="title">
            <a title="<?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['post']->value['name'];?>
</a>
        </div>
        <div class="author">
            <img src="<?php echo $_smarty_tpl->tpl_vars['post']->value['author_avatar'];?>
" class="avatar" alt="author" />
            <?php echo $_smarty_tpl->tpl_vars['post']->value['author_name'];?>
, <?php echo $_smarty_tpl->tpl_vars['post']->value['published'];?>

        </div>
        <p class="intro">
            <?php echo $_smarty_tpl->tpl_vars['post']->value['description'];?>

        </p>
        <a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
" class="continue-reading"><?php echo $_smarty_tpl->tpl_vars['t']->value['blog']['readmore'];?>
</a>
    </div>
<?php } ?><?php }} ?>
