<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 15:13:50
         compiled from "/var/www/engine.loc/themes/default/views/modules/blog/posts.tpl" */ ?>
<?php /*%%SmartyHeaderCode:152826510556f511f12bc117-13331780%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '03e1c85d1510ca5f685b9f44344ed741e49b7d1f' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/blog/posts.tpl',
      1 => 1467720830,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '152826510556f511f12bc117-13331780',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f511f12dae34_65118982',
  'variables' => 
  array (
    'page' => 0,
    'mod' => 0,
    'post' => 0,
    'app' => 0,
    't' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f511f12dae34_65118982')) {function content_56f511f12dae34_65118982($_smarty_tpl) {?><div class="m_news">
    <ul class="news__list">
        <?php  $_smarty_tpl->tpl_vars['post'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['post']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['mod']->value->blog->posts($_smarty_tpl->tpl_vars['page']->value['id']); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['post']->key => $_smarty_tpl->tpl_vars['post']->value) {
$_smarty_tpl->tpl_vars['post']->_loop = true;
?>
        <li class="news__item">
            <a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
" class="news__link">
                <span class="news__img-block">
                    <span class="news__img" style="background-image: url('<?php echo $_smarty_tpl->tpl_vars['app']->value->images->cover($_smarty_tpl->tpl_vars['post']->value['id'],'post');?>
');"></span>
                </span>

                <span class="news__content">
                    <span class="news__heading"><?php echo $_smarty_tpl->tpl_vars['post']->value['name'];?>
</span>
                    <span class="m_article-info">
                        <span class="article-info__date">
                            <?php echo strftime('%d',$_smarty_tpl->tpl_vars['post']->value['created']);?>
 <?php echo $_smarty_tpl->tpl_vars['t']->value['month'][date('n',$_smarty_tpl->tpl_vars['post']->value['created'])];?>
 <?php echo strftime('%Y',$_smarty_tpl->tpl_vars['post']->value['created']);?>

                        </span>
                        <span class="article-info__views">
                            32 <?php echo $_smarty_tpl->tpl_vars['t']->value['blog']['post_views'];?>

                        </span>
                        <span class="article-info__comments">
                            4 <?php echo $_smarty_tpl->tpl_vars['t']->value['blog']['post_comments'];?>

                        </span>
                    </span>
                    <span class="news__text">
                        <?php echo strip_tags($_smarty_tpl->tpl_vars['post']->value['intro']);?>
... <span class="news__read-more"><?php echo $_smarty_tpl->tpl_vars['t']->value['blog']['post_readmore'];?>
</span>
                    </span>
                </span>
            </a>
        </li>
        <?php } ?>
    </ul>
</div><?php }} ?>
