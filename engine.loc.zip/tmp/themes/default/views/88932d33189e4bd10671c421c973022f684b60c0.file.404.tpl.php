<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-24 14:36:00
         compiled from "themes/default/views/content_types/pages/404.tpl" */ ?>
<?php /*%%SmartyHeaderCode:177253006556efffc9be6772-90349533%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '88932d33189e4bd10671c421c973022f684b60c0' => 
    array (
      0 => 'themes/default/views/content_types/pages/404.tpl',
      1 => 1458810170,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '177253006556efffc9be6772-90349533',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56efffc9bf2918_85791126',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56efffc9bf2918_85791126')) {function content_56efffc9bf2918_85791126($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<body id="not-found" class="not-found-page">
<div class="info">
    <h1>404</h1>
    <p>Отакої. Сторінка відсутня.</p>

    <p class="go-back">
        напевне вам вартує повернутись на <a href="/">головну</a>.
    </p>
</div><?php }} ?>
