<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 14:17:55
         compiled from "/var/www/engine.loc/themes/default/views/modules/pagiation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:161496412856f4eab24bd484-37798091%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c92e92ea74833f40690a0f502f51941b7a1cbca' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/pagiation.tpl',
      1 => 1467717425,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '161496412856f4eab24bd484-37798091',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f4eab24dd755_60926171',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f4eab24dd755_60926171')) {function content_56f4eab24dd755_60926171($_smarty_tpl) {?>

<div class="m_pagination">
    <ul class="pagination__list">
        <li class="pagination__item pagination__item--active">
            <a href="#" class="pagination__link">
                1
            </a>
        </li>
        <li class="pagination__item">
            <a href="#" class="pagination__link">
                2
            </a>
        </li>
        <li class="pagination__item">
            <a href="#" class="pagination__link">
                3
            </a>
        </li>
        <li class="pagination__item pagination__item--dots">
            <a href="javascript:void(0)" class="pagination__link">
                ...
            </a>
        </li>
        <li class="pagination__item">
            <a href="#" class="pagination__link">
                10
            </a>
        </li>
    </ul>
</div><?php }} ?>
