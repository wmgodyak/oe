<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-25 10:36:55
         compiled from "/var/www/engine.loc/themes/default/views/modules/pagiation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:161496412856f4eab24bd484-37798091%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c92e92ea74833f40690a0f502f51941b7a1cbca' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/pagiation.tpl',
      1 => 1458895015,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '161496412856f4eab24bd484-37798091',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f4eab24dd755_60926171',
  'variables' => 
  array (
    'pagination' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f4eab24dd755_60926171')) {function content_56f4eab24dd755_60926171($_smarty_tpl) {?>
<?php if (count($_smarty_tpl->tpl_vars['pagination']->value['pages'])) {?>
<div class="pages">
    <ul class="pagination">
        <?php if ($_smarty_tpl->tpl_vars['pagination']->value['prev']!='') {?>
        <li><a href="<?php echo $_smarty_tpl->tpl_vars['pagination']->value['prev'];?>
">&laquo;</a></li>
        <?php }?>
        <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['pagination']->value['pages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
            <li class="<?php echo $_smarty_tpl->tpl_vars['item']->value['class'];?>
"><a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a></li>
        <?php } ?>
        <?php if ($_smarty_tpl->tpl_vars['pagination']->value['next']!='') {?>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['pagination']->value['next'];?>
">&raquo;</a></li>
        <?php }?>
    </ul>
</div>
<?php }?><?php }} ?>
