<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 16:31:55
         compiled from "82beea4ecd045cafcad5d98d4ba56cd3fcf729b8" */ ?>
<?php /*%%SmartyHeaderCode:837526956fbd54beaa6b8-54272333%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '82beea4ecd045cafcad5d98d4ba56cd3fcf729b8' => 
    array (
      0 => '82beea4ecd045cafcad5d98d4ba56cd3fcf729b8',
      1 => 0,
      2 => 'string',
    ),
  ),
  'nocache_hash' => '837526956fbd54beaa6b8-54272333',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56fbd54bec8c86_78716859',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56fbd54bec8c86_78716859')) {function content_56fbd54bec8c86_78716859($_smarty_tpl) {?>Вітаємо.<br> Новий коментар до статі <?php echo $_smarty_tpl->tpl_vars['data']->value['post_name'];?>
.<br>
Ім'я: <?php echo $_smarty_tpl->tpl_vars['data']->value['user']['name'];?>
<br>
Email: <?php echo $_smarty_tpl->tpl_vars['data']->value['user']['email'];?>
<br>
Коментар: <?php echo $_smarty_tpl->tpl_vars['data']->value['message'];?>
<br>
<br>
----------------------------------
<br>
Ви можете <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['approve_url'];?>
">опублікувати коменар</a> або <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['del_url'];?>
">видалити</a> його.
<?php }} ?>
