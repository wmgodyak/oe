<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 14:28:17
         compiled from "themes/default/views/layouts/posts_categories.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1831209817577b9881eb85d7-93761583%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '337080c2af0bb03e9cf652841c2f9ba632ac8986' => 
    array (
      0 => 'themes/default/views/layouts/posts_categories.tpl',
      1 => 1467718095,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1831209817577b9881eb85d7-93761583',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b9881eb8dc8_83870425',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b9881eb8dc8_83870425')) {function content_577b9881eb8dc8_83870425($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("modules/blog/index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
