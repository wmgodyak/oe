<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-30 10:41:35
         compiled from "themes/default/views/layouts/pages.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8383647556f550036aecb6-08806468%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd1441830bfb1d9b36e08bb957e65e22564eb0579' => 
    array (
      0 => 'themes/default/views/layouts/pages.tpl',
      1 => 1459150413,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8383647556f550036aecb6-08806468',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f550036d1c84_54297659',
  'variables' => 
  array (
    'theme_url' => 0,
    'page' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f550036d1c84_54297659')) {function content_56f550036d1c84_54297659($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("chunks/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<body id="about-us">
<?php echo $_smarty_tpl->getSubTemplate ("modules/nav/top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/js/vendor/jquery.flexslider.min.js"><?php echo '</script'; ?>
>
<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['theme_url']->value;?>
assets/css/vendor/flexslider.css">
<div id="slider">
    <div class="container">
        <div class="row header">
            <div class="col-md-12">
                <h3><?php echo $_smarty_tpl->tpl_vars['page']->value['name'];?>
</h3>
                <p>
                    <?php echo $_smarty_tpl->tpl_vars['page']->value['description'];?>

                </p>
            </div>
        </div>
        <?php echo $_smarty_tpl->getSubTemplate ("modules/slider.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>
</div>

<div id="info">
    <div class="container">
        <?php echo $_smarty_tpl->tpl_vars['page']->value['content'];?>

    </div>
</div>

<div id="cta">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wrapper clearfix">
                    <h4>Try engine now and take your own project to a whole new level.</h4>
                    <a href="30" class="button button-small">Sign up free</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("chunks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<?php echo '<script'; ?>
 type="text/javascript">
    $(function() {
        $('.flexslider').flexslider({
            directionNav: false,
            slideshowSpeed: 4000
        });
        $('[data-toggle="tooltip"]').tooltip();
    });
<?php echo '</script'; ?>
>
</body><?php }} ?>
