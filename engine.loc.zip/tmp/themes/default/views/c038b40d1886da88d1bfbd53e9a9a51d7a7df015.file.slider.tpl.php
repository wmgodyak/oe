<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-22 17:21:06
         compiled from "/var/www/engine.loc/themes/default/views/modules/slider.tpl" */ ?>
<?php /*%%SmartyHeaderCode:191454978056f162921a86b3-08628582%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c038b40d1886da88d1bfbd53e9a9a51d7a7df015' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/slider.tpl',
      1 => 1458660066,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '191454978056f162921a86b3-08628582',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56f162921b11f4_41135795',
  'variables' => 
  array (
    'page' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56f162921b11f4_41135795')) {function content_56f162921b11f4_41135795($_smarty_tpl) {?><?php if (count($_smarty_tpl->tpl_vars['page']->value['images'])) {?>
<div class="row">
    <div class="col-md-12">
        <div class="flexslider">
            <ul class="slides">
                <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['page']->value['images']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
                <li>
                    <img src="<?php echo $_smarty_tpl->tpl_vars['item']->value['path'];?>
/slider/<?php echo $_smarty_tpl->tpl_vars['item']->value['image'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['page']->value['name'];?>
" />
                </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</div>
<?php }?><?php }} ?>
