<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-07-05 11:04:04
         compiled from "/var/www/engine.loc/themes/default/views/modules/shop/nav.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1707912497577b69f41b8a94-07942012%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0fd39031f48ef6f7ced0d3869e6f034518a80965' => 
    array (
      0 => '/var/www/engine.loc/themes/default/views/modules/shop/nav.tpl',
      1 => 1467705843,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1707912497577b69f41b8a94-07942012',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_577b69f41c76e4_76743674',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_577b69f41c76e4_76743674')) {function content_577b69f41c76e4_76743674($_smarty_tpl) {?><!-- begin sidebar -->
<aside class="sidebar sidebar-collapse">

    <!-- begin m_goods-nav -->
    <nav class="m_goods-nav">
        <div class="goods-nav__header">
            <a href="#">КАТАЛОГ ТОВАРІВ</a>
        </div>
        <ul class="goods-nav__list">
            <li class="goods-nav__item i1">
                <a class="goods-nav__link" href="#">Запчастини для мобільних телефонів</a>
                <div class="sub-menu">
                    <div class="content my-grid">
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
            <li class="goods-nav__item i2">
                <a class="goods-nav__link" href="#">Запчастини для планшетів</a>
                <div class="sub-menu">
                    <div class="content my-grid">
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
            <li class="goods-nav__item i3">
                <a class="goods-nav__link" href="#">Запчастини для Apple iPhone</a>
                <div class="sub-menu">
                    <div class="content my-grid">
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                        <div class="item">
                            <ul class="single-category">
                                <li><a class="text-head" href="">Категорія</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                                <li><a class="link" href="">Запчастини</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
            <li class="goods-nav__item i4">
                <a class="goods-nav__link" href="#">Запчастини для Apple iPod</a>
            </li>
            <li class="goods-nav__item i5">
                <a class="goods-nav__link" href="#">Запчастини для Apple iPad</a>
            </li>
            <li class="goods-nav__item i6">
                <a class="goods-nav__link" href="#">Аксесуари для мобільних телефонів</a>
            </li>
            <li class="goods-nav__item i7">
                <a class="goods-nav__link" href="#">Аксесуари для Apple iPhone</a>
            </li>
            <li class="goods-nav__item i8">
                <a class="goods-nav__link" href="#">Аксесуари для Apple iPad</a>
            </li>
            <li class="goods-nav__item i9">
                <a class="goods-nav__link" href="#">Обладнання та інструменти</a>
            </li>
            <li class="goods-nav__item i10">
                <a class="goods-nav__link" href="#">Обладнання для програмування</a>
            </li>
            <li class="goods-nav__item i11">
                <a class="goods-nav__link" href="#">Витратні матеріали для ремонту</a>
            </li>
            <li class="goods-nav__item i12">
                <a class="goods-nav__link" href="#">Аксесуари по брендах</a>
            </li>
        </ul>
    </nav>
    <!-- end m_goods-nav -->

</aside>
<!-- end sidebar --><?php }} ?>
