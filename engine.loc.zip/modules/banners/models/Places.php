<?php
/**
 * OYiEngine 7
 * @author Volodymyr Hodiak mailto:support@otakoi.com
 * @copyright Copyright (c) 2015 Otakoyi.com
 * Date: 27.06.16 : 17:51
 */

namespace modules\banners\models;

use system\models\Model;

defined("CPATH") or die();

class Places extends Model
{

}