<?php
/**
 * OYiEngine 7
 * @author Volodymyr Hodiak mailto:support@otakoi.com
 * @copyright Copyright (c) 2015 Otakoyi.com
 * Date: 23.03.16 : 17:41
 */

namespace models\engine\plugins;

use models\Engine;

defined("CPATH") or die();

/**
 * Class Comments
 * @package models\engine\plugins
 */
class Comments extends \models\engine\Comments
{

}