<?php
/**
 * OYiEngine 7
 * @author Volodymyr Hodiak mailto:support@otakoi.com
 * @copyright Copyright (c) 2015 Otakoyi.com
 * Date: 25.03.16 : 18:05
 */

namespace models\modules;

use models\App;

defined("CPATH") or die();

class Comments extends \models\components\Comments
{

}