<?php
/**
 * OYiEngine 7
 * @author Volodymyr Hodiak mailto:support@otakoi.com
 * @copyright Copyright (c) 2015 Otakoyi.com
 * Date: 21.03.16 : 12:05
 */

namespace models\app;

use models\App;

defined("CPATH") or die();

class Page extends Content
{

}